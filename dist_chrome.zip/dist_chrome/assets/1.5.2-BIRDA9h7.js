const e=`<!-- lang:en -->

### What's New

- **Per-site accent color**: The theme accent can now be set per site, with Everforest sage as the default.
- **Search inside folders**: Folders gain a search box, so you can find the conversation you want in a snap.
- **Fuzzy settings search**: Type a few letters in settings to jump straight to an option, instead of scrolling through everything.
- **Claude conversation timeline**: A new built-in plugin brings the familiar conversation timeline to Claude's pages too.
- **Inline folder editing in AI Studio**: Renaming and deleting folders in AI Studio now happens in a tidy inline dialog.

### Fixes

- **Your default model's thinking level sticks**: After setting a default model, its thinking level applies automatically again.
- **Completion alerts are more reliable**: Background, non-generation traffic is ignored and alerts are deduped, so a finished reply pings once, only when it should.
- **Multi-account usage reads correctly**: Usage data is fetched for the right account, instead of coming back empty or mixed up.
- **More complete exports**: Exports now include canvas documents and the UI generated on the page.
- **Smoother sidebar with visual effects on**: With visual effects enabled, the sidebar scrolls and expands with much less jank.
- **Collapse button works on a widened sidebar**: After widening the sidebar, the top toggle no longer sits dead over an invisible button — the real control collapses and expands the sidebar again.

---

> *"To be alive is to be known by someone, and remembered. Just a little is enough. If you can change someone's life, surely that alone is enough." — Himmel, 《Frieren: Beyond Journey's End》*

<!-- lang:zh -->

### 新功能

- **每个站点都能自定义强调色**：主题强调色现在可以按站点单独设置，默认是 Everforest 鼠尾草绿。
- **在文件夹里搜对话**：文件夹内新增搜索框，快速找到想要的那条对话。
- **设置支持模糊搜索**：在设置里随手打几个字就能跳到对应选项，不用一项项翻。
- **Claude 对话时间轴**：新增一个内置插件，在 Claude 页面也能用上熟悉的对话时间轴。
- **AI Studio 文件夹就地编辑**：在 AI Studio 里重命名、删除文件夹改成就地弹窗，更顺手。

### 修复

- **默认模型的思考档位会自动应用**：设好默认模型后，思考档位重新会自动跟着生效。
- **完成提醒更可靠**：忽略非生成的后台流量并去重，回复完成只在该响的时候响一次。
- **多账号用量读取修复**：多账号下能正确拉取当前账号的用量，不再串号或拿空。
- **导出更完整**：导出现在会一并收入 canvas 文档和页面里生成的界面。
- **开特效时侧边栏更顺**：开启视觉特效时，侧边栏滚动和展开的卡顿明显减轻。
- **加宽侧边栏后折叠按钮恢复可点**：把侧边栏拉宽后，顶部的折叠/展开按钮不再被一个隐形按钮挡住失灵，真正的按钮重新能收起、展开侧边栏。

---

> *“所谓活着，就是被某个人知道、被某个人记住。哪怕只是一点点也好。只要能改变某个人的人生，想必这样就足够了。” —— 辛美尔，《葬送的芙莉莲》*

<!-- lang:zh_TW -->

### 新功能

- **每個站點都能自訂強調色**：主題強調色現在可以依站點單獨設定，預設是 Everforest 鼠尾草綠。
- **在資料夾裡搜對話**：資料夾內新增搜尋框，快速找到想要的那則對話。
- **設定支援模糊搜尋**：在設定裡隨手打幾個字就能跳到對應選項，不用一項項翻。
- **Claude 對話時間軸**：新增一個內建外掛，在 Claude 頁面也能用上熟悉的對話時間軸。
- **AI Studio 資料夾就地編輯**：在 AI Studio 裡重新命名、刪除資料夾改成就地彈窗，更順手。

### 修復

- **預設模型的思考檔位會自動套用**：設好預設模型後，思考檔位重新會自動跟著生效。
- **完成提醒更可靠**：忽略非生成的背景流量並去重，回覆完成只在該響的時候響一次。
- **多帳號用量讀取修復**：多帳號下能正確拉取當前帳號的用量，不再串號或拿空。
- **匯出更完整**：匯出現在會一併收入 canvas 文件和頁面裡生成的介面。
- **開特效時側邊欄更順**：開啟視覺特效時，側邊欄捲動和展開的卡頓明顯減輕。
- **加寬側邊欄後折疊按鈕恢復可點**：把側邊欄拉寬後，頂部的折疊/展開按鈕不再被一個隱形按鈕擋住失靈，真正的按鈕重新能收起、展開側邊欄。

---

> *「所謂活著，就是被某個人知道、被某個人記住。哪怕只是一點點也好。只要能改變某個人的人生，想必這樣就足夠了。」——辛美爾，《葬送的芙莉蓮》*

<!-- lang:ja -->

### 新機能

- **サイトごとにアクセントカラーを設定**：テーマのアクセントカラーをサイト単位で設定できるようになりました。既定は Everforest セージグリーンです。
- **フォルダ内を検索**：フォルダに検索ボックスが付き、目当ての会話をすぐ見つけられます。
- **設定のあいまい検索**：設定で数文字打つだけで目的の項目に飛べます。ひとつずつ探す必要はありません。
- **Claude の会話タイムライン**：新しい組み込みプラグインで、おなじみの会話タイムラインが Claude のページでも使えます。
- **AI Studio のフォルダをその場で編集**：AI Studio でのフォルダの名前変更や削除が、すっきりしたインラインダイアログで行えます。

### 修正

- **既定モデルの思考レベルが保持される**：既定モデルを設定すると、その思考レベルがまた自動で適用されます。
- **完了通知がより確実に**：生成以外のバックグラウンド通信を無視し、通知も重複排除。返信が終わったときだけ一度鳴ります。
- **マルチアカウントの使用量が正しく読める**：使用量データが正しいアカウントから取得され、空になったり混ざったりしなくなりました。
- **より完全なエクスポート**：エクスポートに canvas ドキュメントとページ上で生成された UI も含まれるようになりました。
- **視覚エフェクト中のサイドバーがなめらかに**：視覚エフェクトをオンにしていても、サイドバーのスクロールと展開のもたつきが大きく減りました。
- **サイドバーを広げても折りたたみボタンが効く**：サイドバーを広げたとき、上部の切り替えボタンが見えないボタンに覆われて反応しなくなる問題を解消し、本来のボタンでまた折りたたみ・展開できます。

---

> *「生きているということは誰かに知ってもらって覚えていてもらうことだ。ほんの少しでいい。誰かの人生を変えてあげればいい。きっとそれだけで十分なんだ。」——ヒンメル、《葬送のフリーレン》*

<!-- lang:fr -->

### Nouveautés

- **Couleur d'accent par site** : La couleur d'accent du thème peut désormais être définie pour chaque site, avec la sauge Everforest par défaut.
- **Recherche dans les dossiers** : Les dossiers reçoivent une barre de recherche, pour retrouver la conversation voulue en un instant.
- **Recherche floue dans les réglages** : Tapez quelques lettres dans les réglages pour sauter droit à une option, au lieu de tout faire défiler.
- **Chronologie de conversation pour Claude** : Un nouveau module intégré apporte la chronologie de conversation familière aux pages de Claude aussi.
- **Édition de dossiers en ligne dans AI Studio** : Renommer et supprimer des dossiers dans AI Studio se fait désormais dans une boîte de dialogue en ligne, toute simple.

### Corrections

- **Le niveau de réflexion de votre modèle par défaut tient** : Après avoir défini un modèle par défaut, son niveau de réflexion s'applique à nouveau automatiquement.
- **Des alertes de fin plus fiables** : Le trafic d'arrière-plan hors génération est ignoré et les alertes sont dédupliquées, donc une réponse terminée ne sonne qu'une fois, au bon moment.
- **L'utilisation multicompte se lit correctement** : Les données d'utilisation sont récupérées pour le bon compte, au lieu de revenir vides ou mélangées.
- **Des exports plus complets** : Les exports incluent désormais les documents canvas et l'interface générée sur la page.
- **Barre latérale plus fluide avec les effets visuels** : Avec les effets visuels activés, la barre latérale défile et se déploie avec bien moins de saccades.
- **Le bouton de repli fonctionne sur une barre élargie** : Après avoir élargi la barre latérale, le bouton de bascule du haut n'est plus inerte au-dessus d'un bouton invisible — le vrai contrôle replie et déploie de nouveau la barre.

---

> *« Être en vie, c'est être connu de quelqu'un et rester dans sa mémoire. Un tout petit peu suffit. S'il t'est donné de changer la vie de quelqu'un, cela seul suffit sûrement. » — Himmel, 《Frieren: Beyond Journey's End》*

<!-- lang:es -->

### Novedades

- **Color de acento por sitio**: El acento del tema ahora se puede ajustar para cada sitio, con el verde salvia de Everforest por defecto.
- **Busca dentro de las carpetas**: Las carpetas estrenan un buscador, para encontrar la conversación que quieres en un instante.
- **Búsqueda difusa en los ajustes**: Escribe unas letras en los ajustes para saltar directo a una opción, en vez de desplazarte por todo.
- **Línea de tiempo de conversación para Claude**: Un nuevo complemento integrado lleva la conocida línea de tiempo de conversación también a las páginas de Claude.
- **Edición de carpetas en línea en AI Studio**: Renombrar y borrar carpetas en AI Studio ahora ocurre en un diálogo en línea, limpio y sencillo.

### Correcciones

- **El nivel de razonamiento de tu modelo predeterminado se mantiene**: Tras fijar un modelo predeterminado, su nivel de razonamiento vuelve a aplicarse automáticamente.
- **Avisos de finalización más fiables**: Se ignora el tráfico de fondo ajeno a la generación y los avisos se deduplican, así una respuesta terminada suena una vez, solo cuando debe.
- **El uso multicuenta se lee bien**: Los datos de uso se obtienen de la cuenta correcta, en vez de volver vacíos o mezclados.
- **Exportaciones más completas**: Las exportaciones ahora incluyen los documentos canvas y la interfaz generada en la página.
- **Barra lateral más fluida con los efectos visuales**: Con los efectos visuales activados, la barra lateral se desplaza y despliega con muchos menos tirones.
- **El botón de plegado funciona con la barra ensanchada**: Tras ensanchar la barra lateral, el botón de alternancia superior ya no queda inerte sobre un botón invisible — el control real vuelve a plegar y desplegar la barra.

---

> *«Estar vivo es que alguien te conozca y te recuerde. Basta con un poco. Si puedes cambiar la vida de alguien, seguro que con eso basta.» — Himmel, 《Frieren: Beyond Journey's End》*

<!-- lang:pt -->

### Novidades

- **Cor de destaque por site**: O destaque do tema agora pode ser definido para cada site, com o verde sálvia da Everforest por padrão.
- **Busque dentro das pastas**: As pastas ganham um campo de busca, para achar a conversa que você quer num instante.
- **Busca aproximada nas configurações**: Digite algumas letras nas configurações para saltar direto a uma opção, em vez de rolar por tudo.
- **Linha do tempo de conversa para o Claude**: Um novo plugin integrado leva a conhecida linha do tempo de conversa também às páginas do Claude.
- **Edição de pastas em linha no AI Studio**: Renomear e excluir pastas no AI Studio agora acontece num diálogo em linha, limpo e simples.

### Correções

- **O nível de raciocínio do seu modelo padrão se mantém**: Depois de definir um modelo padrão, o nível de raciocínio dele volta a se aplicar automaticamente.
- **Avisos de conclusão mais confiáveis**: O tráfego de fundo alheio à geração é ignorado e os avisos são desduplicados, então uma resposta concluída toca uma vez, só quando deve.
- **O uso multiconta lê corretamente**: Os dados de uso são buscados na conta certa, em vez de voltarem vazios ou misturados.
- **Exportações mais completas**: As exportações agora incluem os documentos canvas e a interface gerada na página.
- **Barra lateral mais fluida com os efeitos visuais**: Com os efeitos visuais ligados, a barra lateral rola e se expande com bem menos travadas.
- **O botão de recolher funciona com a barra alargada**: Depois de alargar a barra lateral, o botão de alternância do topo não fica mais inerte sobre um botão invisível — o controle real volta a recolher e expandir a barra.

---

> *«Estar vivo é ser conhecido por alguém e permanecer em sua memória. Basta um pouco. Se você puder mudar a vida de alguém, com certeza isso já basta.» — Himmel, 《Frieren: Beyond Journey's End》*

<!-- lang:ar -->

### الجديد

- **لون تمييز لكل موقع**: يمكن الآن ضبط لون تمييز السمة لكل موقع على حدة، والافتراضي هو أخضر المريمية من Everforest.
- **ابحث داخل المجلدات**: حصلت المجلدات على مربع بحث، لتجد المحادثة التي تريدها في لمحة.
- **بحث تقريبي في الإعدادات**: اكتب بضعة أحرف في الإعدادات لتقفز مباشرةً إلى الخيار المطلوب بدل التمرير عبر كل شيء.
- **خط زمني للمحادثة في Claude**: إضافة مدمجة جديدة تجلب خط المحادثة الزمني المألوف إلى صفحات Claude أيضًا.
- **تحرير المجلدات داخل الصفحة في AI Studio**: إعادة تسمية المجلدات وحذفها في AI Studio يحدث الآن في نافذة مدمجة أنيقة.

### الإصلاحات

- **مستوى تفكير نموذجك الافتراضي يثبت**: بعد تعيين نموذج افتراضي، يُطبَّق مستوى تفكيره تلقائيًا من جديد.
- **تنبيهات الاكتمال أكثر موثوقية**: يُتجاهَل حركة الخلفية غير المتعلقة بالتوليد وتُزال التنبيهات المكررة، فيرنّ الرد المنتهي مرة واحدة فقط وفي وقته.
- **قراءة صحيحة لاستخدام الحسابات المتعددة**: تُجلب بيانات الاستخدام للحساب الصحيح بدل أن تعود فارغة أو مختلطة.
- **عمليات تصدير أكثر اكتمالًا**: تتضمن عمليات التصدير الآن مستندات canvas والواجهة المولّدة على الصفحة.
- **شريط جانبي أكثر سلاسة مع المؤثرات البصرية**: عند تفعيل المؤثرات البصرية، يتمرر الشريط الجانبي ويتوسع بتلعثم أقل بكثير.
- **زر الطيّ يعمل مع شريط جانبي موسَّع**: بعد توسيع الشريط الجانبي، لم يعد زر التبديل العلوي معطّلًا فوق زر غير مرئي — يعود الزر الحقيقي ليطوي الشريط ويوسّعه.

---

> *«أن تكون حيًّا يعني أن يعرفك أحدهم وأن يظلّ يتذكّرك. يكفي القليل. إن استطعت أن تغيّر حياة أحدهم، فإن ذلك وحده يكفي بالتأكيد.» — هينمل، 《Frieren: Beyond Journey's End》*

<!-- lang:ko -->

### 새로운 기능

- **사이트별 강조 색상**: 이제 테마 강조 색상을 사이트마다 따로 설정할 수 있습니다. 기본값은 Everforest 세이지 그린입니다.
- **폴더 안에서 검색**: 폴더에 검색창이 생겨, 원하는 대화를 순식간에 찾을 수 있습니다.
- **설정 퍼지 검색**: 설정에서 몇 글자만 입력하면 해당 항목으로 바로 이동합니다. 하나하나 넘길 필요가 없습니다.
- **Claude 대화 타임라인**: 새 내장 플러그인으로 익숙한 대화 타임라인을 Claude 페이지에서도 쓸 수 있습니다.
- **AI Studio 폴더 인라인 편집**: AI Studio에서 폴더 이름 변경과 삭제가 깔끔한 인라인 대화상자로 이뤄집니다.

### 수정

- **기본 모델의 사고 단계가 유지됩니다**: 기본 모델을 설정하면 그 사고 단계가 다시 자동으로 적용됩니다.
- **완료 알림이 더 안정적으로**: 생성과 무관한 백그라운드 트래픽을 무시하고 알림을 중복 제거해, 끝난 답변은 알맞은 때 한 번만 울립니다.
- **멀티 계정 사용량이 올바르게 읽힙니다**: 사용량 데이터가 맞는 계정에서 불러와져, 비거나 뒤섞이지 않습니다.
- **더 완전한 내보내기**: 내보내기에 canvas 문서와 페이지에서 생성된 UI도 함께 담깁니다.
- **시각 효과를 켜도 부드러운 사이드바**: 시각 효과를 켠 상태에서도 사이드바의 스크롤과 펼침이 훨씬 덜 끊깁니다.
- **넓힌 사이드바에서도 접기 버튼이 작동**: 사이드바를 넓힌 뒤 상단 토글 버튼이 보이지 않는 버튼에 가려 먹통이 되던 문제를 고쳐, 진짜 버튼으로 다시 접고 펼 수 있습니다.

---

> *"살아 있다는 건, 누군가가 너를 알아주고 기억해 주는 거야. 아주 조금이면 돼. 누군가의 인생을 바꿔 줄 수 있다면, 분명 그것만으로 충분해." — 힘멜, 《장송의 프리렌》*

<!-- lang:ru -->

### Новое

- **Цвет акцента для каждого сайта**: Акцент темы теперь можно задать для каждого сайта отдельно; по умолчанию — шалфейный зелёный Everforest.
- **Поиск внутри папок**: В папках появилось поле поиска, чтобы вы находили нужный разговор за мгновение.
- **Нечёткий поиск в настройках**: Наберите пару букв в настройках, чтобы сразу перейти к нужному пункту, а не прокручивать всё подряд.
- **Лента беседы для Claude**: Новый встроенный плагин приносит знакомую ленту беседы и на страницы Claude.
- **Встроенное редактирование папок в AI Studio**: Переименование и удаление папок в AI Studio теперь происходит в аккуратном встроенном диалоге.

### Исправления

- **Уровень размышления модели по умолчанию сохраняется**: После выбора модели по умолчанию её уровень размышления снова применяется автоматически.
- **Уведомления о завершении надёжнее**: Фоновый трафик, не связанный с генерацией, игнорируется, а уведомления дедуплицируются, поэтому готовый ответ звучит один раз и вовремя.
- **Использование по нескольким аккаунтам читается верно**: Данные об использовании берутся для нужного аккаунта, а не возвращаются пустыми или перепутанными.
- **Более полный экспорт**: Экспорт теперь включает документы canvas и интерфейс, сгенерированный на странице.
- **Боковая панель плавнее при включённых эффектах**: С включёнными визуальными эффектами боковая панель прокручивается и раскрывается с куда меньшими подёргиваниями.
- **Кнопка сворачивания работает на расширенной панели**: После расширения боковой панели верхняя кнопка-переключатель больше не зависает над невидимой кнопкой — настоящий элемент снова сворачивает и разворачивает панель.

---

> *«Быть живым — значит быть кому-то знакомым и остаться в чьей-то памяти. Хватит и малого. Если ты можешь изменить чью-то жизнь, этого одного наверняка довольно.» — Химмель, 《Frieren: Beyond Journey's End》*
`;export{e as default};
