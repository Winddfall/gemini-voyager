const n=`<!-- lang:en -->

### What's New

- **Safer default permissions**: Voyager no longer asks for all-site access by default; generated UI capture requests it only when you export.

### Fixes

- **Legacy capture permission cleanup**: Users who updated from v1.5.2 have the old broad generated-UI capture permission removed automatically.
- **Recents hider recovery**: Hidden sidebar sections now restore their peek bars reliably after Gemini re-renders.
- **Canvas copy menu stability**: Canvas Markdown copy buttons keep appearing correctly without interrupting Gemini's native Canvas mode.

---

> *"With great power comes great responsibility." — Uncle Ben, 《Spider-Man》*

<!-- lang:zh -->

### 新功能

- **默认权限更安全**：Voyager 不再默认请求所有网站访问权；只有导出生成界面截图时，才会按需请求这项权限。

### 修复

- **清理旧版截图权限**：从 v1.5.2 更新上来的用户，会自动移除旧的生成界面截图宽权限。
- **最近项目隐藏恢复更稳**：Gemini 重渲染侧边栏后，被隐藏区块的恢复条不再容易丢失。
- **Canvas 复制菜单更稳**：Canvas 的 Markdown 复制按钮会继续正常出现，也不会打断 Gemini 原生 Canvas 模式。

---

> *“能力越大，责任越大。” —— 本叔叔，《蜘蛛侠》*

<!-- lang:zh_TW -->

### 新功能

- **預設權限更安全**：Voyager 不再預設請求所有網站存取權；只有匯出生成介面截圖時，才會視需要請求這項權限。

### 修復

- **清理舊版截圖權限**：從 v1.5.2 更新上來的使用者，會自動移除舊的生成介面截圖寬權限。
- **最近項目隱藏恢復更穩**：Gemini 重新渲染側邊欄後，被隱藏區塊的恢復條不再容易消失。
- **Canvas 複製選單更穩**：Canvas 的 Markdown 複製按鈕會繼續正常出現，也不會打斷 Gemini 原生 Canvas 模式。

---

> *「能力越大，責任越大。」——班叔叔，《蜘蛛人》*

<!-- lang:ja -->

### 新機能

- **既定権限をより安全に**：Voyager は全サイトへのアクセス権を既定で求めなくなりました。生成 UI のスクリーンショットは、エクスポート時だけ必要に応じて権限を求めます。

### 修正

- **旧キャプチャ権限の整理**：v1.5.2 から更新したユーザーは、以前の広い生成 UI キャプチャ権限が自動で外れます。
- **最近項目の非表示復元**：Gemini がサイドバーを再描画しても、非表示セクションの復元バーが安定して戻ります。
- **Canvas コピーメニューの安定化**：Canvas の Markdown コピーボタンが正しく出続け、Gemini 標準の Canvas モードも邪魔しません。

---

> *「大いなる力には、大いなる責任が伴う。」——ベンおじさん、《スパイダーマン》*

<!-- lang:fr -->

### Nouveautés

- **Autorisations par défaut plus sûres** : Voyager ne demande plus l'accès à tous les sites par défaut ; la capture d'UI générée le demande seulement lors de l'export.

### Corrections

- **Nettoyage de l'ancienne autorisation de capture** : Les utilisateurs passés par v1.5.2 perdent automatiquement l'ancienne autorisation large de capture d'UI générée.
- **Restauration du masquage des éléments récents** : Les sections masquées retrouvent maintenant leur barre de restauration de façon fiable après un nouveau rendu de la barre latérale par Gemini.
- **Menu de copie Canvas plus stable** : Les boutons de copie Markdown du Canvas continuent d'apparaître correctement sans interrompre le mode Canvas natif de Gemini.

---

> *« Un grand pouvoir implique de grandes responsabilités. » — Oncle Ben, 《Spider-Man》*

<!-- lang:es -->

### Novedades

- **Permisos predeterminados más seguros**: Voyager ya no pide acceso a todos los sitios por defecto; la captura de UI generada lo solicita solo al exportar.

### Correcciones

- **Limpieza del permiso de captura anterior**: A quienes actualizaron desde v1.5.2 se les retira automáticamente el antiguo permiso amplio para capturar UI generada.
- **Recuperación del ocultador de recientes**: Las secciones ocultas vuelven a mostrar su barra de recuperación de forma fiable después de que Gemini renderice de nuevo la barra lateral.
- **Menú de copia de Canvas más estable**: Los botones de copiar Markdown en Canvas siguen apareciendo correctamente sin interrumpir el modo Canvas nativo de Gemini.

---

> *« Un gran poder conlleva una gran responsabilidad. » — Tío Ben, 《Spider-Man》*

<!-- lang:pt -->

### Novidades

- **Permissões padrão mais seguras**: O Voyager não pede mais acesso a todos os sites por padrão; a captura de UI gerada só solicita isso ao exportar.

### Correções

- **Limpeza da permissão antiga de captura**: Quem atualizou a partir da v1.5.2 tem a antiga permissão ampla de captura de UI gerada removida automaticamente.
- **Recuperação do ocultador de recentes**: As seções ocultas agora recuperam suas barras de restauração de forma confiável depois que o Gemini renderiza a barra lateral novamente.
- **Menu de cópia do Canvas mais estável**: Os botões de copiar Markdown no Canvas continuam aparecendo corretamente sem interromper o modo Canvas nativo do Gemini.

---

> *« Com grandes poderes vêm grandes responsabilidades. » — Tio Ben, 《Homem-Aranha》*

<!-- lang:ar -->

### الجديد

- **أذونات افتراضية أكثر أمانًا**: لم يعد Voyager يطلب الوصول إلى كل المواقع افتراضيًا؛ ولا يطلب التقاط الواجهة المولّدة هذا الإذن إلا عند التصدير.

### الإصلاحات

- **تنظيف إذن الالتقاط القديم**: من حدّثوا من v1.5.2 يُزال لديهم تلقائيًا إذن التقاط الواجهة المولّدة الواسع القديم.
- **استعادة أكثر موثوقية لإخفاء العناصر الأخيرة**: تعود أشرطة الاستعادة للأقسام المخفية بثبات بعد أن يعيد Gemini رسم الشريط الجانبي.
- **قائمة نسخ Canvas أكثر استقرارًا**: تستمر أزرار نسخ Markdown في Canvas بالظهور بشكل صحيح من دون تعطيل وضع Canvas الأصلي في Gemini.

---

> *«مع القوة العظيمة تأتي مسؤولية عظيمة.» — العم بن، 《الرجل العنكبوت》*

<!-- lang:ko -->

### 새로운 기능

- **더 안전한 기본 권한**: Voyager는 이제 기본으로 모든 사이트 접근 권한을 요청하지 않습니다. 생성된 UI 캡처는 내보낼 때만 필요에 따라 요청합니다.

### 수정

- **이전 캡처 권한 정리**: v1.5.2에서 업데이트한 사용자는 예전의 넓은 생성 UI 캡처 권한이 자동으로 제거됩니다.
- **최근 항목 숨김 복구 개선**: Gemini가 사이드바를 다시 렌더링해도 숨겨진 섹션의 복구 막대가 안정적으로 돌아옵니다.
- **Canvas 복사 메뉴 안정화**: Canvas Markdown 복사 버튼이 계속 올바르게 표시되며 Gemini의 기본 Canvas 모드를 방해하지 않습니다.

---

> *"큰 힘에는 큰 책임이 따른다." — 벤 삼촌, 《스파이더맨》*

<!-- lang:ru -->

### Новое

- **Более безопасные разрешения по умолчанию**: Voyager больше не запрашивает доступ ко всем сайтам по умолчанию; захват созданного UI просит его только при экспорте.

### Исправления

- **Очистка старого разрешения на захват**: У пользователей, обновившихся с v1.5.2, старое широкое разрешение на захват созданного UI удаляется автоматически.
- **Восстановление скрытых недавних разделов**: Скрытые разделы теперь надёжно возвращают панели восстановления после повторной отрисовки боковой панели Gemini.
- **Более стабильное меню копирования Canvas**: Кнопки копирования Markdown в Canvas продолжают появляться корректно и не мешают родному режиму Canvas в Gemini.

---

> *«С большой силой приходит большая ответственность.» — дядя Бен, 《Человек-паук》*
`;export{n as default};
