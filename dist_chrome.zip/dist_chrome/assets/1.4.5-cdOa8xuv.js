const e=`<!-- lang:en -->

**Important update — please skim before dismissing.** Gemini's web UI just shipped a major redesign, and this release rebuilds the entire extension for the new layout (sidebar, model picker, folder panel, Gems entry) so your existing setup keeps working. The fixes below address real reports from the past 24 hours — if anything's still broken for you, expect a quick follow-up.

### What's New

- **Recent Gems sidebar list**: Expand the native Gems entry in the sidebar into a list of your recent gems for one-click access.
- **Thinking-level lock**: The default-model setting now also remembers and re-applies your preferred thinking level (Standard / Extended).
- **Input box halo toggle** *(off by default)*: Hide the blue radial-gradient glow behind Gemini's chat input area.
- **Markdown upload fork**: Start a new fork by uploading a markdown file — its content is prefilled into the new prompt as context.
- **Folder toolbar settings**: Floating folder-panel settings now live in its toolbar, with a cloud-sync popover and automatic floating-mode fallback.
- **Notebooks/Recents hide controls**: Corner buttons to hide Notebooks and Recents are back, plus a new corner-swap toggle to switch which section the folder panel anchors above.

### Fixes

- **Gemini 2026 model picker**: The default-model lock recognizes the redesigned model picker overlay so the menu stops flickering open and closed.
- **Sidebar auto-hide on Gemini 2026**: Auto-hide now finds the redesigned collapse button instead of bailing out.
- **Folder panel placement**: Folder panel reliably stays above Recents through Gemini's re-renders.
- **Collapsed-sidebar leak**: Our gems list and folder UI no longer protrude past the collapsed sidebar rail.
- **Keyboard shortcuts vs IME**: Shortcuts no longer fire during IME composition or inside editable inputs.
- **Cloud sync overwrite safety**: Cloud overwrite is blocked when no local folder backup exists yet.
- **Markdown-upload fork prefill**: Uploading a markdown file in the fork flow correctly prefills the context prompt.

<!-- lang:zh -->

**重要更新，建议花一分钟浏览。** Gemini 网页端刚完成一次大改版，本次更新已将整个扩展重新适配到新布局（侧边栏、模型选择器、文件夹面板、Gems 入口），确保你现有的所有设置在新界面下继续可用。下方修复列表对应过去 24 小时收到的真实反馈——如果还有问题，下一个补丁会很快跟进。

### 新功能

- **侧边栏最近 Gems 列表**：将侧边栏中原生的 Gems 入口展开为最近使用过的 gems 列表，一键直达。
- **思考级别锁定**：默认模型设置现在还会记忆并自动应用你偏好的思考级别（标准 / 增强）。
- **输入框光晕开关** *（默认关闭）*：隐藏 Gemini 输入框背后的蓝色径向渐变光晕。
- **Markdown 上传分叉**：通过上传 markdown 文件开启新的对话分叉，文件内容会作为上下文自动填入新提示词。
- **文件夹工具栏设置**：浮动文件夹面板的设置移至其工具栏，新增云同步弹窗与浮动模式自动回退。
- **Notebooks / Recents 隐藏控件**：恢复了角落里隐藏 Notebooks 与 Recents 的按钮，并新增角落切换开关以选择文件夹面板锚定在哪个区域之上。

### 修复

- **Gemini 2026 模型选择器**：默认模型锁定能识别改版后的模型选择浮层，菜单不再反复闪烁开关。
- **Gemini 2026 侧边栏自动隐藏**：自动隐藏可正确找到改版后的折叠按钮，不再失效。
- **文件夹面板位置**：在 Gemini 重新渲染时，文件夹面板能稳定保持在 Recents 之上。
- **侧边栏收起漏出**：收起侧边栏时，我们注入的 gems 列表和文件夹 UI 不再越过侧边栏边界露出。
- **快捷键与输入法**：在中文输入法编辑状态或可编辑输入框中，快捷键不再误触发。
- **云同步覆盖保护**：本地尚无文件夹备份时，云端覆盖会被阻止。
- **Markdown 上传分叉预填**：分叉流程中上传 markdown 文件可正确预填上下文提示词。

<!-- lang:zh_TW -->

**重要更新，建議花一分鐘瀏覽。** Gemini 網頁端剛完成一次大改版，本次更新已將整個擴充功能重新適配到新版面（側邊欄、模型選擇器、資料夾面板、Gems 入口），確保你現有的所有設定在新介面下繼續可用。下方修復列表對應過去 24 小時收到的真實回報——如果還有問題，下一個修補檔會很快跟進。

### 新功能

- **側邊欄最近 Gems 列表**：將側邊欄中原生的 Gems 入口展開為最近使用過的 gems 列表，一鍵直達。
- **思考級別鎖定**：預設模型設定現在還會記憶並自動套用你偏好的思考級別（標準 / 增強）。
- **輸入框光暈開關** *（預設關閉）*：隱藏 Gemini 輸入框背後的藍色徑向漸層光暈。
- **Markdown 上傳分叉**：透過上傳 markdown 檔案開啟新的對話分叉，檔案內容會作為上下文自動填入新提示詞。
- **資料夾工具列設定**：浮動資料夾面板的設定移至其工具列，新增雲端同步彈窗與浮動模式自動回退。
- **Notebooks / Recents 隱藏控制項**：恢復了角落隱藏 Notebooks 與 Recents 的按鈕，並新增角落切換開關以選擇資料夾面板錨定在哪個區域之上。

### 修復

- **Gemini 2026 模型選擇器**：預設模型鎖定能辨識改版後的模型選擇浮層，選單不再反覆閃爍開關。
- **Gemini 2026 側邊欄自動隱藏**：自動隱藏可正確找到改版後的摺疊按鈕，不再失效。
- **資料夾面板位置**：在 Gemini 重新渲染時，資料夾面板能穩定保持在 Recents 之上。
- **側邊欄收合漏出**：收合側邊欄時，我們注入的 gems 列表和資料夾 UI 不再越過側邊欄邊界露出。
- **快速鍵與輸入法**：在中文輸入法編輯狀態或可編輯輸入框中，快速鍵不再誤觸發。
- **雲端同步覆寫保護**：本機尚無資料夾備份時，雲端覆寫會被阻止。
- **Markdown 上傳分叉預填**：分叉流程中上傳 markdown 檔案可正確預填上下文提示詞。

<!-- lang:ja -->

**重要なアップデートです。さっとでも目を通してください。** Gemini のウェブ UI が大幅にリデザインされたため、本リリースでは拡張機能全体を新レイアウト（サイドバー、モデルピッカー、フォルダパネル、Gems エントリ）に作り直し、既存の設定が新しい見た目でもそのまま動作するようにしています。下記の修正は過去 24 時間に寄せられた実際のレポートに対応したもので、まだ動作しない箇所があれば速やかにフォローアップを予定しています。

### 新機能

- **サイドバーの最近の Gems リスト**：サイドバー内のネイティブ Gems エントリを最近使った gems のリストに展開し、ワンクリックでアクセスできます。
- **思考レベルのロック**：既定モデル設定が、お好みの思考レベル（標準 / 拡張）も記憶し、自動で再適用します。
- **入力欄の光暈トグル** *（既定で無効）*：Gemini チャット入力欄の背後にある青いラジアルグラデーションを非表示にします。
- **Markdown アップロードによる分岐**：markdown ファイルをアップロードして新しい分岐を開始でき、内容がコンテキストとして新しいプロンプトに自動入力されます。
- **フォルダのツールバー設定**：フローティングフォルダパネルの設定がツールバーに移動し、クラウド同期ポップオーバーとフローティングモードの自動フォールバックを追加しました。
- **Notebooks / Recents 非表示コントロール**：Notebooks と Recents を非表示にするコーナーボタンを復活、フォルダパネルがどちらの上にアンカーするかを切り替えるコーナースワップを追加しました。

### 修正

- **Gemini 2026 モデルピッカー**：既定モデルロックが刷新されたモデル選択オーバーレイを認識し、メニューが開閉を繰り返してちらつく問題を解消しました。
- **Gemini 2026 サイドバー自動折りたたみ**：刷新された折りたたみボタンを検出できるようになり、自動折りたたみが復活しました。
- **フォルダパネルの配置**：Gemini の再描画後もフォルダパネルが Recents の上に安定して表示されます。
- **サイドバー折りたたみ時のはみ出し**：サイドバーを折りたたんだ際、注入した gems リストとフォルダ UI がレールからはみ出さなくなりました。
- **キーボードショートカットと IME**：IME 入力中や編集可能な入力欄内ではショートカットが発動しなくなりました。
- **クラウド同期の上書き保護**：ローカルのフォルダバックアップがまだない場合、クラウド上書きをブロックします。
- **Markdown アップロード分岐の事前入力**：分岐フローで markdown ファイルをアップロードすると、コンテキストプロンプトが正しく事前入力されます。

<!-- lang:fr -->

**Mise à jour importante — prenez une minute pour la parcourir.** L'interface web de Gemini vient de recevoir une refonte majeure, et cette version reconstruit toute l'extension pour la nouvelle disposition (barre latérale, sélecteur de modèle, panneau de dossiers, entrée Gems) afin que votre configuration existante continue de fonctionner. Les correctifs ci-dessous répondent à des rapports réels reçus ces dernières 24 heures — si quelque chose reste cassé, un suivi rapide est à prévoir.

### Nouveautés

- **Liste des Gems récents dans la barre latérale** : L'entrée Gems native s'étend en une liste de vos gems récents accessible en un clic.
- **Verrouillage du niveau de réflexion** : Le réglage de modèle par défaut mémorise et réapplique aussi votre niveau de réflexion préféré (Standard / Étendu).
- **Bouton de masquage du halo de saisie** *(désactivé par défaut)* : Masque le halo bleu en dégradé radial derrière le champ de saisie de Gemini.
- **Fork via téléversement Markdown** : Démarrez un nouveau fork en téléversant un fichier markdown — son contenu est pré-rempli comme contexte dans la nouvelle invite.
- **Réglages dans la barre d'outils du dossier** : Les réglages du panneau de dossier flottant passent dans sa barre d'outils, avec un menu de synchronisation cloud et un repli automatique en mode flottant.
- **Contrôles de masquage Notebooks / Recents** : Les boutons d'angle pour masquer Notebooks et Recents sont de retour, avec un nouveau bouton d'échange d'angle pour choisir la section au-dessus de laquelle le panneau de dossier s'ancre.

### Corrections

- **Sélecteur de modèle Gemini 2026** : Le verrouillage du modèle par défaut reconnaît la nouvelle superposition de sélection, le menu ne clignote plus en ouverture/fermeture.
- **Masquage automatique de la barre latérale sur Gemini 2026** : Le masquage automatique trouve désormais le nouveau bouton de réduction.
- **Placement du panneau de dossier** : Le panneau de dossier reste au-dessus de Recents même après les re-rendus de Gemini.
- **Débordement en barre latérale réduite** : Notre liste de gems et notre interface de dossiers ne dépassent plus du rail réduit.
- **Raccourcis clavier vs IME** : Les raccourcis ne se déclenchent plus pendant la saisie IME ni dans les champs éditables.
- **Sécurité d'écrasement de synchronisation cloud** : L'écrasement cloud est bloqué tant qu'aucune sauvegarde locale des dossiers n'existe.
- **Pré-remplissage du fork par téléversement Markdown** : Le téléversement d'un fichier markdown dans le flux de fork pré-remplit correctement l'invite contextuelle.

<!-- lang:es -->

**Actualización importante — dedícale un minuto.** La interfaz web de Gemini acaba de recibir un rediseño importante, y esta versión reconstruye toda la extensión para el nuevo diseño (barra lateral, selector de modelo, panel de carpetas, entrada Gems) para que tu configuración existente siga funcionando. Las correcciones siguientes responden a informes reales de las últimas 24 horas — si algo sigue roto, espera un parche rápido.

### Novedades

- **Lista de Gems recientes en la barra lateral**: La entrada nativa de Gems se expande en una lista de tus gems recientes con acceso de un clic.
- **Bloqueo del nivel de pensamiento**: El ajuste de modelo predeterminado también recuerda y reaplica tu nivel de pensamiento preferido (Estándar / Extendido).
- **Interruptor del halo del cuadro de entrada** *(desactivado por defecto)*: Oculta el halo azul de degradado radial detrás del cuadro de entrada de Gemini.
- **Fork por subida de Markdown**: Inicia un nuevo fork subiendo un archivo markdown — su contenido se rellena automáticamente como contexto en el nuevo mensaje.
- **Ajustes en la barra de herramientas de carpetas**: Los ajustes del panel flotante de carpetas se trasladan a su barra de herramientas, con un popover de sincronización en la nube y respaldo automático al modo flotante.
- **Controles para ocultar Notebooks / Recents**: Vuelven los botones de esquina para ocultar Notebooks y Recents, además de un nuevo intercambio de esquina para elegir sobre qué sección se ancla el panel de carpetas.

### Correcciones

- **Selector de modelo en Gemini 2026**: El bloqueo del modelo predeterminado reconoce la nueva capa del selector y el menú deja de parpadear abriéndose y cerrándose.
- **Ocultación automática de la barra lateral en Gemini 2026**: La ocultación automática encuentra el nuevo botón de plegado.
- **Posición del panel de carpetas**: El panel de carpetas se mantiene fiablemente sobre Recents tras los re-renderizados de Gemini.
- **Fuga de la barra lateral colapsada**: Nuestra lista de gems y la interfaz de carpetas dejan de sobresalir del riel colapsado.
- **Atajos de teclado vs IME**: Los atajos ya no se disparan durante la composición IME ni dentro de campos editables.
- **Seguridad de sobrescritura en la nube**: La sobrescritura en la nube se bloquea cuando aún no existe una copia local de carpetas.
- **Prerelleno del fork por subida de Markdown**: Subir un archivo markdown en el flujo de fork rellena correctamente el mensaje de contexto.

<!-- lang:pt -->

**Atualização importante — dedique um minuto para ler.** A interface web do Gemini acaba de receber uma reformulação importante, e esta versão reconstrói toda a extensão para o novo layout (barra lateral, seletor de modelo, painel de pastas, entrada Gems) para que sua configuração existente continue funcionando. As correções abaixo respondem a relatos reais das últimas 24 horas — se algo ainda estiver quebrado, espere uma correção rápida.

### Novidades

- **Lista de Gems recentes na barra lateral**: A entrada nativa de Gems expande para uma lista de seus gems recentes com acesso em um clique.
- **Bloqueio do nível de raciocínio**: A configuração de modelo padrão agora também lembra e reaplica o seu nível de raciocínio preferido (Padrão / Estendido).
- **Interruptor do halo do campo de entrada** *(desativado por padrão)*: Oculta o halo azul de gradiente radial atrás do campo de entrada do Gemini.
- **Fork por upload de Markdown**: Inicie um novo fork enviando um arquivo markdown — o conteúdo é pré-preenchido como contexto no novo prompt.
- **Configurações na barra de ferramentas de pastas**: As configurações do painel flutuante de pastas vão para a sua barra de ferramentas, com um popover de sincronização na nuvem e fallback automático para modo flutuante.
- **Controles para ocultar Notebooks / Recents**: Os botões de canto para ocultar Notebooks e Recents voltaram, mais um novo botão de troca para escolher acima de qual seção o painel de pastas se ancora.

### Correções

- **Seletor de modelo no Gemini 2026**: O bloqueio de modelo padrão reconhece a nova sobreposição do seletor e o menu deixa de piscar abrindo e fechando.
- **Ocultação automática da barra lateral no Gemini 2026**: A ocultação automática encontra o novo botão de recolhimento.
- **Posição do painel de pastas**: O painel de pastas permanece de forma confiável acima de Recents após as re-renderizações do Gemini.
- **Vazamento da barra lateral recolhida**: Nossa lista de gems e a UI de pastas não ultrapassam mais o trilho recolhido.
- **Atalhos de teclado vs IME**: Os atalhos não são acionados durante a composição IME nem em campos editáveis.
- **Segurança de sobrescrita na nuvem**: A sobrescrita na nuvem é bloqueada quando ainda não existe um backup local de pastas.
- **Pré-preenchimento do fork por upload de Markdown**: O upload de um arquivo markdown no fluxo de fork preenche corretamente o prompt de contexto.

<!-- lang:ar -->

**تحديث مهم — يُرجى تخصيص دقيقة لتصفّحه.** تلقّى تصميم واجهة الويب لـ Gemini تحديثًا كبيرًا، وتُعيد هذه الإصدارة بناء الإضافة بأكملها للتخطيط الجديد (الشريط الجانبي، ومنتقي النماذج، ولوحة المجلدات، وإدخالة Gems) لتظل إعداداتك الحالية تعمل. تستجيب الإصلاحات أدناه لتقارير فعلية وردت خلال آخر 24 ساعة — إن بقي شيء معطوبًا، فالتحديث التالي قادم سريعًا.

### الجديد

- **قائمة Gems الحديثة في الشريط الجانبي**: تتحول إدخالة Gems الأصلية إلى قائمة بـ gems الأخيرة للوصول بنقرة واحدة.
- **قفل مستوى التفكير**: يتذكر إعداد النموذج الافتراضي أيضًا مستوى التفكير المفضّل (Standard / Extended) ويعيد تطبيقه تلقائيًا.
- **مفتاح إخفاء هالة مربع الإدخال** *(معطّل افتراضيًا)*: إخفاء الهالة الزرقاء المتدرجة شعاعيًا خلف مربع إدخال محادثة Gemini.
- **التفرّع عبر رفع Markdown**: ابدأ تفرّعًا جديدًا برفع ملف markdown — يُملأ محتواه تلقائيًا كسياق في الموجّه الجديد.
- **إعدادات في شريط أدوات المجلدات**: تنتقل إعدادات لوحة المجلدات العائمة إلى شريط أدواتها، مع نافذة منبثقة لمزامنة السحابة وآلية رجوع تلقائية للوضع العائم.
- **عناصر تحكم لإخفاء Notebooks / Recents**: عادت أزرار الزوايا لإخفاء Notebooks و Recents، مع زر تبديل زاوية جديد لاختيار القسم الذي ترتبط فوقه لوحة المجلدات.

### الإصلاحات

- **منتقي النماذج في Gemini 2026**: يتعرّف قفل النموذج الافتراضي على طبقة المنتقي الجديدة، فلا تظل القائمة تتذبذب فتحًا وإغلاقًا.
- **الإخفاء التلقائي للشريط الجانبي في Gemini 2026**: يعثر الإخفاء التلقائي على زر الطي الجديد بدلًا من التعطّل.
- **موضع لوحة المجلدات**: تبقى لوحة المجلدات أعلى Recents بثبات بعد إعادة عرض Gemini.
- **تسرب الشريط الجانبي المطوي**: لم تعد قائمة gems وواجهة المجلدات تتجاوز شريط الطي.
- **اختصارات لوحة المفاتيح مع IME**: لم تعد الاختصارات تنطلق أثناء التركيب بـ IME أو داخل حقول قابلة للتحرير.
- **حماية الكتابة فوق السحابة**: تُحجب الكتابة فوق السحابة عند عدم وجود نسخة احتياطية محلية للمجلدات بعد.
- **التعبئة المسبقة لتفرّع Markdown**: يؤدي رفع ملف markdown في تدفق التفرّع إلى تعبئة موجّه السياق بشكل صحيح.

<!-- lang:ko -->

**중요 업데이트입니다 — 잠시 살펴봐 주세요.** Gemini의 웹 UI가 대대적으로 리디자인되었고, 이번 릴리스는 확장 프로그램 전체를 새 레이아웃(사이드바, 모델 선택기, 폴더 패널, Gems 항목)에 맞춰 다시 만들어, 기존 설정이 그대로 작동하도록 했습니다. 아래 수정 사항은 지난 24시간 내 실제 제보에 대응한 것이며, 여전히 문제가 있다면 곧 후속 패치가 나옵니다.

### 새로운 기능

- **사이드바 최근 Gems 목록**: 사이드바의 기본 Gems 항목을 최근 사용한 gems 목록으로 확장하여 한 번의 클릭으로 접근합니다.
- **사고 수준 잠금**: 기본 모델 설정이 선호하는 사고 수준(Standard / Extended)도 기억하고 자동으로 다시 적용합니다.
- **입력창 광채 토글** *(기본 꺼짐)*: Gemini 채팅 입력창 뒤의 파란색 방사형 그라데이션 광채를 숨깁니다.
- **Markdown 업로드 포크**: markdown 파일을 업로드해 새 포크를 시작하면, 그 내용이 새 프롬프트의 컨텍스트로 미리 채워집니다.
- **폴더 툴바 설정**: 떠다니는 폴더 패널의 설정이 툴바로 이동하고, 클라우드 동기화 팝오버와 떠다니기 모드 자동 폴백이 추가됩니다.
- **Notebooks / Recents 숨기기 컨트롤**: Notebooks와 Recents를 숨기는 코너 버튼이 돌아왔고, 폴더 패널이 어느 섹션 위에 고정될지 바꾸는 코너 스왑 토글이 추가되었습니다.

### 수정

- **Gemini 2026 모델 선택기**: 기본 모델 잠금이 새로 디자인된 모델 선택기 오버레이를 인식하여 메뉴가 열리고 닫히는 깜빡임이 사라졌습니다.
- **Gemini 2026 사이드바 자동 숨김**: 자동 숨김이 새 접기 버튼을 정상적으로 찾습니다.
- **폴더 패널 위치**: Gemini 재렌더링 후에도 폴더 패널이 안정적으로 Recents 위에 유지됩니다.
- **사이드바 접힘 누출**: 사이드바를 접었을 때, 주입된 gems 목록과 폴더 UI가 더 이상 접힘 레일 밖으로 비어져 나오지 않습니다.
- **키보드 단축키 대 IME**: IME 입력 중이거나 편집 가능한 입력란 내부에서는 단축키가 발동되지 않습니다.
- **클라우드 동기화 덮어쓰기 보호**: 로컬 폴더 백업이 아직 없을 때 클라우드 덮어쓰기를 차단합니다.
- **Markdown 업로드 포크 미리 채움**: 포크 흐름에서 markdown 파일을 업로드하면 컨텍스트 프롬프트가 올바르게 미리 채워집니다.

<!-- lang:ru -->

**Важное обновление — пожалуйста, уделите минуту.** Веб-интерфейс Gemini получил крупный редизайн, и этот релиз заново собирает всё расширение под новую раскладку (боковая панель, выбор модели, панель папок, пункт Gems), чтобы ваши текущие настройки продолжали работать. Исправления ниже отвечают на реальные сообщения за последние 24 часа — если что-то по-прежнему сломано, патч выйдет быстро.

### Новое

- **Список недавних Gems в боковой панели**: Нативный пункт Gems разворачивается в список недавно использованных gems с переходом в один клик.
- **Блокировка уровня мышления**: Настройка модели по умолчанию теперь также запоминает и автоматически применяет ваш предпочтительный уровень мышления (Standard / Extended).
- **Переключатель ореола поля ввода** *(выключен по умолчанию)*: Скрывает синий радиально-градиентный ореол за полем ввода чата Gemini.
- **Форк через загрузку Markdown**: Начните новый форк, загрузив markdown-файл — его содержимое автоматически подставляется как контекст в новый запрос.
- **Настройки в панели инструментов папок**: Настройки плавающей панели папок переезжают в её панель инструментов, добавлены попап облачной синхронизации и автоматический откат к плавающему режиму.
- **Элементы скрытия Notebooks / Recents**: Угловые кнопки для скрытия Notebooks и Recents вернулись, плюс новый переключатель угла, чтобы выбрать, над какой секцией закрепляется панель папок.

### Исправления

- **Выбор модели в Gemini 2026**: Блокировка модели по умолчанию распознаёт обновлённый оверлей выбора, и меню больше не мерцает открытием и закрытием.
- **Автоскрытие боковой панели в Gemini 2026**: Автоскрытие находит новую кнопку сворачивания вместо отказа.
- **Положение панели папок**: Панель папок надёжно остаётся над Recents после перерисовок Gemini.
- **Утечка свёрнутой боковой панели**: Внедрённый список gems и интерфейс папок больше не выходят за пределы свёрнутого рельса.
- **Горячие клавиши и IME**: Горячие клавиши не срабатывают во время ввода через IME или внутри редактируемых полей.
- **Защита от перезаписи в облаке**: Облачная перезапись блокируется, пока нет локального резервного копирования папок.
- **Предзаполнение форка при загрузке Markdown**: Загрузка markdown-файла в потоке форка корректно заполняет контекстный запрос.
`;export{e as default};
