const e=`<!-- lang:en -->

### What's New

- **AI Studio Master Toggle**: Quickly enable or disable all AI Studio features from the popup.
- **Sidebar Left-Edge Hover Trigger**: Hover near the left edge of the screen to reveal a fully hidden sidebar.
- **Timeline Edge-Drag Resize**: Drag the edge of the timeline bar to resize its background width.
- **Dark Mode Circle Transition**: Smooth circle-expand animation when toggling dark mode in the popup.

### Bug Fixes

- Fixed width adjusters not auto-enabling for upgrading users.
- Fixed LaTeX syntax being stripped when quoting math equations in replies.
- Fixed sidebar full-hide and auto-collapse state not syncing correctly.
- Fixed missing storage default for sidebar full-hide toggle.
- Fixed export dropdown disappearing on hover.
- Fixed star button being injected into non-model menus.
- Fixed font rendering inconsistency in fork and timeline by using explicit sans-serif font stack.
- Fixed accidental click firing after dragging the prompt trigger button.
- Fixed pointer-events blocking interaction in content area.

<!-- lang:zh -->

### 新功能

- **AI Studio 总开关**：在弹窗中一键启用或禁用所有 AI Studio 功能。
- **侧边栏左侧悬停触发**：鼠标悬停在屏幕左边缘即可唤出完全隐藏的侧边栏。
- **时间线边缘拖拽调整**：拖拽时间线栏的边缘来调整背景宽度。
- **暗色模式圆形过渡**：在弹窗中切换暗色模式时的平滑圆形展开动画。

### Bug 修复

- 修复升级用户的宽度调节器未自动启用的问题。
- 修复引用数学公式回复时 LaTeX 语法被移除的问题。
- 修复侧边栏完全隐藏与自动折叠状态不同步的问题。
- 修复侧边栏完全隐藏开关缺少默认存储值的问题。
- 修复导出下拉菜单在悬停时消失的问题。
- 修复星标按钮被注入到非模型菜单中的问题。
- 修复 Fork 和时间线中字体渲染不一致的问题。
- 修复拖拽提示词触发按钮后误触发点击的问题。
- 修复内容区域 pointer-events 阻止交互的问题。

<!-- lang:zh_TW -->

### 新功能

- **AI Studio 總開關**：在彈窗中一鍵啟用或停用所有 AI Studio 功能。
- **側邊欄左側懸停觸發**：滑鼠懸停在螢幕左邊緣即可喚出完全隱藏的側邊欄。
- **時間線邊緣拖曳調整**：拖曳時間線列的邊緣來調整背景寬度。
- **暗色模式圓形過渡**：在彈窗中切換暗色模式時的平滑圓形展開動畫。

### Bug 修復

- 修復升級使用者的寬度調節器未自動啟用的問題。
- 修復引用數學公式回覆時 LaTeX 語法被移除的問題。
- 修復側邊欄完全隱藏與自動摺疊狀態不同步的問題。
- 修復側邊欄完全隱藏開關缺少預設儲存值的問題。
- 修復匯出下拉選單在懸停時消失的問題。
- 修復星標按鈕被注入到非模型選單中的問題。
- 修復 Fork 和時間線中字型渲染不一致的問題。
- 修復拖曳提示詞觸發按鈕後誤觸發點擊的問題。
- 修復內容區域 pointer-events 阻止互動的問題。

<!-- lang:ja -->

### 新機能

- **AI Studio マスタートグル**：ポップアップからすべての AI Studio 機能をまとめて有効/無効化。
- **サイドバー左端ホバートリガー**：画面左端にホバーして完全に非表示のサイドバーを表示。
- **タイムラインエッジドラッグリサイズ**：タイムラインバーの端をドラッグして背景幅を調整。
- **ダークモード円形トランジション**：ポップアップでダークモードを切り替える際のスムーズな円形展開アニメーション。

### バグ修正

- アップグレードユーザーの幅調整機能が自動有効化されない問題を修正。
- 数式を引用返信する際に LaTeX 構文が除去される問題を修正。
- サイドバーの完全非表示と自動折りたたみの状態が同期しない問題を修正。
- サイドバー完全非表示トグルのストレージデフォルト値が欠落している問題を修正。
- エクスポートドロップダウンがホバー時に消える問題を修正。
- 星ボタンがモデル以外のメニューに挿入される問題を修正。
- Fork とタイムラインのフォントレンダリングの不一致を修正。
- プロンプトトリガーボタンのドラッグ後に誤クリックが発生する問題を修正。
- コンテンツエリアの pointer-events がインタラクションをブロックする問題を修正。

<!-- lang:fr -->

### Nouveautes

- **Interrupteur global AI Studio** : Activez ou desactivez toutes les fonctionnalites AI Studio depuis le popup.
- **Declencheur par survol du bord gauche** : Survolez le bord gauche de l'ecran pour reveler la barre laterale completement masquee.
- **Redimensionnement par glissement du bord de la timeline** : Faites glisser le bord de la barre de timeline pour ajuster sa largeur.
- **Transition circulaire du mode sombre** : Animation d'expansion circulaire fluide lors du basculement du mode sombre dans le popup.

### Corrections de bugs

- Correction des ajusteurs de largeur non actives automatiquement pour les utilisateurs en mise a jour.
- Correction de la syntaxe LaTeX supprimee lors de la citation de formules mathematiques.
- Correction de la desynchronisation entre le masquage complet et la reduction automatique de la barre laterale.
- Correction de la valeur par defaut manquante pour le bouton de masquage complet de la barre laterale.
- Correction du menu deroulant d'exportation qui disparaissait au survol.
- Correction du bouton etoile injecte dans des menus non lies aux modeles.
- Correction de l'incoherence du rendu des polices dans Fork et la timeline.
- Correction du clic accidentel apres le glissement du bouton declencheur de prompt.
- Correction des pointer-events bloquant l'interaction dans la zone de contenu.

<!-- lang:es -->

### Novedades

- **Interruptor general de AI Studio**: Activa o desactiva todas las funciones de AI Studio desde el popup.
- **Activacion por hover en el borde izquierdo**: Pasa el raton por el borde izquierdo de la pantalla para mostrar la barra lateral completamente oculta.
- **Redimensionar timeline arrastrando el borde**: Arrastra el borde de la barra de timeline para ajustar su ancho.
- **Transicion circular del modo oscuro**: Animacion de expansion circular suave al alternar el modo oscuro en el popup.

### Correcciones de errores

- Corregido que los ajustadores de ancho no se activaban automaticamente para usuarios en actualizacion.
- Corregida la sintaxis LaTeX eliminada al citar ecuaciones matematicas en respuestas.
- Corregida la desincronizacion entre el ocultamiento completo y la reduccion automatica de la barra lateral.
- Corregido el valor predeterminado faltante para el boton de ocultamiento completo de la barra lateral.
- Corregido el menu desplegable de exportacion que desaparecia al pasar el raton.
- Corregido el boton de estrella inyectado en menus no relacionados con modelos.
- Corregida la inconsistencia en el renderizado de fuentes en Fork y la timeline.
- Corregido el clic accidental al soltar el boton de activacion de prompts despues de arrastrarlo.
- Corregidos los pointer-events que bloqueaban la interaccion en el area de contenido.

<!-- lang:pt -->

### Novidades

- **Interruptor geral do AI Studio**: Ative ou desative todas as funcionalidades do AI Studio a partir do popup.
- **Ativacao por hover na borda esquerda**: Passe o rato pela borda esquerda do ecra para revelar a barra lateral completamente oculta.
- **Redimensionar timeline arrastando a borda**: Arraste a borda da barra de timeline para ajustar a sua largura.
- **Transicao circular do modo escuro**: Animacao de expansao circular suave ao alternar o modo escuro no popup.

### Correcoes de bugs

- Corrigido os ajustadores de largura nao ativados automaticamente para utilizadores em atualizacao.
- Corrigida a sintaxe LaTeX removida ao citar equacoes matematicas nas respostas.
- Corrigida a dessincronizacao entre o ocultamento completo e a reducao automatica da barra lateral.
- Corrigido o valor padrao em falta para o botao de ocultamento completo da barra lateral.
- Corrigido o menu suspenso de exportacao que desaparecia ao passar o rato.
- Corrigido o botao de estrela injetado em menus nao relacionados com modelos.
- Corrigida a inconsistencia no renderizado de fontes no Fork e na timeline.
- Corrigido o clique acidental apos arrastar o botao de ativacao de prompts.
- Corrigidos os pointer-events que bloqueavam a interacao na area de conteudo.

<!-- lang:ar -->

### الجديد

- **مفتاح رئيسي لـ AI Studio**: تفعيل أو تعطيل جميع ميزات AI Studio من النافذة المنبثقة.
- **تشغيل الشريط الجانبي بالتمرير على الحافة اليسرى**: مرر الماوس بالقرب من حافة الشاشة اليسرى لإظهار الشريط الجانبي المخفي بالكامل.
- **تغيير حجم شريط الجدول الزمني بالسحب**: اسحب حافة شريط الجدول الزمني لتغيير عرض الخلفية.
- **انتقال دائري للوضع الداكن**: رسوم متحركة سلسة بتوسع دائري عند تبديل الوضع الداكن في النافذة المنبثقة.

### إصلاحات الأخطاء

- إصلاح عدم تفعيل ضبط العرض تلقائياً للمستخدمين المحدّثين.
- إصلاح إزالة صيغة LaTeX عند اقتباس المعادلات الرياضية في الردود.
- إصلاح عدم مزامنة حالة الإخفاء الكامل والطي التلقائي للشريط الجانبي.
- إصلاح القيمة الافتراضية المفقودة لمفتاح الإخفاء الكامل للشريط الجانبي.
- إصلاح اختفاء قائمة التصدير المنسدلة عند التمرير.
- إصلاح حقن زر النجمة في قوائم غير متعلقة بالنماذج.
- إصلاح عدم تناسق عرض الخطوط في Fork والجدول الزمني.
- إصلاح النقر العرضي بعد سحب زر تشغيل الأوامر.
- إصلاح pointer-events التي تمنع التفاعل في منطقة المحتوى.

<!-- lang:ru -->

### Что нового

- **Главный переключатель AI Studio**: Быстро включайте или отключайте все функции AI Studio из всплывающего окна.
- **Триггер при наведении на левый край**: Наведите курсор на левый край экрана, чтобы показать полностью скрытую боковую панель.
- **Изменение ширины таймлайна перетаскиванием**: Перетащите край полосы таймлайна для изменения ширины фона.
- **Круговой переход тёмного режима**: Плавная анимация кругового расширения при переключении тёмного режима.

### Исправление ошибок

- Исправлено автоматическое включение регуляторов ширины для обновляющихся пользователей.
- Исправлено удаление синтаксиса LaTeX при цитировании математических формул.
- Исправлена рассинхронизация полного скрытия и автосворачивания боковой панели.
- Исправлено отсутствие значения по умолчанию для переключателя полного скрытия боковой панели.
- Исправлено исчезновение выпадающего меню экспорта при наведении.
- Исправлена вставка кнопки-звёздочки в меню, не связанные с моделями.
- Исправлена несогласованность отображения шрифтов в Fork и таймлайне.
- Исправлен случайный клик после перетаскивания кнопки-триггера промпта.
- Исправлена блокировка взаимодействия pointer-events в области контента.

<!-- lang:ko -->

### 새로운 기능

- **AI Studio 마스터 토글**: 팝업에서 모든 AI Studio 기능을 한 번에 활성화/비활성화.
- **사이드바 왼쪽 가장자리 호버 트리거**: 화면 왼쪽 가장자리에 마우스를 올려 완전히 숨겨진 사이드바를 표시.
- **타임라인 가장자리 드래그 크기 조절**: 타임라인 바의 가장자리를 드래그하여 배경 너비를 조절.
- **다크 모드 원형 전환**: 팝업에서 다크 모드를 전환할 때 부드러운 원형 확장 애니메이션.

### 버그 수정

- 업그레이드 사용자의 너비 조절기가 자동 활성화되지 않는 문제 수정.
- 수학 공식을 인용 답변할 때 LaTeX 구문이 제거되는 문제 수정.
- 사이드바 완전 숨김과 자동 접기 상태가 동기화되지 않는 문제 수정.
- 사이드바 완전 숨김 토글의 기본 저장 값이 누락된 문제 수정.
- 내보내기 드롭다운이 호버 시 사라지는 문제 수정.
- 별표 버튼이 모델과 무관한 메뉴에 삽입되는 문제 수정.
- Fork 및 타임라인의 폰트 렌더링 불일치 수정.
- 프롬프트 트리거 버튼 드래그 후 의도치 않은 클릭이 발생하는 문제 수정.
- 콘텐츠 영역의 pointer-events 가 상호작용을 차단하는 문제 수정.
`;export{e as default};
