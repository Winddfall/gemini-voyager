const e=`<!-- lang:en -->

### What's New

- **Highlight color palette**: Gemini highlights now have five customizable color slots, live-preview the color on your selected text as you edit, and a toggle to show or hide highlight markers on the timeline.
- **Center ChatGPT conversation** *(off by default)*: The ChatGPT "Comfortable Reading Width" plugin adds a "Center conversation content" option that centers your own messages while assistant replies stay left-aligned, keeping your chosen width.
- **Visual effects on authorized sites** *(off by default)*: Snow, rain, and sakura effects can now run on third-party sites you've authorized, not just Gemini.
- **Storage usage warning**: A prompt now appears when the extension's storage nears its limit, so you can review and clean up in time.
- **Refreshed Saved Library**: The Saved Library popup has a cleaner look, with count badges on the filter tabs and a larger search field.

### Fixes

- **Manual folder ordering**: Fixed drag-to-sort no longer working inside folders and conversations jumping to the top when opened; Folder settings also gain a synced "Manual / Recently opened" sort choice.
- **Personalization across devices**: Cloud Sync now carries your installed plugins and their settings, plus many more preferences (folder, timeline, prompt, input, export), and no longer re-triggers onboarding on a synced device.
- **Onboarding as a guided tour**: Feature guides now play back-to-back as one tour with 1/N progress and a "Next" button, and folder settings stay usable after the sorting guide.
- **Highlight account scope**: Fixed highlights being misfiled under a temporary account on multi-account setups, and the Saved Library now shows a clear error instead of appearing empty when loading fails.
- **Prompt manager layering**: Fixed the prompt manager being hidden behind the floating usage bar and unclickable.
- **Smoother ChatGPT plugin enable**: Enabling the ChatGPT reading-width plugin now requests permission only for the site you're on and turns on in a single click.
- **Timeline compact preview**: Fixed the preview panel in compact view not closing when tapped again.

---

> *"Colour is a power which directly influences the soul." — Wassily Kandinsky, Concerning the Spiritual in Art*

<!-- lang:zh -->

### 新功能

- **高亮调色板**：Gemini 高亮新增 5 个可自定义的颜色槽，编辑颜色时会实时预览选中文字的效果，还能在时间线上显示或隐藏高亮标记。
- **ChatGPT 居中对话** *（默认关闭）*：ChatGPT「舒适阅读宽度」插件新增「居中对话内容」开关，把你发送的消息居中，助手回复保持左对齐，阅读宽度不变。
- **视觉特效扩展到授权站点** *（默认关闭）*：雪、雨、樱花特效现在可以在你已授权的第三方站点运行，不再只限 Gemini。
- **存储用量提醒**：扩展存储接近上限时会弹出提示，提醒你及时查看和清理。
- **收藏库界面焕新**：收藏库弹窗界面焕新，筛选标签带数量徽标，搜索框更大更清爽。

### 修复

- **文件夹手动排序**：修复了文件夹内拖动排序失效、打开对话就被顶到最前的问题；文件夹设置里新增「手动 / 最近打开」排序选择，并跨设备同步。
- **跨设备个性化同步**：云同步现在会带上你安装的插件及其设置，以及更多偏好（文件夹、时间线、Prompt、输入、导出等），在新设备上也不会重复弹出新手引导。
- **新手引导连续播放**：功能引导现在会作为一个连续教程依次播放，带 1/N 进度和「下一步」按钮；排序引导结束后文件夹设置依然可以操作。
- **高亮账户归属**：修复了多账户下高亮被错误归到临时账户的问题，收藏库加载失败时也会明确提示而不是显示为空。
- **Prompt 管理器层级**：修复了 Prompt 管理器被浮动用量条盖住、点不到的问题。
- **ChatGPT 插件启用更顺畅**：启用 ChatGPT 阅读宽度插件时只为当前站点请求权限，一次点击即可开启。
- **时间线紧凑预览**：修复了紧凑视图下预览面板打开后再次点击无法关闭的问题。

---

> *「色彩是直接影响心灵的力量。」——瓦西里·康定斯基，《论艺术的精神》*

<!-- lang:zh_TW -->

### 新功能

- **重點調色盤**：Gemini 重點標註新增 5 個可自訂的顏色槽，編輯顏色時會即時預覽選取文字的效果，還能在時間軸上顯示或隱藏重點標記。
- **ChatGPT 置中對話** *（預設關閉）*：ChatGPT「舒適閱讀寬度」外掛新增「置中對話內容」開關，將你傳送的訊息置中，助手回覆維持靠左對齊，閱讀寬度不變。
- **視覺特效擴展到授權網站** *（預設關閉）*：雪、雨、櫻花特效現在可在你已授權的第三方網站執行，不再僅限 Gemini。
- **儲存用量提醒**：擴充功能儲存空間接近上限時會跳出提示，提醒你即時檢視與清理。
- **收藏庫介面煥新**：收藏庫彈出視窗介面煥新，篩選標籤帶數量徽章，搜尋框更大更清爽。

### 修復

- **資料夾手動排序**：修復了資料夾內拖曳排序失效、開啟對話就被頂到最前的問題；資料夾設定新增「手動 / 最近開啟」排序選擇，並跨裝置同步。
- **跨裝置個人化同步**：雲端同步現在會帶上你安裝的外掛及其設定，以及更多偏好（資料夾、時間軸、Prompt、輸入、匯出等），在新裝置上也不會重複跳出新手導覽。
- **新手導覽連續播放**：功能導覽現在會作為一個連續教學依序播放，帶 1/N 進度和「下一步」按鈕；排序導覽結束後資料夾設定依然可以操作。
- **重點帳戶歸屬**：修復了多帳戶下重點被錯誤歸到暫時帳戶的問題，收藏庫載入失敗時也會明確提示而不是顯示為空。
- **Prompt 管理器層級**：修復了 Prompt 管理器被浮動用量列蓋住、點不到的問題。
- **ChatGPT 外掛啟用更順暢**：啟用 ChatGPT 閱讀寬度外掛時只為目前網站要求權限，一次點擊即可開啟。
- **時間軸精簡預覽**：修復了精簡檢視下預覽面板開啟後再次點擊無法關閉的問題。

---

> *「色彩是直接影響心靈的力量。」——瓦西里·康丁斯基，《藝術中的精神》*

<!-- lang:ja -->

### 新機能

- **ハイライトのカラーパレット**：Gemini のハイライトに、カスタマイズできる 5 つのカラースロットを追加しました。色を編集すると選択中のテキストにその色がリアルタイムでプレビューされ、タイムライン上のハイライトマーカーの表示/非表示も切り替えられます。
- **ChatGPT の会話を中央寄せ** *（デフォルトはオフ）*：ChatGPT「快適な読みやすい幅」プラグインに「会話内容を中央寄せ」オプションを追加しました。自分のメッセージが中央に寄り、アシスタントの返信は左揃えのまま、選んだ幅も保たれます。
- **視覚エフェクトを許可したサイトでも** *（デフォルトはオフ）*：雪・雨・桜のエフェクトが、Gemini だけでなく、あなたが許可した外部サイトでも動くようになりました。
- **ストレージ使用量の警告**：拡張機能のストレージが上限に近づくと通知が表示され、早めに確認・整理できます。
- **保存ライブラリを刷新**：保存ライブラリのポップアップを刷新し、フィルタータブに件数バッジを追加、検索欄も大きくなりました。

### 修正

- **フォルダーの手動並べ替え**：フォルダー内のドラッグ並べ替えが効かない、会話を開くと先頭に移動してしまう問題を修正しました。フォルダー設定に「手動 / 最近開いた順」の並べ替え選択（デバイス間で同期）も追加しました。
- **デバイス間のパーソナライズ同期**：クラウド同期が、インストール済みプラグインとその設定に加え、より多くの設定（フォルダー、タイムライン、プロンプト、入力、エクスポートなど）を引き継ぐようになり、同期先のデバイスでオンボーディングが再表示されなくなりました。
- **オンボーディングをガイドツアーに**：機能ガイドが 1 つのツアーとして連続で再生され、1/N の進捗と「次へ」ボタンが付きました。並べ替えガイドの後もフォルダー設定を操作できます。
- **ハイライトのアカウント帰属**：複数アカウント環境でハイライトが一時アカウントに誤って振り分けられる問題を修正し、保存ライブラリの読み込みに失敗したときは空表示ではなく明確なエラーを表示するようにしました。
- **プロンプトマネージャーの重なり**：プロンプトマネージャーがフローティングの使用量バーに隠れてクリックできない問題を修正しました。
- **ChatGPT プラグインの有効化をスムーズに**：ChatGPT の読みやすい幅プラグインを有効にする際、今いるサイトの権限だけを要求し、ワンクリックでオンにできるようにしました。
- **タイムラインのコンパクトプレビュー**：コンパクト表示でプレビューパネルがもう一度タップしても閉じない問題を修正しました。

---

> *「色彩は、魂に直接働きかける力である。」——ワシリー・カンディンスキー、《芸術における精神的なもの》*

<!-- lang:fr -->

### Nouveautés

- **Palette de couleurs pour les surlignages** : Les surlignages de Gemini disposent désormais de cinq emplacements de couleur personnalisables, prévisualisent la couleur sur le texte sélectionné pendant que vous la modifiez, et offrent une option pour afficher ou masquer les marqueurs de surlignage sur la chronologie.
- **Centrer la conversation ChatGPT** *(désactivé par défaut)* : Le plugin ChatGPT « Largeur de lecture confortable » ajoute une option « Centrer le contenu de la conversation » qui centre vos propres messages tandis que les réponses de l'assistant restent alignées à gauche, en conservant la largeur choisie.
- **Effets visuels sur les sites autorisés** *(désactivé par défaut)* : Les effets de neige, de pluie et de sakura peuvent désormais s'afficher sur les sites tiers que vous avez autorisés, et plus seulement sur Gemini.
- **Alerte d'utilisation du stockage** : Une notification apparaît lorsque le stockage de l'extension approche de sa limite, pour vous permettre de vérifier et de nettoyer à temps.
- **Bibliothèque enregistrée repensée** : Le popup de la Bibliothèque enregistrée a une apparence plus nette, avec des badges de comptage sur les onglets de filtre et un champ de recherche plus grand.

### Corrections

- **Tri manuel des dossiers** : Correction du tri par glisser-déposer qui ne fonctionnait plus dans les dossiers et des conversations qui remontaient en haut à l'ouverture ; les paramètres de dossier gagnent aussi un choix de tri « Manuel / Récemment ouvert » synchronisé.
- **Personnalisation entre appareils** : La synchronisation cloud transporte désormais vos plugins installés et leurs réglages, ainsi que bien d'autres préférences (dossier, chronologie, prompt, saisie, export), et ne relance plus l'intégration sur un appareil synchronisé.
- **Intégration sous forme de visite guidée** : Les guides de fonctionnalités s'enchaînent désormais en une seule visite avec une progression 1/N et un bouton « Suivant », et les paramètres de dossier restent utilisables après le guide de tri.
- **Compte associé aux surlignages** : Correction des surlignages mal classés sous un compte temporaire sur les configurations multi-comptes ; la Bibliothèque enregistrée affiche désormais une erreur claire au lieu de paraître vide en cas d'échec de chargement.
- **Superposition du gestionnaire de prompts** : Correction du gestionnaire de prompts caché derrière la barre d'utilisation flottante et impossible à cliquer.
- **Activation du plugin ChatGPT plus fluide** : L'activation du plugin de largeur de lecture ChatGPT ne demande désormais l'autorisation que pour le site où vous êtes et s'active en un seul clic.
- **Aperçu compact de la chronologie** : Correction du panneau d'aperçu en vue compacte qui ne se fermait pas lorsqu'on le touchait à nouveau.

---

> *« La couleur est une force qui influence directement l'âme. » — Vassily Kandinsky, Du spirituel dans l'art*

<!-- lang:es -->

### Novedades

- **Paleta de colores para resaltados**: Los resaltados de Gemini ahora tienen cinco espacios de color personalizables, muestran una vista previa del color en el texto seleccionado mientras lo editas, y una opción para mostrar u ocultar los marcadores de resaltado en la línea de tiempo.
- **Centrar la conversación de ChatGPT** *(desactivado por defecto)*: El complemento «Ancho de lectura cómodo» de ChatGPT añade la opción «Centrar el contenido de la conversación», que centra tus propios mensajes mientras las respuestas del asistente permanecen alineadas a la izquierda, manteniendo el ancho elegido.
- **Efectos visuales en sitios autorizados** *(desactivado por defecto)*: Los efectos de nieve, lluvia y sakura ahora pueden ejecutarse en los sitios de terceros que hayas autorizado, no solo en Gemini.
- **Aviso de uso de almacenamiento**: Aparece un aviso cuando el almacenamiento de la extensión se acerca a su límite, para que puedas revisarlo y limpiarlo a tiempo.
- **Biblioteca guardada renovada**: El popup de la Biblioteca guardada tiene un aspecto más limpio, con insignias de recuento en las pestañas de filtro y un campo de búsqueda más grande.

### Correcciones

- **Ordenación manual de carpetas**: Se corrigió que la ordenación por arrastre dejara de funcionar dentro de las carpetas y que las conversaciones saltaran al principio al abrirlas; los ajustes de carpeta también incluyen una opción de orden «Manual / Abierto recientemente» sincronizada.
- **Personalización entre dispositivos**: La sincronización en la nube ahora lleva tus complementos instalados y sus ajustes, además de muchas más preferencias (carpeta, línea de tiempo, prompt, entrada, exportación), y ya no vuelve a mostrar la introducción en un dispositivo sincronizado.
- **Introducción como recorrido guiado**: Las guías de funciones ahora se reproducen seguidas como un solo recorrido con progreso 1/N y un botón «Siguiente», y los ajustes de carpeta siguen siendo utilizables tras la guía de ordenación.
- **Cuenta asociada a los resaltados**: Se corrigió que los resaltados se archivaran por error en una cuenta temporal en configuraciones con varias cuentas; la Biblioteca guardada ahora muestra un error claro en lugar de parecer vacía cuando falla la carga.
- **Superposición del gestor de prompts**: Se corrigió que el gestor de prompts quedara oculto tras la barra de uso flotante y no se pudiera pulsar.
- **Activación más fluida del complemento de ChatGPT**: Al activar el complemento de ancho de lectura de ChatGPT, ahora solo se solicita permiso para el sitio en el que estás y se activa con un solo clic.
- **Vista previa compacta de la línea de tiempo**: Se corrigió que el panel de vista previa en la vista compacta no se cerrara al tocarlo de nuevo.

---

> *« El color es una fuerza que influye directamente en el alma. » — Vasili Kandinsky, De lo espiritual en el arte*

<!-- lang:pt -->

### Novidades

- **Paleta de cores para destaques**: Os destaques do Gemini agora têm cinco espaços de cor personalizáveis, pré-visualizam a cor no texto selecionado enquanto você a edita, e oferecem uma opção para mostrar ou ocultar os marcadores de destaque na linha do tempo.
- **Centralizar a conversa do ChatGPT** *(desativado por padrão)*: O plugin «Largura de leitura confortável» do ChatGPT adiciona a opção «Centralizar o conteúdo da conversa», que centraliza suas próprias mensagens enquanto as respostas do assistente permanecem alinhadas à esquerda, mantendo a largura escolhida.
- **Efeitos visuais em sites autorizados** *(desativado por padrão)*: Os efeitos de neve, chuva e sakura agora podem funcionar nos sites de terceiros que você autorizou, não apenas no Gemini.
- **Aviso de uso de armazenamento**: Um aviso aparece quando o armazenamento da extensão se aproxima do limite, para que você possa revisar e limpar a tempo.
- **Biblioteca salva renovada**: O popup da Biblioteca salva tem uma aparência mais limpa, com selos de contagem nas abas de filtro e um campo de busca maior.

### Correções

- **Ordenação manual das pastas**: Corrigido o problema de a ordenação por arrastar deixar de funcionar dentro das pastas e de as conversas irem para o topo ao serem abertas; as configurações de pasta também ganham uma opção de ordem «Manual / Aberto recentemente» sincronizada.
- **Personalização entre dispositivos**: A sincronização na nuvem agora leva seus plugins instalados e suas configurações, além de muitas outras preferências (pasta, linha do tempo, prompt, entrada, exportação), e não exibe mais a introdução novamente em um dispositivo sincronizado.
- **Introdução como um tour guiado**: Os guias de recursos agora são reproduzidos em sequência como um único tour, com progresso 1/N e um botão «Próximo», e as configurações de pasta continuam utilizáveis após o guia de ordenação.
- **Conta associada aos destaques**: Corrigido o problema de os destaques serem arquivados por engano em uma conta temporária em configurações com várias contas; a Biblioteca salva agora mostra um erro claro em vez de parecer vazia quando o carregamento falha.
- **Sobreposição do gerenciador de prompts**: Corrigido o gerenciador de prompts ficar escondido atrás da barra de uso flutuante e não poder ser clicado.
- **Ativação mais fluida do plugin do ChatGPT**: Ao ativar o plugin de largura de leitura do ChatGPT, agora só é solicitada permissão para o site em que você está e ele é ativado com um único clique.
- **Prévia compacta da linha do tempo**: Corrigido o painel de prévia na visão compacta que não fechava ao ser tocado novamente.

---

> *« A cor é uma força que influencia diretamente a alma. » — Wassily Kandinsky, Do Espiritual na Arte*

<!-- lang:ar -->

### الجديد

- **لوحة ألوان للتمييزات**: أصبح لتمييزات Gemini الآن خمس خانات ألوان قابلة للتخصيص، مع معاينة مباشرة للون على النص المحدد أثناء تعديله، وخيار لإظهار أو إخفاء علامات التمييز على الخط الزمني.
- **توسيط محادثة ChatGPT** *(مُعطَّل افتراضيًا)*: تضيف إضافة «عرض قراءة مريح» في ChatGPT خيار «توسيط محتوى المحادثة» الذي يوسّط رسائلك بينما تبقى ردود المساعد محاذاةً لليسار، مع الحفاظ على العرض الذي اخترته.
- **المؤثرات البصرية على المواقع المصرَّح بها** *(مُعطَّل افتراضيًا)*: يمكن الآن تشغيل مؤثرات الثلج والمطر وأزهار الساكورا على مواقع الطرف الثالث التي صرّحت بها، وليس على Gemini فقط.
- **تنبيه استخدام التخزين**: يظهر تنبيه عندما يقترب تخزين الامتداد من حدّه الأقصى، لتتمكن من المراجعة والتنظيف في الوقت المناسب.
- **تجديد المكتبة المحفوظة**: أصبح مظهر نافذة المكتبة المحفوظة أوضح، مع شارات عدد على علامات تبويب التصفية وحقل بحث أكبر.

### الإصلاحات

- **الترتيب اليدوي للمجلدات**: تم إصلاح توقف الترتيب بالسحب داخل المجلدات وانتقال المحادثات إلى الأعلى عند فتحها؛ كما تحصل إعدادات المجلد على خيار ترتيب «يدوي / المفتوحة مؤخرًا» متزامن.
- **تزامن التخصيص عبر الأجهزة**: أصبحت المزامنة السحابية تنقل الآن الإضافات المثبّتة وإعداداتها، إضافةً إلى المزيد من التفضيلات (المجلد، الخط الزمني، الموجّه، الإدخال، التصدير)، ولم تعد تُعيد عرض الإعداد الأولي على جهاز متزامن.
- **الإعداد الأولي كجولة إرشادية**: تُعرض أدلة الميزات الآن تباعًا كجولة واحدة مع مؤشر تقدم 1/N وزر «التالي»، وتبقى إعدادات المجلد قابلة للاستخدام بعد دليل الترتيب.
- **الحساب المرتبط بالتمييزات**: تم إصلاح تصنيف التمييزات بالخطأ ضمن حساب مؤقت في الإعدادات متعددة الحسابات؛ وتعرض المكتبة المحفوظة الآن رسالة خطأ واضحة بدلًا من الظهور فارغة عند فشل التحميل.
- **تراكب مدير الموجّهات**: تم إصلاح اختفاء مدير الموجّهات خلف شريط الاستخدام العائم وتعذّر النقر عليه.
- **تفعيل أسلس لإضافة ChatGPT**: عند تفعيل إضافة عرض القراءة في ChatGPT، يُطلب الإذن الآن للموقع الذي تتصفحه فقط ويتم التفعيل بنقرة واحدة.
- **المعاينة المضغوطة للخط الزمني**: تم إصلاح عدم إغلاق لوحة المعاينة في العرض المضغوط عند النقر عليها مرة أخرى.

---

> *«اللون قوة تؤثر مباشرةً في الروح.» — فاسيلي كاندينسكي، 《حول الروحاني في الفن》*

<!-- lang:ko -->

### 새로운 기능

- **하이라이트 색상 팔레트**: Gemini 하이라이트에 사용자 지정 가능한 5개의 색상 슬롯이 추가되었고, 색상을 편집하는 동안 선택한 텍스트에 색상이 실시간으로 미리보기되며, 타임라인의 하이라이트 마커를 표시하거나 숨기는 옵션도 추가되었습니다.
- **ChatGPT 대화 가운데 정렬** *(기본값 꺼짐)*: ChatGPT '편안한 읽기 너비' 플러그인에 '대화 내용 가운데 정렬' 옵션이 추가되었습니다. 내가 보낸 메시지는 가운데로 정렬되고 어시스턴트 답변은 왼쪽 정렬을 유지하며, 선택한 너비도 그대로 유지됩니다.
- **허용한 사이트에서도 시각 효과** *(기본값 꺼짐)*: 눈, 비, 벚꽃 효과를 이제 Gemini뿐 아니라 사용자가 허용한 외부 사이트에서도 실행할 수 있습니다.
- **저장 공간 사용량 알림**: 확장 프로그램 저장 공간이 한도에 가까워지면 알림이 표시되어 제때 확인하고 정리할 수 있습니다.
- **저장 라이브러리 새 단장**: 저장 라이브러리 팝업이 더 깔끔해졌고, 필터 탭에 개수 배지가 추가되고 검색창이 더 커졌습니다.

### 수정

- **폴더 수동 정렬**: 폴더 안에서 드래그 정렬이 작동하지 않고 대화를 열면 맨 위로 올라가던 문제를 수정했습니다. 폴더 설정에는 기기 간 동기화되는 '수동 / 최근 연 순' 정렬 선택도 추가되었습니다.
- **기기 간 개인화 동기화**: 클라우드 동기화가 이제 설치한 플러그인과 그 설정은 물론, 더 많은 환경설정(폴더, 타임라인, 프롬프트, 입력, 내보내기)까지 가져가며, 동기화된 기기에서 온보딩이 다시 표시되지 않습니다.
- **온보딩을 안내 투어로**: 기능 안내가 이제 1/N 진행 표시와 '다음' 버튼과 함께 하나의 투어로 연달아 재생되고, 정렬 안내 후에도 폴더 설정을 계속 사용할 수 있습니다.
- **하이라이트 계정 귀속**: 다중 계정 환경에서 하이라이트가 임시 계정으로 잘못 분류되던 문제를 수정했고, 저장 라이브러리는 로드 실패 시 비어 있는 것처럼 보이는 대신 명확한 오류를 표시합니다.
- **프롬프트 관리자 레이어**: 프롬프트 관리자가 떠 있는 사용량 막대에 가려 클릭할 수 없던 문제를 수정했습니다.
- **더 매끄러운 ChatGPT 플러그인 활성화**: ChatGPT 읽기 너비 플러그인을 켤 때 현재 사이트에 대해서만 권한을 요청하고 한 번의 클릭으로 켜집니다.
- **타임라인 압축 미리보기**: 압축 보기에서 미리보기 패널을 다시 눌러도 닫히지 않던 문제를 수정했습니다.

---

> *"색채는 영혼에 직접 영향을 미치는 힘이다." — 바실리 칸딘스키, 《예술에서의 정신적인 것에 대하여》*

<!-- lang:ru -->

### Новое

- **Цветовая палитра для выделений**: У выделений в Gemini теперь есть пять настраиваемых слотов цвета, предпросмотр цвета на выделенном тексте во время редактирования и переключатель для показа или скрытия маркеров выделения на временной шкале.
- **Центрирование разговора ChatGPT** *(по умолчанию выключено)*: Плагин ChatGPT «Удобная ширина чтения» добавляет параметр «Центрировать содержимое разговора», который центрирует ваши сообщения, тогда как ответы ассистента остаются выровненными по левому краю, сохраняя выбранную ширину.
- **Визуальные эффекты на разрешённых сайтах** *(по умолчанию выключено)*: Эффекты снега, дождя и сакуры теперь могут работать на сторонних сайтах, которые вы разрешили, а не только в Gemini.
- **Предупреждение об использовании хранилища**: Когда хранилище расширения приближается к пределу, появляется уведомление, чтобы вы могли вовремя просмотреть и очистить данные.
- **Обновлённая Сохранённая библиотека**: Всплывающее окно Сохранённой библиотеки стало аккуратнее — со счётчиками на вкладках фильтра и увеличенным полем поиска.

### Исправления

- **Ручная сортировка папок**: Исправлено, что сортировка перетаскиванием переставала работать внутри папок, а переписки перемещались наверх при открытии; в настройках папок также появился синхронизируемый выбор сортировки «Вручную / Недавно открытые».
- **Персонализация между устройствами**: Облачная синхронизация теперь переносит установленные плагины и их настройки, а также множество других предпочтений (папка, временная шкала, промпт, ввод, экспорт), и больше не запускает онбординг заново на синхронизированном устройстве.
- **Онбординг как обучающий тур**: Подсказки по функциям теперь воспроизводятся подряд как один тур с индикатором 1/N и кнопкой «Далее», а настройки папок остаются доступными после подсказки о сортировке.
- **Привязка выделений к аккаунту**: Исправлено ошибочное отнесение выделений к временному аккаунту при нескольких аккаунтах; Сохранённая библиотека теперь показывает понятную ошибку вместо пустого вида при сбое загрузки.
- **Наложение менеджера промптов**: Исправлено, что менеджер промптов был скрыт за плавающей панелью использования и его нельзя было нажать.
- **Более плавное включение плагина ChatGPT**: При включении плагина ширины чтения ChatGPT разрешение теперь запрашивается только для сайта, на котором вы находитесь, и он включается одним щелчком.
- **Компактный предпросмотр временной шкалы**: Исправлена панель предпросмотра в компактном виде, которая не закрывалась при повторном касании.

---

> *«Цвет — это сила, которая непосредственно воздействует на душу.» — Василий Кандинский, «О духовном в искусстве»*
`;export{e as default};
