const e=`<!-- lang:en -->

### What's New

- **Line spacing control**: Adjust line spacing in chat messages from the popup settings.
- **Folder rename from menu**: Rename a folder directly from its context menu.
- **Searchable move dialog**: Search folders by name when moving conversations.
- **AI Studio Enter-to-send**: Press Enter to send messages on AI Studio.
- **Folder collapse guidance**: A visual hint shows when sidebar folders can be collapsed.

### Fixes

- **Timeline active state**: Clicked timeline node stays highlighted after navigating to the message.
- **Folder title sync**: Conversation titles in folders stay in sync with Gemini's native titles.
- **Folder auto-assignment**: Three Folder-as-Project auto-assignment defects corrected.
- **Watermark download**: Download interception only fires when watermark removal is active.
- **Localized send button**: Send button is recognized in all UI languages.
- **Timeline stability**: Draft timestamps scoped per tab, duplicate nodes merged, starred state syncs immediately, and turn IDs stay unique after history prepend.
- **Folder reorder indicator**: Conversation reorder indicator no longer flickers during drag.
- **AI Studio folder backup**: AI Studio folders are now included in local backups.

<!-- lang:zh -->

### 新功能

- **行距控制**：可在扩展弹窗设置中调节聊天消息的行距。
- **文件夹菜单重命名**：可直接从文件夹右键菜单重命名。
- **可搜索的移动对话框**：移动对话时可按名称搜索文件夹。
- **AI Studio 回车发送**：在 AI Studio 中按回车即可发送消息。
- **文件夹折叠提示**：侧边栏文件夹可折叠时会显示视觉提示。

### 修复

- **时间线高亮状态**：点击时间线节点后，跳转到消息后节点仍保持高亮。
- **文件夹标题同步**：文件夹内的对话标题与 Gemini 原生标题保持一致。
- **文件夹自动分配**：修复 Folder-as-Project 自动分配的三个缺陷。
- **水印下载拦截**：仅在启用去水印时才拦截下载。
- **本地化发送按钮**：各语言的发送按钮均能被正确识别。
- **时间线稳定性**：草稿时间戳按标签页隔离、重复节点合并、收藏状态即时同步、历史追加后 ID 不重复。
- **文件夹排序指示器**：拖动时排序指示器不再闪烁。
- **AI Studio 文件夹备份**：本地备份现在包含 AI Studio 文件夹。

<!-- lang:zh_TW -->

### 新功能

- **行距控制**：可在擴充功能彈窗設定中調節聊天訊息的行距。
- **資料夾選單重新命名**：可直接從資料夾右鍵選單重新命名。
- **可搜尋的移動對話框**：移動對話時可依名稱搜尋資料夾。
- **AI Studio Enter 傳送**：在 AI Studio 中按 Enter 即可傳送訊息。
- **資料夾摺疊提示**：側邊欄資料夾可摺疊時會顯示視覺提示。

### 修復

- **時間線高亮狀態**：點擊時間線節點後，跳轉至訊息後節點仍保持高亮。
- **資料夾標題同步**：資料夾內的對話標題與 Gemini 原生標題保持一致。
- **資料夾自動分配**：修正 Folder-as-Project 自動分配的三個缺陷。
- **浮水印下載攔截**：僅在啟用去浮水印時才攔截下載。
- **本地化傳送按鈕**：各語言的傳送按鈕均能被正確辨識。
- **時間線穩定性**：草稿時間戳依分頁隔離、重複節點合併、收藏狀態即時同步、歷史追加後 ID 不重複。
- **資料夾排序指示器**：拖曳時排序指示器不再閃爍。
- **AI Studio 資料夾備份**：本機備份現在包含 AI Studio 資料夾。

<!-- lang:ja -->

### 新機能

- **行間調整**：ポップアップ設定からチャットメッセージの行間を調整できます。
- **フォルダメニューからリネーム**：フォルダのコンテキストメニューから直接名前を変更できます。
- **検索対応の移動ダイアログ**：会話を移動する際、フォルダ名で検索できます。
- **AI Studio Enter 送信**：AI Studio で Enter キーを押してメッセージを送信できます。
- **フォルダ折りたたみガイド**：サイドバーのフォルダが折りたためるとき、視覚的なヒントが表示されます。

### 修正

- **タイムラインのアクティブ状態**：クリックしたタイムラインノードがメッセージへ移動後もハイライトを維持します。
- **フォルダタイトルの同期**：フォルダ内の会話タイトルが Gemini のネイティブタイトルと同期されます。
- **フォルダ自動振り分け**：Folder-as-Project の自動振り分けに関する 3 つの不具合を修正しました。
- **ウォーターマークのダウンロード**：ウォーターマーク除去が有効な場合のみダウンロードを傍受します。
- **ローカライズされた送信ボタン**：すべての UI 言語で送信ボタンを認識します。
- **タイムラインの安定性**：下書きタイムスタンプのタブ別スコープ、重複ノードの統合、スター状態の即時同期、履歴追加後の ID 一意性を確保しました。
- **フォルダ並べ替えインジケーター**：ドラッグ中にインジケーターがちらつかなくなりました。
- **AI Studio フォルダバックアップ**：ローカルバックアップに AI Studio フォルダが含まれるようになりました。

<!-- lang:fr -->

### Nouveautés

- **Contrôle de l'interligne** : Ajustez l'interligne des messages depuis les paramètres de l'extension.
- **Renommer depuis le menu du dossier** : Renommez un dossier directement depuis son menu contextuel.
- **Dialogue de déplacement avec recherche** : Recherchez les dossiers par nom lors du déplacement de conversations.
- **AI Studio Entrée pour envoyer** : Appuyez sur Entrée pour envoyer un message sur AI Studio.
- **Guide de réduction des dossiers** : Un repère visuel indique quand les dossiers de la barre latérale peuvent être réduits.

### Corrections

- **État actif de la timeline** : Le nœud cliqué reste en surbrillance après la navigation vers le message.
- **Synchronisation des titres de dossier** : Les titres de conversation dans les dossiers restent synchronisés avec les titres natifs de Gemini.
- **Attribution automatique de dossier** : Correction de trois défauts dans l'attribution automatique Folder-as-Project.
- **Téléchargement de filigrane** : L'interception du téléchargement ne s'active que lorsque la suppression du filigrane est active.
- **Bouton d'envoi localisé** : Le bouton d'envoi est reconnu dans toutes les langues de l'interface.
- **Stabilité de la timeline** : Horodatages de brouillon par onglet, nœuds dupliqués fusionnés, état étoilé synchronisé immédiatement et identifiants uniques après l'ajout d'historique.
- **Indicateur de réorganisation des dossiers** : L'indicateur ne clignote plus lors du glissement.
- **Sauvegarde des dossiers AI Studio** : Les sauvegardes locales incluent désormais les dossiers AI Studio.

<!-- lang:es -->

### Novedades

- **Control de interlineado**: Ajusta el interlineado de los mensajes desde los ajustes de la extensión.
- **Renombrar desde el menú de carpeta**: Renombra una carpeta directamente desde su menú contextual.
- **Diálogo de mover con búsqueda**: Busca carpetas por nombre al mover conversaciones.
- **AI Studio Enter para enviar**: Pulsa Enter para enviar mensajes en AI Studio.
- **Guía de colapso de carpetas**: Una pista visual indica cuándo las carpetas de la barra lateral se pueden contraer.

### Correcciones

- **Estado activo de la cronología**: El nodo pulsado se mantiene resaltado tras navegar al mensaje.
- **Sincronización de títulos de carpeta**: Los títulos de conversación en carpetas se mantienen sincronizados con los títulos nativos de Gemini.
- **Asignación automática de carpeta**: Corregidos tres defectos en la asignación automática de Folder-as-Project.
- **Descarga de marca de agua**: La interceptación de descarga solo se activa cuando la eliminación de marca de agua está habilitada.
- **Botón de enviar localizado**: El botón de enviar se reconoce en todos los idiomas de la interfaz.
- **Estabilidad de la cronología**: Marcas de tiempo de borrador por pestaña, nodos duplicados fusionados, estado destacado sincronizado al instante e IDs únicos tras añadir historial.
- **Indicador de reordenación de carpetas**: El indicador ya no parpadea durante el arrastre.
- **Copia de seguridad de carpetas AI Studio**: Las copias de seguridad locales ahora incluyen carpetas de AI Studio.

<!-- lang:pt -->

### Novidades

- **Controle de espaçamento entre linhas**: Ajuste o espaçamento entre linhas das mensagens nas configurações da extensão.
- **Renomear pelo menu da pasta**: Renomeie uma pasta diretamente pelo menu de contexto.
- **Diálogo de mover com busca**: Pesquise pastas por nome ao mover conversas.
- **AI Studio Enter para enviar**: Pressione Enter para enviar mensagens no AI Studio.
- **Guia de recolhimento de pastas**: Uma dica visual indica quando as pastas da barra lateral podem ser recolhidas.

### Correções

- **Estado ativo da linha do tempo**: O nó clicado permanece destacado após a navegação até a mensagem.
- **Sincronização de títulos de pasta**: Os títulos de conversa nas pastas permanecem sincronizados com os títulos nativos do Gemini.
- **Atribuição automática de pasta**: Corrigidos três defeitos na atribuição automática de Folder-as-Project.
- **Download de marca d'água**: A interceptação de download só é ativada quando a remoção de marca d'água está ativa.
- **Botão de enviar localizado**: O botão de enviar é reconhecido em todos os idiomas da interface.
- **Estabilidade da linha do tempo**: Carimbos de rascunho por aba, nós duplicados mesclados, estado de favorito sincronizado imediatamente e IDs únicos após adição de histórico.
- **Indicador de reordenação de pastas**: O indicador não pisca mais durante o arrasto.
- **Backup de pastas AI Studio**: Os backups locais agora incluem pastas do AI Studio.

<!-- lang:ar -->

### الجديد

- **التحكم في تباعد الأسطر**: اضبط تباعد أسطر رسائل الدردشة من إعدادات الإضافة.
- **إعادة تسمية من قائمة المجلد**: أعِد تسمية مجلد مباشرة من قائمة السياق الخاصة به.
- **حوار نقل مع بحث**: ابحث عن المجلدات بالاسم عند نقل المحادثات.
- **AI Studio إرسال بـ Enter**: اضغط Enter لإرسال الرسائل في AI Studio.
- **دليل طيّ المجلدات**: تلميح بصري يظهر عندما يمكن طيّ مجلدات الشريط الجانبي.

### الإصلاحات

- **حالة العقدة النشطة في المخطط الزمني**: تبقى العقدة المنقورة مميّزة بعد الانتقال إلى الرسالة.
- **مزامنة عناوين المجلدات**: تبقى عناوين المحادثات في المجلدات متزامنة مع عناوين Gemini الأصلية.
- **التعيين التلقائي للمجلدات**: تصحيح ثلاثة عيوب في التعيين التلقائي لـ Folder-as-Project.
- **تنزيل العلامة المائية**: لا يتم اعتراض التنزيل إلا عند تفعيل إزالة العلامة المائية.
- **زر الإرسال المحلّي**: يُتعرَّف على زر الإرسال في جميع لغات الواجهة.
- **استقرار المخطط الزمني**: طوابع زمنية للمسودات حسب التبويب، ودمج العقد المكررة، ومزامنة حالة النجمة فورًا، وبقاء المعرّفات فريدة بعد إلحاق السجل.
- **مؤشر إعادة ترتيب المجلدات**: لم يعد المؤشر يومض أثناء السحب.
- **نسخ احتياطي لمجلدات AI Studio**: تشمل النسخ الاحتياطية المحلية الآن مجلدات AI Studio.

<!-- lang:ko -->

### 새로운 기능

- **줄 간격 조절**: 확장 팝업 설정에서 채팅 메시지의 줄 간격을 조정합니다.
- **폴더 메뉴에서 이름 변경**: 폴더 컨텍스트 메뉴에서 바로 이름을 변경합니다.
- **검색 가능한 이동 대화상자**: 대화를 이동할 때 이름으로 폴더를 검색합니다.
- **AI Studio Enter 전송**: AI Studio에서 Enter를 눌러 메시지를 보냅니다.
- **폴더 접기 안내**: 사이드바 폴더를 접을 수 있을 때 시각적 힌트가 표시됩니다.

### 수정

- **타임라인 활성 상태**: 클릭한 타임라인 노드가 메시지로 이동 후에도 강조 표시를 유지합니다.
- **폴더 제목 동기화**: 폴더 내 대화 제목이 Gemini 기본 제목과 동기화됩니다.
- **폴더 자동 배정**: Folder-as-Project 자동 배정의 세 가지 결함을 수정했습니다.
- **워터마크 다운로드**: 워터마크 제거가 활성화된 경우에만 다운로드를 가로챕니다.
- **현지화된 보내기 버튼**: 모든 UI 언어에서 보내기 버튼을 인식합니다.
- **타임라인 안정성**: 탭별 임시 타임스탬프 범위 지정, 중복 노드 병합, 즐겨찾기 상태 즉시 동기화, 기록 추가 후 ID 고유성 보장.
- **폴더 정렬 표시기**: 드래그 중 표시기가 더 이상 깜빡이지 않습니다.
- **AI Studio 폴더 백업**: 로컬 백업에 AI Studio 폴더가 포함됩니다.

<!-- lang:ru -->

### Новое

- **Управление межстрочным интервалом**: Настройте межстрочный интервал сообщений чата в параметрах расширения.
- **Переименование из меню папки**: Переименовывайте папку прямо из контекстного меню.
- **Диалог перемещения с поиском**: Ищите папки по имени при перемещении бесед.
- **AI Studio отправка по Enter**: Нажмите Enter для отправки сообщений в AI Studio.
- **Подсказка сворачивания папок**: Визуальная подсказка появляется, когда папки на боковой панели можно свернуть.

### Исправления

- **Активное состояние timeline**: Нажатый узел timeline остаётся выделенным после перехода к сообщению.
- **Синхронизация заголовков папок**: Заголовки бесед в папках синхронизируются с родными заголовками Gemini.
- **Автоназначение папок**: Исправлены три дефекта автоназначения Folder-as-Project.
- **Загрузка с водяным знаком**: Перехват загрузки срабатывает только при активном удалении водяного знака.
- **Локализованная кнопка отправки**: Кнопка отправки распознаётся на всех языках интерфейса.
- **Стабильность timeline**: Черновые метки времени по вкладкам, дублирующиеся узлы объединены, состояние звёздочки синхронизируется мгновенно, ID остаются уникальными после подгрузки истории.
- **Индикатор перестановки папок**: Индикатор больше не мерцает при перетаскивании.
- **Резервное копирование папок AI Studio**: Локальные бэкапы теперь включают папки AI Studio.
`;export{e as default};
