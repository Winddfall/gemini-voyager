const e=`<!-- lang:en -->

### What's New

- **Official plugin marketplace & contribution guide**: Voyager now ships with a built-in plugin marketplace. Anyone can publish a plugin via a simple [contribution guide](https://voyager.nagi.fun/guide/plugin-contribution) — start with a declarative CSS + JSON plugin, no extension build required. See it in action at the [Plugin Store](https://voyager.nagi.fun/plugins).
- **Builtin Formula Copy plugin** *(opt-in, off by default)*: A new first-party "Formula Copy" plugin ships in the extension — but it stays **off** until you turn it on. Just open the popup's Plugins section, flip the toggle for Claude or ChatGPT, and the browser will show a one-time permission prompt to grant Voyager host access for that site. Click the formula on the page and it's copied as Markdown LaTeX. Nothing activates silently and the prompt is the only "configuration" step.
- **Localized plugin metadata**: Plugin name and description now follow your popup language; marketplace cards on the docs site do too.

### Fixes

- **Watermark anchor moved by Gemini**: Re-adapted the watermark remover to Gemini's new anchor position — the high-failure report from 1.4.7 is resolved.
- **Watermark full teardown**: \`stopWatermarkRemover\` now releases every observer, timer, and listener it created, so toggling off can't leave a stuck "processing" state.
- **Sidebar toggle hit target**: Restored the widened hit area on the collapsed-sidebar toggle that was reverted in the last release.
- **Folder menu titles on native drag**: Folder drag titles now match Gemini's native style, so they look right inside AI Studio and the recent-history hover.
- **Folder picker opens upward**: The folder project picker now opens above the trigger when there's no room below.
- **Folder: "Remove from folder" wording**: Confirmation copy is clearer — you're removing the conversation from the folder, not deleting the folder.
- **Timeline tooltip activation**: Tooltips now wait for an explicit hover instead of flashing on every scroll.
- **Firefox optional-host-permissions gate**: Users on Firefox 116+ can now grant optional permissions again (regression from the Fx<128 fix).
- **Safari durable backup recovery**: Backup recovery now persists to durable storage so the ITP 7-day window doesn't drop folder backups.
- **Formula copy toast language**: The copy-success toast now matches the selected UI language, not the browser locale.
- **A11y wiring**: Sliders, switches, and ratings now have proper aria labels, and \`eslint-plugin-jsx-a11y\` is enforced in CI.

### Performance

- **Lazy KaTeX + JSZip**: KaTeX and JSZIP no longer load in the content-script bundle — they only load when first needed (math preview, image export).
- **Deferred marked + KaTeX in prompt preview**: The prompt markdown preview no longer parses math at popup open time.
- **Idle watermark init**: Watermark observer initialization yields to \`requestIdleCallback\` so first paint stays smooth.
- **Account-isolation skip**: No-op profile-map rewrites are now skipped instead of re-running on every change.

<!-- lang:zh -->

### 新功能

- **官方插件市场与贡献指南**：Voyager 现在内置插件市场，任何人都可以通过[插件贡献说明](https://voyager.nagi.fun/guide/plugin-contribution)发布插件——从声明式 CSS + JSON 插件起步即可，无需打包扩展。在[插件商店](https://voyager.nagi.fun/plugins)查看已上架插件。
- **内置「复制公式」插件** *（默认关闭，按需开启）*：随扩展一起打包了新的官方「复制公式」插件——但**默认是关闭的**，你不开它就完全不动。要用时打开弹窗里的插件面板，把对应站点（Claude 或 ChatGPT）的开关打开，浏览器会弹出一次性的站点授权确认；同意后在页面上点击公式，就会以 Markdown LaTeX 形式复制。不会有任何"静默启用"，授权框就是唯一的"配置"步骤。
- **插件元数据本地化**：插件名称和描述会跟随弹窗语言显示；官网市场卡片也会同步本地化。

### 修复

- **水印锚点被 Gemini 改动**：水印移除器已适配 Gemini 新的锚点位置，1.4.7 报告的"高概率去水印失败"已修复。
- **水印彻底释放**：\`stopWatermarkRemover\` 现在会释放它创建的所有观察器、定时器和监听器，关闭后不会再卡在"处理中"。
- **侧边栏开关点击区**：恢复了窄侧边栏开关的扩展点击区域（上一版误改回原状）。
- **文件夹拖拽标题样式**：在 AI Studio 和历史悬停中，文件夹拖拽标题现在与 Gemini 原生样式一致。
- **文件夹选择器向上展开**：触发器下方空间不足时，文件夹项目选择器改为向上展开。
- **"移出文件夹"文案**：确认文案更清晰——你正在把对话从该文件夹移出，而不是删除该文件夹。
- **时间线提示激活**：提示框现在只在明确悬停时显示，不再因滚动而频繁闪烁。
- **Firefox 可选权限门控**：Firefox 116+ 用户可以重新授予可选权限（修复 Fx<128 修复带来的回归）。
- **Safari 持久化备份恢复**：备份恢复现在写入持久化存储，不再被 ITP 的 7 天窗口丢弃。
- **复制公式提示语言**：复制成功的提示语现在跟随弹窗所选语言，而非浏览器语言。
- **可访问性**：滑块、开关、评分控件已补齐 aria 标签，\`eslint-plugin-jsx-a11y\` 已在 CI 中强制启用。

### 性能

- **KaTeX 与 JSZip 懒加载**：KaTeX 和 JSZIP 不再打进 content-script 包，仅在首次需要时（数学预览、图片导出）按需加载。
- **Prompt 预览延后加载 marked + KaTeX**：弹窗打开时不再立即解析数学公式。
- **水印观察器空闲初始化**：水印观察器通过 \`requestIdleCallback\` 延迟初始化，首屏更顺滑。
- **账号隔离跳过空操作**：无变更时不再重写 profile-map。

<!-- lang:zh_TW -->

### 新功能

- **官方插件市集與貢獻指南**：Voyager 現在內建插件市集，任何人都可以透過[插件貢獻說明](https://voyager.nagi.fun/guide/plugin-contribution)發佈插件——從宣告式 CSS + JSON 插件起步即可，無需打包擴充功能。在[插件商店](https://voyager.nagi.fun/plugins)查看已上架的插件。
- **內建「複製公式」外掛** *（預設關閉，按需開啟）*：隨擴充功能一起打包了新的官方「複製公式」外掛——但**預設是關閉的**，你沒開它就完全不會動。要用時打開彈窗裡的外掛面板，把對應網站（Claude 或 ChatGPT）的開關打開，瀏覽器會跳出一次性的網站授權確認；同意後在頁面上點擊公式，就會以 Markdown LaTeX 形式複製。沒有任何「靜默啟用」，授權框就是唯一的「設定」步驟。
- **外掛中繼資料在地化**：外掛名稱與說明會跟隨彈窗語系顯示；官網市集卡片也會同步在地化。

### 修復

- **浮水印錨點被 Gemini 變動**：浮水印移除器已適配 Gemini 新的錨點位置，1.4.7 回報的「高機率去浮水印失敗」已修復。
- **浮水印徹底釋放**：\`stopWatermarkRemover\` 現在會釋放它建立的所有觀察器、計時器與監聽器，關閉後不會再卡在「處理中」。
- **側邊欄開關點擊區**：恢復了窄側邊欄開關的擴展點擊區（上一版誤改回原狀）。
- **資料夾拖曳標題樣式**：在 AI Studio 與歷史懸停中，資料夾拖曳標題現在與 Gemini 原生樣式一致。
- **資料夾選擇器向上展開**：觸發器下方空間不足時，資料夾專案選擇器改為向上展開。
- **「移出資料夾」文案**：確認文案更清楚——你正在把對話從該資料夾移出，而不是刪除該資料夾。
- **時間軸提示啟動**：提示框現在只在明確懸停時顯示，不再因捲動而頻繁閃爍。
- **Firefox 可選權限門控**：Firefox 116+ 使用者可以重新授予可選權限（修正 Fx<128 修正帶來的迴歸）。
- **Safari 持久化備份復原**：備份復原現在寫入持久化儲存，不再被 ITP 的 7 天視窗丟棄。
- **複製公式提示語言**：複製成功的提示語現在跟隨彈窗所選語系，而非瀏覽器語系。
- **無障礙**：滑桿、開關、評分控制項已補齊 aria 標籤，\`eslint-plugin-jsx-a11y\` 已在 CI 中強制啟用。

### 效能

- **KaTeX 與 JSZip 懶載入**：KaTeX 和 JSZIP 不再打包進 content-script bundle，僅在首次需要時（數學預覽、圖片匯出）按需載入。
- **Prompt 預覽延後載入 marked + KaTeX**：彈窗開啟時不再立即解析數學公式。
- **浮水印觀察器閒置初始化**：浮水印觀察器透過 \`requestIdleCallback\` 延後初始化，首頁更順暢。
- **帳號隔離跳過空操作**：無變更時不再重寫 profile-map。

<!-- lang:ja -->

### 新機能

- **公式プラグイン市場と貢献ガイド**：Voyager に公式のプラグインマーケットプレイスを内蔵しました。[プラグイン貢献ガイド](https://voyager.nagi.fun/guide/plugin-contribution)に従って、誰でも拡張機能をパッケージ化せずにプラグインを公開できます。公開済みプラグインは[プラグインストア](https://voyager.nagi.fun/plugins)から確認できます。
- **内蔵「数式コピー」プラグイン** *（デフォルトではオフ、使う時だけ有効化）*：新しい公式の「数式コピー」プラグインを拡張機能に同梱しました。ただし**デフォルトは無効**で、あなたが開かない限り一切動作しません。使うときはポップアップのプラグイン欄で対応サイト（Claude または ChatGPT）のトグルをオンにしてください。ブラウザがサイトアクセス許可のダイアログを一度だけ表示します。許可後、ページ上の数式をクリックすれば Markdown LaTeX としてコピーされます。バックグラウンドで勝手に有効化されることはなく、許可ダイアログが唯一の「設定」ステップです。
- **プラグインメタデータのローカライズ**：プラグイン名と説明文が、ポップアップの言語設定に従って表示されるようになりました。公式サイトのマーケットプレースカードも同様にローカライズされます。

### 修正

- **Gemini によるウォーターマークアンカー変更への追従**：ウォーターマーク除去ツールを Gemini の新しいアンカー位置に適応させました。1.4.7 で報告された「高確率で失敗する」事象は解消しています。
- **ウォーターマークの完全な解放**：\`stopWatermarkRemover\` が作成したすべてのオブザーバ・タイマ・リスナを解放するようになり、オフにしたときに「処理中」のまま固まらなくなりました。
- **サイドバートグルの当たり判定**：折りたたみサイドバーのトグルで広げていた当たり判定領域を復活させました（前リリースで元に戻っていた箇所）。
- **フォルダのドラッグタイトル**：AI Studio や履歴ホバー内でのフォルダドラッグタイトルが、Gemini のネイティブ表示と揃うようになりました。
- **フォルダピッカーが上向きに展開**：下方向にスペースがないとき、フォルダピッカーが上向きに展開されるようになりました。
- **フォルダから削除」の文言**：確認ダイアログの文面を改善しました — フォルダを削除するのではなく、そのフォルダから会話を外す操作であることが明確になります。
- **タイムラインのツールチップ表示**：明示的なホバーまで待ってから表示するようになり、スクロールのたびに点滅しなくなりました。
- **Firefox のオプショナル権限ゲート**：Firefox 116+ のユーザーが再びオプショナル権限を付与できるようになりました（Fx<128 対応の副作用を修正）。
- **Safari の永続バックアップ復元**：バックアップ復元が永続ストレージに書き込まれるようになり、ITP の 7 日ウィンドウにバックアップが捨てられなくなりました。
- **数式コピーのトースト言語**：コピー成功のトーストが、ブラウザロケールではなく選択中の UI 言語に従うようになりました。
- **アクセシビリティ**：スライダ・スイッチ・評価コントロールに適切な aria ラベルが付与され、\`eslint-plugin-jsx-a11y\` が CI で必須化されました。

### パフォーマンス

- **KaTeX と JSZip の遅延読み込み**：KaTeX と JSZIP は content-script のチャンクに含まれなくなり、必要になった時点で動的に読み込まれます（数式プレビュー・画像エクスポート時）。
- **プロンプトプレビューで marked + KaTeX を遅延**：ポップアップを開いた時点で数式のパースを行わなくなりました。
- **ウォーターマークのアイドル時初期化**：ウォーターマークのオブザーバ初期化を \`requestIdleCallback\` に委譲し、初期描画が軽くなりました。
- **アカウント分離の空操作スキップ**：変更がないときは profile-map の書き換えをスキップします。

<!-- lang:fr -->

### Nouveautés

- **Marketplace de plugins officielle & guide de contribution** : Voyager intègre désormais une marketplace de plugins. Tout le monde peut publier un plugin via le [guide de contribution](https://voyager.nagi.fun/guide/plugin-contribution) — commencez par un plugin déclaratif CSS + JSON, sans compiler l'extension. Découvrez-les sur la [Plugin Store](https://voyager.nagi.fun/plugins).
- **Plugin natif « Copier les formules »** *(désactivé par défaut, à activer au besoin)* : Un nouveau plugin officiel « Copier les formules » est inclus dans l'extension — mais il reste **désactivé** tant que vous ne l'activez pas, et il ne fait strictement rien dans cet état. Pour l'utiliser, ouvrez la section Plugins du popup et activez le toggle du site concerné (Claude ou ChatGPT). Le navigateur affichera alors une boîte de dialogue unique pour autoriser Voyager à accéder au site. Une fois accepté, cliquez sur une formule dans la page : elle est copiée en LaTeX Markdown. Aucune activation silencieuse, et la boîte d'autorisation est l'unique étape de « configuration ».
- **Métadonnées des plugins localisées** : Le nom et la description des plugins suivent la langue du popup ; les cartes de la marketplace sur le site le sont aussi.

### Corrections

- **Ancre du filigrane déplacée par Gemini** : L'outil de suppression du filigrane a été ré-adapté à la nouvelle position d'ancre de Gemini — le signalement de forte fréquence d'échec en 1.4.7 est résolu.
- **Démontage complet du filigrane** : \`stopWatermarkRemover\` libère désormais tous les observers, timers et listeners qu'il a créés, ce qui évite un état bloqué sur « traitement ».
- **Cible du toggle de la barre latérale** : La zone de clic élargie du toggle de la barre latérale réduite, rétablie après le retour en arrière de la version précédente.
- **Titres de glisser-déposer des dossiers** : Les titres pendant le drag correspondent désormais au style natif de Gemini, aussi bien dans AI Studio que dans l'historique au survol.
- **Sélecteur de dossier vers le haut** : Le sélecteur de projet de dossier s'ouvre désormais vers le haut lorsqu'il n'y a pas la place en dessous.
- **Libellé « Retirer du dossier »** : Le message de confirmation est plus clair — vous retirez la conversation du dossier, pas le dossier lui-même.
- **Activation des tooltips de la timeline** : Les tooltips attendent désormais un survol explicite au lieu de clignoter à chaque défilement.
- **Portée des permissions optionnelles Firefox** : Les utilisateurs de Firefox 116+ peuvent à nouveau accorder les permissions optionnelles (régression introduite par le correctif Fx<128).
- **Restauration des sauvegardes durables Safari** : La restauration écrit désormais dans le stockage durable, ce qui évite la perte des sauvegardes de dossiers dans la fenêtre ITP de 7 jours.
- **Langue du toast « Copier la formule »** : Le toast de succès suit la langue d'interface choisie, et non la locale du navigateur.
- **Accessibilité** : Les sliders, switches et notations ont désormais des aria-labels appropriés, et \`eslint-plugin-jsx-a11y\` est appliqué en CI.

### Performances

- **Chargement paresseux de KaTeX et JSZip** : KaTeX et JSZIP ne sont plus inclus dans le bundle du content-script — ils ne se chargent qu'à la première utilisation (prévisualisation maths, export image).
- **Chargement différé de marked + KaTeX dans l'aperçu des prompts** : L'aperçu markdown ne parse plus les formules à l'ouverture du popup.
- **Initialisation du filigrane en différé** : L'initialisation de l'observer du filigrane est cédée à \`requestIdleCallback\`, pour un premier rendu plus fluide.
- **Isolation de compte : pas de réécriture à vide** : Les réécritures de profile-map sans changement sont désormais ignorées.

<!-- lang:es -->

### Novedades

- **Marketplace oficial de plugins y guía de contribución**: Voyager incluye ahora una marketplace de plugins integrada. Cualquiera puede publicar un plugin siguiendo la [guía de contribución](https://voyager.nagi.fun/guide/plugin-contribution): empieza con un plugin declarativo CSS + JSON, sin compilar la extensión. Échales un vistazo en la [Plugin Store](https://voyager.nagi.fun/plugins).
- **Plugin nativo «Copiar fórmulas»** *(desactivado por defecto, se activa bajo demanda)*: Un nuevo plugin oficial «Copiar fórmulas» viene incluido en la extensión, pero permanece **desactivado** hasta que tú lo enciendas; mientras esté apagado, no hace absolutamente nada. Para usarlo, abre la sección de Plugins del popup y activa el interruptor del sitio correspondiente (Claude o ChatGPT). El navegador mostrará un único cuadro de diálogo para conceder a Voyager el acceso a ese sitio. Tras aceptarlo, haz clic en una fórmula de la página y se copiará como LaTeX en Markdown. No hay activación silenciosa alguna: el cuadro de autorización es el único paso de «configuración».
- **Metadatos de plugins localizados**: El nombre y la descripción de los plugins siguen ahora el idioma del popup; las tarjetas de la marketplace en el sitio también.

### Correcciones

- **Ancla de la marca de agua movida por Gemini**: El removedor de marca de agua se ha vuelto a adaptar a la nueva posición del ancla de Gemini — el aviso de alta tasa de fallos de 1.4.7 queda resuelto.
- **Desmontaje completo de la marca de agua**: \`stopWatermarkRemover\` libera ya todos los observers, timers y listeners que creó, así que al desactivarlo no puede dejar el estado «procesando» colgado.
- **Área de clic del toggle de la barra lateral**: Restablecida el área de clic ampliada del toggle de la barra lateral contraída, que se había revertido en la versión anterior.
- **Títulos al arrastrar carpetas**: Los títulos durante el arrastre siguen ahora el estilo nativo de Gemini, tanto en AI Studio como en el hover del historial.
- **Selector de carpeta hacia arriba**: El selector de proyecto de carpeta se abre ahora hacia arriba cuando no hay espacio debajo.
- **Texto «Quitar de la carpeta»**: El mensaje de confirmación es más claro — estás quitando la conversación de la carpeta, no borrando la carpeta.
- **Activación del tooltip de la timeline**: Los tooltips esperan ahora un hover explícito en lugar de parpadear con cada scroll.
- **Puerta de permisos opcionales en Firefox**: Los usuarios de Firefox 116+ pueden volver a conceder permisos opcionales (regresión del parche para Fx<128).
- **Restauración de copias de seguridad duraderas en Safari**: La restauración escribe ya en almacenamiento duradero, evitando perder copias de carpetas en la ventana ITP de 7 días.
- **Idioma del toast de «Copiar fórmula»**: El toast de éxito sigue el idioma de la interfaz elegido, no la locale del navegador.
- **Accesibilidad**: Sliders, switches y ratings cuentan ya con aria-labels apropiados, y \`eslint-plugin-jsx-a11y\` se aplica en CI.

### Rendimiento

- **Carga diferida de KaTeX y JSZip**: KaTeX y JSZIP ya no se incluyen en el bundle del content-script — solo se cargan cuando se necesitan (vista previa de matemáticas, export de imagen).
- **Carga diferida de marked + KaTeX en la vista previa de prompts**: La vista previa markdown ya no parsea las fórmulas al abrir el popup.
- **Inicialización de la marca de agua en diferido**: La inicialización del observer se cede a \`requestIdleCallback\`, mejorando el primer render.
- **Saltarse la reescritura vacía en el aislamiento de cuenta**: Ya no se reescribe el profile-map si no hay cambios.

<!-- lang:pt -->

### Novidades

- **Marketplace oficial de plugins e guia de contribuição**: O Voyager agora traz uma marketplace de plugins integrada. Qualquer pessoa pode publicar um plugin seguindo o [guia de contribuição](https://voyager.nagi.fun/guide/plugin-contribution) — comece por um plugin declarativo CSS + JSON, sem precisar compilar a extensão. Veja-os na [Plugin Store](https://voyager.nagi.fun/plugins).
- **Plugin nativo «Copiar fórmulas»** *(desativado por padrão, ative quando precisar)*: Um novo plugin oficial «Copiar fórmulas» vem incluído na extensão, mas permanece **desativado** até você ligá-lo — enquanto estiver desligado, não faz absolutamente nada. Para usá-lo, abra a secção de Plugins do popup e ative o interruptor do site correspondente (Claude ou ChatGPT). O navegador mostrará um único diálogo de autorização para conceder ao Voyager o acesso àquele site. Depois de aceitar, clique numa fórmula na página e ela será copiada como LaTeX em Markdown. Não há qualquer ativação silenciosa: o diálogo de autorização é o único passo de «configuração».
- **Metadados dos plugins localizados**: O nome e a descrição dos plugins agora seguem o idioma do popup; os cartões da marketplace no site também.

### Correções

- **Âncora da marca d'água movida pelo Gemini**: O removedor de marca d'água foi readaptado à nova posição da âncora do Gemini — o relato de alta taxa de falhas do 1.4.7 está resolvido.
- **Desmontagem completa da marca d'água**: \`stopWatermarkRemover\` libera agora todos os observers, timers e listeners que criou, de modo que desativá-la não deixa um estado «processando» preso.
- **Área de clique do toggle da barra lateral**: Restaurada a área de clique ampliada do toggle da barra lateral recolhida, que tinha sido revertida no lançamento anterior.
- **Títulos ao arrastar pastas**: Os títulos durante o arrasto agora seguem o estilo nativo do Gemini, tanto no AI Studio quanto no hover do histórico.
- **Seletor de pasta para cima**: O seletor de projeto de pasta abre-se agora para cima quando não há espaço abaixo.
- **Texto «Remover da pasta»**: A mensagem de confirmação é mais clara — você está removendo a conversa da pasta, não apagando a pasta.
- **Ativação do tooltip da timeline**: Os tooltips esperam agora um hover explícito, em vez de piscar a cada scroll.
- **Porta de permissões opcionais no Firefox**: Utilizadores de Firefox 116+ podem voltar a conceder permissões opcionais (regressão do patch para Fx<128).
- **Restauração de backups duráveis no Safari**: A restauração grava agora em armazenamento durável, evitando perder backups de pastas na janela de 7 dias do ITP.
- **Idioma do toast de «Copiar fórmula»**: O toast de sucesso segue o idioma da interface escolhido, e não a locale do navegador.
- **Acessibilidade**: Sliders, switches e ratings já têm aria-labels adequados, e \`eslint-plugin-jsx-a11y\` é aplicado na CI.

### Desempenho

- **Carga preguiçosa de KaTeX e JSZip**: KaTeX e JSZIP deixam de integrar o bundle do content-script — só carregam quando precisos (pré-visualização de matemática, export de imagem).
- **Carga diferida de marked + KaTeX na pré-visualização de prompts**: A pré-visualização markdown deixa de fazer parse de fórmulas ao abrir o popup.
- **Inicialização da marca d'água em diferido**: A inicialização do observer passa a ser entregue a \`requestIdleCallback\`, melhorando o primeiro render.
- **Saltar reescrita vazia no isolamento de conta**: Não se reescreve o profile-map quando nada mudou.

<!-- lang:ar -->

### الجديد

- **متجر الإضافات الرسمي ودليل المساهمة**: أصبح Voyager يضم متجرًا مدمجًا للإضافات. يمكن لأي شخص نشر إضافة عبر [دليل المساهمة](https://voyager.nagi.fun/guide/plugin-contribution) — ابدأ بإضافة تعريفية من CSS + JSON، دون الحاجة إلى بناء الإضافة. تصفّح الإضافات في [متجر الإضافات](https://voyager.nagi.fun/plugins).
- **إضافة «نسخ الصيغ» المدمجة** *(*معطّلة افتراضيًا، تُفعَّل عند الحاجة*)*: أُرفقت مع الإضافة إضافة رسمية جديدة باسم «نسخ الصيغ»، لكنها تبقى **معطّلة** إلى أن تُفعّلها أنت بنفسك — وفي حالة التعطيل لا تفعل شيئًا على الإطلاق. لاستخدامها، افتح قسم الإضافات في النافذة المنبثقة وفعّل مفتاح التبديل للموقع المعني (Claude أو ChatGPT). سيُظهر المتصفّح حوارًا واحدًا لمنح Voyager صلاحية الوصول إلى ذلك الموقع. بعد الموافقة، انقر على أي صيغة في الصفحة لتُنسخ بصيغة Markdown ‏LaTeX. لا يوجد أي تفعيل صامت، وحوار الإذن هو خطوة «الإعداد» الوحيدة.
- **بيانات الإضافات بأثر اللغة**: أصبح اسم الإضافة ووصفها يتبعان لغة النافذة المنبثقة؛ وبطاقات المتجر على الموقع أيضًا.

### الإصلاحات

- **تغيّر مرساة العلامة المائية في Gemini**: أُعيد تكييف أداة إزالة العلامة المائية مع موضع المرساة الجديد في Gemini — وقد عُولج البلاغ المتعلّق بارتفاع معدّل الفشل في 1.4.7.
- **إيقاف تشغيل كامل للعلامة المائية**: يُحرِّر \`stopWatermarkRemover\` الآن جميع المراقبات والمؤقّتات والمستمعات التي أنشأها، فلا يبقى عالقًا في حالة «جارٍ المعالجة» بعد الإيقاف.
- **مساحة النقر لمبدّل الشريط الجانبي**: استُعيدت مساحة النقر الموسّعة لمبدّل الشريط الجانبي المطوي، التي كانت قد تراجعت في الإصدار السابق.
- **عناوين السحب والإفلات للمجلدات**: أصبحت عناوين السحب تتطابق مع نمط Gemini الأصلي، سواء في AI Studio أم عند تمرير المؤشّر فوق السجلّ.
- **فتح منتقي المجلد للأعلى**: يفتح منتقي مشروع المجلد الآن للأعلى عند عدم توفّر مساحة أدنى المُطلِق.
- **نص «إزالة من المجلد»**: رسالة التأكيد أوضح — أنت تزيل المحادثة من المجلد، لا تحذف المجلد نفسه.
- **تفعيل تلميح الجدول الزمني**: تنتظر التلميحات الآن تمريرًا صريحًا للمؤشّر فوقها، بدلًا من الوميض مع كل تمرير.
- **بوابة الصلاحيات الاختيارية في Firefox**: يمكن لمستخدمي Firefox 116+ منح الصلاحيات الاختيارية مجددًا (انحدار ناتج عن إصلاح Fx<128).
- **استعادة النسخ الاحتياطي الدائم في Safari**: تكتب الاستعادة الآن في التخزين الدائم، فلا تُفقد نسخ المجلدات الاحتياطية ضمن نافذة الـ7 أيام في ITP.
- **لغة إشعار «نسخ الصيغة»**: يتبع إشعار النجاح لغة الواجهة المختارة، لا لغة المتصفّح.
- **الإتاحة**: حظيت المنزلقات والمفاتيح والتقييمات بوسوم aria الملائمة، ويُطبَّق \`eslint-plugin-jsx-a11y\` في CI.

### الأداء

- **تحميل كسول لـ KaTeX وJSZip**: لم يعودا ضمن حزمة content-script — يُحمَّلان عند الحاجة فقط (معاينة الرياضيات، تصدير الصور).
- **تأخير تحميل marked + KaTeX في معاينة التلميح**: لم تعد معاينة markdown تحلّل الصيغ عند فتح النافذة.
- **تهيئة العلامة المائية في وقت الخمول**: صارت تهيئة المراقب تُسلَّم إلى \`requestIdleCallback\` لتحسين سرعة الرسم الأوّل.
- **تخطّي إعادة الكتابة الفارغة في عزل الحساب**: لا يُعاد كتابة profile-map عند عدم وجود تغيّر.

<!-- lang:ko -->

### 새로운 기능

- **공식 플러그인 마켓플레이스 & 기여 가이드**: Voyager에 플러그인 마켓플레이스가 내장되었습니다. 누구나 [기여 가이드](https://voyager.nagi.fun/guide/plugin-contribution)에 따라 플러그인을 게시할 수 있습니다 — 선언적 CSS + JSON 플러그인부터 시작하면 확장 빌드 없이도 됩니다. [플러그인 스토어](https://voyager.nagi.fun/plugins)에서 확인해 보세요.
- **내장 "수식 복사" 플러그인** *(기본 꺼짐, 필요할 때만 켜기)*: 새 공식 "수식 복사" 플러그인이 확장 프로그램에 동봉되어 있지만 **기본은 꺼져** 있어서 본인이 켜기 전에는 전혀 동작하지 않습니다. 사용하려면 팝업의 플러그인 섹션에서 해당 사이트(Claude 또는 ChatGPT)의 토글을 켜세요. 그러면 브라우저가 해당 사이트에 대한 Voyager의 접근 권한을 묻는 대화상자를 한 번만 띄웁니다. 허용한 후 페이지에서 수식을 클릭하면 Markdown LaTeX으로 복사됩니다. 조용히 켜지는 일은 없으며, 권한 대화상자가 유일한 "설정" 단계입니다.
- **플러그인 메타데이터 현지화**: 플러그인 이름과 설명이 팝업 언어 설정을 따르도록 변경되었으며, 공식 사이트 마켓플레이스 카드도 동일하게 현지화됩니다.

### 수정

- **Gemini가 변경한 워터마크 앵커**: 워터마크 제거 도구를 Gemini의 새 앵커 위치에 다시 맞췄습니다 — 1.4.7에서 보고된 높은 실패율은 해결되었습니다.
- **워터마크 완전 해제**: \`stopWatermarkRemover\`가 생성한 모든 옵저버, 타이머, 리스너를 해제하도록 변경되어, 비활성화 시 "처리 중" 상태에 더 이상 멈추지 않습니다.
- **사이드바 토글 클릭 영역**: 접힌 사이드바 토글의 확장된 클릭 영역을 복원했습니다(지난 릴리스에서 되돌아갔던 부분).
- **폴더 드래그 제목**: AI Studio와 기록 호버에서 폴더 드래그 제목이 이제 Gemini 네이티브 스타일과 일치합니다.
- **폴더 선택기 위로 열기**: 트리거 아래에 공간이 없을 때 폴더 프로젝트 선택기가 위로 열리도록 변경했습니다.
- **"폴더에서 제거" 문구**: 확인 문구가 더 명확해졌습니다 — 폴더를 삭제하는 것이 아니라 그 폴더에서 대화를 제거하는 작업입니다.
- **타임라인 툴팁 활성화**: 스크롤할 때마다 깜빡이지 않고, 명시적인 호버를 기다리도록 변경했습니다.
- **Firefox 옵션 권한 게이트**: Firefox 116+ 사용자가 옵션 권한을 다시 부여할 수 있습니다(Fx<128 패치로 인한 회귀 수정).
- **Safari 영구 백업 복구**: 복구본을 영구 저장소에 기록하여, ITP의 7일 윈도우에서 폴더 백업이 유실되지 않게 했습니다.
- **수식 복사 토스트 언어**: 복사 성공 토스트가 브라우저 로케일이 아닌 선택된 UI 언어를 따르도록 변경했습니다.
- **접근성**: 슬라이더, 스위치, 평가 컨트롤에 적절한 aria 레이블이 부여되었으며, \`eslint-plugin-jsx-a11y\`가 CI에서 강제됩니다.

### 성능

- **KaTeX 및 JSZip 지연 로드**: KaTeX와 JSZIP이 더 이상 content-script 번들에 포함되지 않으며, 처음 필요할 때(수식 미리보기, 이미지 내보내기) 로드됩니다.
- **프롬프트 미리보기에서 marked + KaTeX 지연**: 팝업 열림 시점에 수식을 더 이상 파싱하지 않습니다.
- **워터마크 유휴 초기화**: 워터마크 옵저버 초기화가 \`requestIdleCallback\`으로 위임되어, 첫 렌더가 더 매끄러워집니다.
- **계정 격리에서 빈 재기록 건너뛰기**: 변경 사항이 없을 때 profile-map을 다시 쓰지 않습니다.

<!-- lang:ru -->

### Новое

- **Официальный маркетплейс плагинов и руководство для контрибьюторов**: Voyager теперь поставляется со встроенным маркетплейсом плагинов. Любой может опубликовать плагин, следуя [руководству по участию](https://voyager.nagi.fun/guide/plugin-contribution) — начните с декларативного CSS + JSON плагина, без сборки расширения. Доступно в [магазине плагинов](https://voyager.nagi.fun/plugins).
- **Встроенный плагин «Копировать формулы»** *(по умолчанию выключен, включается по запросу)*: В комплект расширения добавлен новый официальный плагин «Копировать формулы», но он остаётся **выключен**, пока вы сами его не включите — в этом состоянии он не делает ровным счётом ничего. Чтобы воспользоваться им, откройте в попапе раздел плагинов и переключите тумблер нужного сайта (Claude или ChatGPT). Браузер покажет единственное окно запроса доступа Voyager к этому сайту. После согласия достаточно кликнуть по формуле на странице — она скопируется как LaTeX в Markdown. Никаких скрытых включений нет: диалог запроса разрешения — единственный «шаг настройки».
- **Локализация метаданных плагинов**: Имя и описание плагина теперь следуют языку всплывающего окна; карточки в маркетплейсе на сайте — тоже.

### Исправления

- **Смещённая Gemini якорь водяного знака**: Средство удаления водяного знака снова адаптировано к новой позиции якоря в Gemini — сообщения о высокой частоте сбоев в 1.4.7 устранены.
- **Полная остановка водяного знака**: \`stopWatermarkRemover\` теперь освобождает все созданные им observer-ы, таймеры и слушатели, поэтому после отключения состояние «обработка» не зависает.
- **Зона клика переключателя боковой панели**: Восстановлена расширенная зона клика переключателя свёрнутой боковой панели, откатившаяся в прошлом релизе.
- **Заголовки перетаскивания папок**: Заголовки при перетаскивании теперь соответствуют нативному стилю Gemini — и в AI Studio, и в подсказке истории.
- **Выбор папки вверх**: Выбор папок проекта теперь раскрывается вверх, если снизу под триггером нет места.
- **Текст «Удалить из папки»**: Сообщение подтверждения стало яснее — вы убираете диалог из папки, а не удаляете саму папку.
- **Активация подсказок таймлайна**: Подсказки теперь ждут явного наведения, а не вспыхивают при каждой прокрутке.
- **Гейт опциональных разрешений в Firefox**: Пользователи Firefox 116+ снова могут выдавать опциональные разрешения (регрессия от правки Fx<128).
- **Восстановление долговременных бэкапов в Safari**: Восстановление теперь пишет в долговременное хранилище, поэтому бэкапы папок не теряются в 7-дневном окне ITP.
- **Язык тоста «Копировать формулу»**: Тост успеха теперь следует выбранному языку интерфейса, а не локали браузера.
- **Доступность**: Слайдеры, переключатели и оценки получили корректные aria-метки; \`eslint-plugin-jsx-a11y\` теперь обязателен в CI.

### Производительность

- **Ленивая загрузка KaTeX и JSZip**: KaTeX и JSZIP больше не входят в бандл content-script — они подгружаются при первом обращении (предпросмотр формул, экспорт в изображение).
- **Отложенная загрузка marked + KaTeX в превью промпта**: При открытии попапа формулы больше не парсятся сразу.
- **Инициализация водяного знака в idle**: Инициализация observer-а водяного знака уступает \`requestIdleCallback\`, чтобы первая отрисовка оставалась плавной.
- **Пропуск пустой перезаписи при изоляции аккаунтов**: profile-map больше не перезаписывается, если изменений нет.
`;export{e as default};
