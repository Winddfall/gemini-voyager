const a=`<!-- lang:en -->

### What's New

- **Floating folder mode** *(off by default)*: Pop the folder panel out as a draggable floating window instead of injecting it into the sidebar. Toggle from popup → Folder options.
- **AI Studio new nav support**: Folder panel now mounts on AI Studio's refreshed left nav (\`/prompts\` and \`/library\`), restoring the feature after Google's UI change.
- **Hide archived in AI Studio Library**: The \`/library\` table hides conversations already filed into folders.
- **Vim mode for chat input** *(off by default)*: Modal editing keybindings directly in the chat input.
- **Copy Canvas as Markdown**: One-click markdown copy from a Canvas artifact's share menu.

### Fixes

- **Vim mode line editing**: Stabilized cursor behavior at end-of-line.
- **Sidebar auto-hide / full-hide**: The two settings are now independent — toggling one no longer affects the other.

<!-- lang:zh -->

### 新功能

- **悬浮文件夹模式** *（默认关闭）*：把文件夹面板拆成可拖动的悬浮窗，不再注入到侧边栏。弹窗 → 文件夹选项中开启。
- **AI Studio 新导航支持**：文件夹面板适配 AI Studio 改版后的左侧导航（\`/prompts\` 和 \`/library\`），恢复 Google 改版后失效的功能。
- **AI Studio 库页面隐藏已归档**：\`/library\` 表格现在会隐藏已归入文件夹的对话。
- **Vim 模式聊天输入** *（默认关闭）*：在聊天输入框直接使用模态编辑键位。
- **Canvas 复制为 Markdown**：Canvas 作品的分享菜单中新增"复制为 Markdown"。

### 修复

- **Vim 模式行尾编辑**：行尾操作时光标行为更稳定。
- **侧边栏自动隐藏与完全隐藏**：两项设置互相独立，不再相互干扰。

<!-- lang:zh_TW -->

### 新功能

- **浮動資料夾模式** *（預設關閉）*：將資料夾面板拆成可拖曳的浮動視窗，不再注入到側邊欄。彈窗 → 資料夾選項中開啟。
- **AI Studio 新導覽支援**：資料夾面板適配 AI Studio 改版後的左側導覽（\`/prompts\` 與 \`/library\`），恢復 Google 改版後失效的功能。
- **AI Studio 檔案庫隱藏已封存**：\`/library\` 表格會隱藏已歸入資料夾的對話。
- **Vim 模式聊天輸入** *（預設關閉）*：在聊天輸入框直接使用模式編輯鍵位。
- **Canvas 複製為 Markdown**：Canvas 作品的分享選單中新增「複製為 Markdown」。

### 修復

- **Vim 模式行末編輯**：行末操作時游標行為更穩定。
- **側邊欄自動隱藏與完全隱藏**：兩項設定互相獨立，不再互相干擾。

<!-- lang:ja -->

### 新機能

- **フローティングフォルダモード** *（デフォルトでオフ）*：フォルダパネルをサイドバーに埋め込む代わりにドラッグ可能なフローティングウィンドウとして表示します。ポップアップ → フォルダ設定から切替。
- **AI Studio 新ナビ対応**：リニューアルされた AI Studio の左ナビ（\`/prompts\` と \`/library\`）にフォルダパネルが挿入され、Google の UI 変更後も機能が復帰します。
- **AI Studio ライブラリでアーカイブを非表示**：\`/library\` のテーブルで、すでにフォルダに振り分けた会話を非表示にします。
- **チャット入力の Vim モード** *（デフォルトでオフ）*：チャット入力欄でモーダル編集キーバインドを使えます。
- **Canvas を Markdown としてコピー**：Canvas アーティファクトの共有メニューからワンクリックで Markdown をコピー。

### 修正

- **Vim モードの行末編集**：行末でのカーソル挙動が安定しました。
- **サイドバー自動非表示／完全非表示**：両設定が独立し、一方の切替がもう一方に影響しなくなりました。

<!-- lang:fr -->

### Nouveautés

- **Mode dossier flottant** *(désactivé par défaut)* : Ouvrez le panneau des dossiers dans une fenêtre flottante déplaçable au lieu de l'injecter dans la barre latérale. Activable depuis popup → Options de dossiers.
- **Prise en charge de la nouvelle navigation AI Studio** : Le panneau des dossiers s'intègre désormais à la nouvelle barre latérale AI Studio (\`/prompts\` et \`/library\`), rétablissant la fonctionnalité après le changement d'UI de Google.
- **Masquer les conversations archivées dans la bibliothèque AI Studio** : Le tableau \`/library\` masque les conversations déjà classées dans des dossiers.
- **Mode Vim dans la saisie** *(désactivé par défaut)* : Raccourcis d'édition modale directement dans le champ de saisie.
- **Copier un Canvas en Markdown** : Copie Markdown en un clic depuis le menu de partage d'un artefact Canvas.

### Corrections

- **Édition Vim en fin de ligne** : Stabilisation du comportement du curseur en fin de ligne.
- **Masquage automatique vs masquage complet de la sidebar** : Les deux réglages sont désormais indépendants — l'activation de l'un n'affecte plus l'autre.

<!-- lang:es -->

### Novedades

- **Modo de carpetas flotantes** *(desactivado por defecto)*: Muestra el panel de carpetas como una ventana flotante arrastrable en lugar de inyectarlo en la barra lateral. Actívalo desde popup → Opciones de carpetas.
- **Compatibilidad con la nueva navegación de AI Studio**: El panel de carpetas se integra con la nueva navegación lateral de AI Studio (\`/prompts\` y \`/library\`), restaurando la funcionalidad tras el cambio de UI de Google.
- **Ocultar archivadas en la biblioteca de AI Studio**: La tabla \`/library\` oculta las conversaciones ya clasificadas en carpetas.
- **Modo Vim en la entrada** *(desactivado por defecto)*: Atajos de edición modal directamente en el cuadro de entrada.
- **Copiar Canvas como Markdown**: Copia Markdown con un clic desde el menú de compartir de un artefacto Canvas.

### Correcciones

- **Edición Vim al final de línea**: Comportamiento del cursor estabilizado al final de la línea.
- **Ocultación automática y total de la barra lateral**: Ambos ajustes son ahora independientes — activar uno no afecta al otro.

<!-- lang:pt -->

### Novidades

- **Modo de pastas flutuantes** *(desativado por padrão)*: Mostra o painel de pastas como uma janela flutuante arrastável em vez de injetá-lo na barra lateral. Ative em popup → Opções de pastas.
- **Compatibilidade com a nova navegação do AI Studio**: O painel de pastas integra-se com a nova navegação lateral do AI Studio (\`/prompts\` e \`/library\`), restaurando a funcionalidade após a mudança de UI do Google.
- **Ocultar arquivadas na biblioteca do AI Studio**: A tabela \`/library\` oculta as conversas já classificadas em pastas.
- **Modo Vim na entrada** *(desativado por padrão)*: Atalhos de edição modal diretamente no campo de entrada.
- **Copiar Canvas como Markdown**: Cópia em Markdown com um clique a partir do menu de partilha de um artefacto Canvas.

### Correções

- **Edição Vim no final da linha**: Comportamento do cursor estabilizado no final da linha.
- **Ocultação automática e total da barra lateral**: As duas configurações são agora independentes — ativar uma já não afeta a outra.

<!-- lang:ar -->

### الجديد

- **وضع المجلدات العائم** *(مُعطَّل افتراضيًا)*: اعرض لوحة المجلدات كنافذة عائمة قابلة للسحب بدلاً من إدراجها في الشريط الجانبي. فعِّل من النافذة المنبثقة ← خيارات المجلدات.
- **دعم تنقّل AI Studio الجديد**: لوحة المجلدات تعمل الآن مع الشريط الجانبي الجديد لـ AI Studio (\`/prompts\` و \`/library\`)، ما يعيد الميزة بعد تغيير واجهة Google.
- **إخفاء المؤرشفة في مكتبة AI Studio**: جدول \`/library\` يخفي المحادثات التي سبق تصنيفها في مجلدات.
- **وضع Vim لمربع الإدخال** *(مُعطَّل افتراضيًا)*: اختصارات التحرير الوضعية مباشرة في مربع إدخال المحادثة.
- **نسخ Canvas كـ Markdown**: نسخ Markdown بنقرة واحدة من قائمة مشاركة محتوى Canvas.

### الإصلاحات

- **تحرير Vim في نهاية السطر**: استقرار سلوك المؤشر عند نهاية السطر.
- **الإخفاء التلقائي / الإخفاء الكامل للشريط الجانبي**: أصبح الإعدادان مستقلَّين — تفعيل أحدهما لم يعد يؤثر على الآخر.

<!-- lang:ko -->

### 새로운 기능

- **플로팅 폴더 모드** *(기본값: 꺼짐)*: 폴더 패널을 사이드바에 주입하지 않고 드래그 가능한 플로팅 창으로 표시합니다. 팝업 → 폴더 옵션에서 켜세요.
- **AI Studio 새 내비게이션 지원**: 폴더 패널이 새로 개편된 AI Studio 왼쪽 내비게이션(\`/prompts\` 및 \`/library\`)에 장착되어, Google UI 변경 이후 기능이 복구됩니다.
- **AI Studio 라이브러리에서 보관됨 숨기기**: \`/library\` 테이블에서 이미 폴더에 정리된 대화를 숨깁니다.
- **채팅 입력창 Vim 모드** *(기본값: 꺼짐)*: 채팅 입력창에서 직접 모달 편집 단축키를 사용합니다.
- **Canvas를 Markdown으로 복사**: Canvas 아티팩트의 공유 메뉴에서 한 번에 Markdown으로 복사.

### 수정

- **Vim 모드 줄 끝 편집**: 줄 끝에서의 커서 동작이 안정화되었습니다.
- **사이드바 자동 숨김과 완전 숨김**: 두 설정이 서로 독립적으로 작동하며, 한쪽을 켜도 다른 쪽에 영향을 주지 않습니다.

<!-- lang:ru -->

### Новое

- **Плавающий режим папок** *(по умолчанию выключено)*: Показывать панель папок как перетаскиваемое плавающее окно вместо внедрения в боковую панель. Включается в попапе → Настройки папок.
- **Поддержка новой навигации AI Studio**: Панель папок теперь работает в обновлённой левой навигации AI Studio (\`/prompts\` и \`/library\`), восстанавливая функцию после изменения интерфейса Google.
- **Скрытие архивных в библиотеке AI Studio**: Таблица \`/library\` скрывает разговоры, уже помещённые в папки.
- **Режим Vim в поле ввода** *(по умолчанию выключено)*: Модальные клавиши редактирования прямо в поле ввода чата.
- **Копировать Canvas как Markdown**: Копирование в Markdown одним кликом из меню «Поделиться» артефакта Canvas.

### Исправления

- **Редактирование в конце строки в Vim-режиме**: Стабилизировано поведение курсора в конце строки.
- **Автоскрытие и полное скрытие боковой панели**: Настройки теперь независимы — включение одной не влияет на другую.
`;export{a as default};
