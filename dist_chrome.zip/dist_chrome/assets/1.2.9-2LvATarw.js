const n=`<!-- lang:en -->

### Highlights

- From now on, every release will have clear and easy-to-understand release notes. (The author noticed that silent updates made many users think plugin features, like auto-selecting the default model, were native to Gemini.)
- There's now a ❄️ effect in Settings—bring some winter vibes to your Gemini! (More lightweight visual effects coming soon.)
- Experimental conversation branches are now supported (see docs for info).
- Fixed several bugs.
- The plugin’s promo image below was made using Pencil—feel free to share it!

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner.png)

<!-- lang:zh -->

### 亮点

- 从现在起每个版本会有便于理解的更新说明（作者发现静默更新会让很多用户把插件功能当成 Gemini 的原生功能，比如自动选择默认模型）
- 设置里增加了一个❄️效果，让你的 Gemini 更有冬日情趣吧（后续会支持更多轻量特效）
- 支持实验性的对话分支功能（详情见文档）。
- 修复了若干 Bug
- 用 Pencil 制作了插件的宣传图如下，欢迎分享！

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner-cn.png)

<!-- lang:zh_TW -->

### 亮點

- 從現在起每個版本會有便於理解的更新說明（作者發現靜默更新會讓許多用戶把插件功能當成 Gemini 的原生功能，比如自動選擇預設模型）
- 設定中新增了❄️效果，讓你的 Gemini 更添冬日氛圍！（後續將支持更多輕量特效）
- 支援實驗性的對話分支功能（詳情請見文件）。
- 修復了若干 Bug
- 用 Pencil 製作了插件的宣傳圖如下，歡迎分享！

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner-cn.png)

<!-- lang:ja -->

### ハイライト

- 今後は各バージョンごとに分かりやすいリリースノートを用意します（サイレントアップデートにより多くのユーザーがプラグインの機能（例：デフォルトモデルの自動選択）を Gemini の標準機能だと誤解していました）
- 設定に❄️エフェクトを追加しました。Gemini に冬の雰囲気をどうぞ！（今後も軽量な演出を追加予定）
- 実験的な会話分岐機能をサポート（詳細はドキュメント参照）。
- いくつかのバグを修正しました。
- Pencil で作成したプロモーション画像をご自由に共有ください！

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner-jp.png)

<!-- lang:fr -->

### Points forts

- Désormais, chaque version aura des notes de version faciles à comprendre (l’auteur a constaté que les mises à jour silencieuses faisaient croire à de nombreux utilisateurs que certaines fonctionnalités du plugin, comme la sélection automatique du modèle par défaut, faisaient partie intégrante de Gemini).
- Un effet ❄️ est disponible dans les paramètres, pour donner une touche hivernale à votre Gemini ! (D’autres petits effets seront ajoutés à l’avenir)
- Prise en charge expérimentale des branches de conversation (voir la documentation).
- Correction de plusieurs bugs.
- L’image promotionnelle du plugin ci-dessous a été créée avec Pencil—n’hésitez pas à la partager !

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner.png)

<!-- lang:es -->

### Destacados

- A partir de ahora, cada versión tendrá notas de lanzamiento fáciles de entender (el autor notó que las actualizaciones silenciosas hacían que muchos usuarios pensaran que funciones del complemento, como la selección automática del modelo predeterminado, eran nativas de Gemini).
- ¡Nuevo efecto ❄️ en la configuración! Dale un toque invernal a tu Gemini. (Próximamente más efectos ligeros)
- Ahora se admite la función experimental de ramas de conversación (ver documentación).
- Corregidos varios errores.
- La imagen promocional del complemento, creada con Pencil, está a continuación. ¡Siéntete libre de compartirla!

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner.png)

<!-- lang:pt -->

### Destaques

- A partir de agora, cada lançamento terá notas de atualização fáceis de entender (o autor percebeu que atualizações silenciosas faziam muitos usuários pensarem que recursos do plugin, como seleção automática do modelo padrão, eram nativos do Gemini).
- Agora há um efeito de ❄️ nas configurações—deixe seu Gemini com clima de inverno! (Mais efeitos leves em breve)
- Suporte experimental para ramificações de conversa (veja a documentação).
- Diversos bugs corrigidos.
- A imagem promocional do plugin abaixo foi criada no Pencil—sinta-se à vontade para compartilhá-la!

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner.png)

<!-- lang:ar -->

### أبرز التحديثات

- بدءًا من الآن، ستحتوي كل نسخة على ملاحظات تحديث واضحة وسهلة الفهم (لاحظ المؤلف أن التحديثات الصامتة جعلت العديد من المستخدمين يظنون أن بعض ميزات الإضافة، مثل اختيار النموذج الافتراضي آليًا، هي من وظائف Gemini الأصلية).
- يمكنك الآن تفعيل تأثير ❄️ في الإعدادات لإضفاء أجواء شتوية على Gemini (سيتم دعم المزيد من التأثيرات الخفيفة مستقبلًا).
- دعم ميزة تجريبية لتفرعات المحادثة (راجع الوثائق للمزيد).
- تم إصلاح عدد من الأخطاء البرمجية.
- تم إعداد صورة ترويجية للإضافة باستخدام Pencil — لا تتردد في مشاركتها!

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner.png)

<!-- lang:ru -->

### Основные изменения

- Начиная с этой версии, для каждого выпуска будут подробные и понятные заметки о релизе (автор заметил, что из-за тихих обновлений многие пользователи считали функции плагина, такие как автоматический выбор модели по умолчанию, родными для Gemini).
- В настройках появился эффект ❄️ — добавьте зимнее настроение своему Gemini! (В будущем появятся и другие лёгкие визуальные эффекты)
- Добавлена экспериментальная поддержка ветвления диалогов (подробности в документации).
- Исправлено несколько ошибок.
- Промо-изображение плагина ниже создано в Pencil — делитесь им свободно!

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner.png)

<!-- lang:ko -->

### 주요 변경사항

- 이제부터 각 버전별로 이해하기 쉬운 업데이트 노트를 제공합니다 (조용한 업데이트로 인해 많은 사용자가 자동 기본 모델 선택 등 플러그인 기능을 Gemini 의 기본 기능으로 착각하는 일이 있었습니다).
- 설정에 ❄️ 효과가 추가되어 Gemini 에 겨울 분위기를 더할 수 있습니다! (추가 가벼운 효과도 곧 지원될 예정이에요)
- 실험적인 대화 분기 기능이 추가되었습니다 (자세한 내용은 문서 참고).
- 여러 버그가 수정되었습니다.
- 플러그인 홍보 이미지는 아래와 같이 Pencil 로 제작하였습니다. 자유롭게 공유하세요!

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner-KO.png)
`;export{n as default};
