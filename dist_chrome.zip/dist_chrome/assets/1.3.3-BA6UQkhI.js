const n=`<!-- lang:en -->

### Highlights

- Fixed drag-and-drop onto conversations inside folders not working correctly.
- Fixed AI Studio history titles being lost when dragging into folders.
- Fixed chat width input-container gradient not extending to match custom chat width.

<!-- lang:zh -->

### 亮点

- 修复拖拽对话到文件夹内的对话上不生效的问题。
- 修复将 AI Studio 历史记录拖入文件夹时标题丢失的问题。
- 修复聊天宽度调整后输入框渐变未跟随扩展的问题。

<!-- lang:zh_TW -->

### 亮點

- 修復拖曳對話到資料夾內的對話上不生效的問題。
- 修復將 AI Studio 歷史紀錄拖入資料夾時標題遺失的問題。
- 修復聊天寬度調整後輸入框漸層未跟隨擴展的問題。

<!-- lang:ja -->

### ハイライト

- フォルダ内の会話へのドラッグ＆ドロップが正しく動作しない問題を修正。
- AI Studio の履歴タイトルがフォルダにドラッグした際に失われる問題を修正。
- チャット幅の入力コンテナグラデーションがカスタム幅に合わせて拡張されない問題を修正。

<!-- lang:fr -->

### Points forts

- Correction du glisser-deposer sur les conversations a l'interieur des dossiers qui ne fonctionnait pas correctement.
- Correction de la perte des titres d'historique AI Studio lors du glissement dans les dossiers.
- Correction du degrade du conteneur de saisie qui ne s'etendait pas pour correspondre a la largeur de chat personnalisee.

<!-- lang:es -->

### Destacados

- Corregido el arrastrar y soltar sobre conversaciones dentro de carpetas que no funcionaba correctamente.
- Corregida la perdida de titulos del historial de AI Studio al arrastrar a carpetas.
- Corregido el degradado del contenedor de entrada que no se extendia para coincidir con el ancho de chat personalizado.

<!-- lang:pt -->

### Destaques

- Corrigido o arrastar e soltar em conversas dentro de pastas que nao funcionava corretamente.
- Corrigida a perda de titulos do historico do AI Studio ao arrastar para pastas.
- Corrigido o gradiente do contêiner de entrada que nao se estendia para corresponder a largura de chat personalizada.

<!-- lang:ar -->

### أبرز التحديثات

- إصلاح السحب والإفلات على المحادثات داخل المجلدات الذي لم يكن يعمل بشكل صحيح.
- إصلاح فقدان عناوين سجل AI Studio عند السحب إلى المجلدات.
- إصلاح تدرج حاوية الإدخال الذي لم يمتد ليتوافق مع عرض الدردشة المخصص.

<!-- lang:ru -->

### Основные изменения

- Исправлено перетаскивание на беседы внутри папок, которое не работало корректно.
- Исправлена потеря заголовков истории AI Studio при перетаскивании в папки.
- Исправлен градиент контейнера ввода, который не расширялся в соответствии с пользовательской шириной чата.

<!-- lang:ko -->

### 주요 변경사항

- 폴더 내 대화에 드래그 앤 드롭이 올바르게 작동하지 않는 문제 수정.
- AI Studio 기록 제목이 폴더로 드래그할 때 손실되는 문제 수정.
- 채팅 너비에 맞게 입력 컨테이너 그라데이션이 확장되지 않는 문제 수정.
`;export{n as default};
