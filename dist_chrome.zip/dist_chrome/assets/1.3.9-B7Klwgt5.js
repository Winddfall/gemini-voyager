const e=`<!-- lang:en -->

### What's New

- **Pinned timeline preview**: You can now keep the timeline preview panel pinned from the popup.
- **Configurable timeline jump shortcuts**: Customize the shortcut keys used to jump through the timeline.

### Fixes

- **Experimental node hierarchy**: Timeline node hierarchy state now persists separately for each account.
- **Nested folder moves**: Moving folders with child folders now works correctly.
- **Firefox permission flow**: Fixed permission request handling for Firefox.

<!-- lang:zh -->

### 新功能

- **时间线预览固定**：现在可以在弹窗中将时间线预览面板固定显示。
- **时间线跳转快捷键可配置**：可自定义在时间线中跳转使用的快捷键。

### 修复

- **实验性节点层级**：时间线节点层级状态现在会按不同账号分别持久化保存。
- **嵌套文件夹移动**：现在可以正确移动带有子文件夹的文件夹。
- **Firefox 权限流程**：修复了 Firefox 中的权限请求处理问题。

<!-- lang:zh_TW -->

### 新功能

- **固定時間線預覽**：現在可以在彈窗中將時間線預覽面板固定顯示。
- **時間線跳轉快捷鍵可自訂**：可自訂在時間線中跳轉所使用的快捷鍵。

### 修復

- **實驗性節點層級**：時間線節點層級狀態現在會依不同帳號分別持久化保存。
- **巢狀資料夾移動**：現在可以正確移動帶有子資料夾的資料夾。
- **Firefox 權限流程**：修復了 Firefox 中的權限請求處理問題。

<!-- lang:ja -->

### 新機能

- **タイムラインプレビューの固定表示**：ポップアップからタイムラインのプレビューパネルを固定できるようになりました。
- **タイムライン移動ショートカットの設定**：タイムライン移動に使うショートカットキーをカスタマイズできます。

### 修正

- **実験的なノード階層**：タイムラインのノード階層状態がアカウントごとに個別保存されるようになりました。
- **ネストしたフォルダの移動**：子フォルダを含むフォルダを正しく移動できるようになりました。
- **Firefox の権限フロー**：Firefox での権限リクエスト処理を修正しました。

<!-- lang:fr -->

### Nouveautés

- **Aperçu de timeline épinglable** : Vous pouvez désormais garder le panneau d’aperçu de la timeline épinglé depuis le popup.
- **Raccourcis de navigation configurables** : Vous pouvez personnaliser les raccourcis utilisés pour naviguer dans la timeline.

### Corrections

- **Hiérarchie expérimentale des nœuds** : L’état de la hiérarchie des nœuds de la timeline est maintenant conservé séparément pour chaque compte.
- **Déplacement des dossiers imbriqués** : Le déplacement des dossiers contenant des sous-dossiers fonctionne désormais correctement.
- **Flux d’autorisation Firefox** : Correction de la gestion des demandes d’autorisation sur Firefox.

<!-- lang:es -->

### Novedades

- **Vista previa de la línea de tiempo fijable**: Ahora puedes mantener fijado el panel de vista previa de la línea de tiempo desde el popup.
- **Atajos configurables para navegar**: Ahora puedes personalizar los atajos usados para moverte por la línea de tiempo.

### Correcciones

- **Jerarquía experimental de nodos**: El estado de la jerarquía de nodos de la línea de tiempo ahora se guarda por separado para cada cuenta.
- **Movimiento de carpetas anidadas**: Ahora mover carpetas con subcarpetas funciona correctamente.
- **Flujo de permisos en Firefox**: Se corrigió el manejo de solicitudes de permisos en Firefox.

<!-- lang:pt -->

### Novidades

- **Pré-visualização da timeline fixável**: Agora pode manter o painel de pré-visualização da timeline fixado a partir do popup.
- **Atalhos configuráveis para navegação**: Agora pode personalizar os atalhos usados para navegar na timeline.

### Correções

- **Hierarquia experimental de nós**: O estado da hierarquia de nós da timeline passa agora a ser guardado separadamente para cada conta.
- **Mover pastas aninhadas**: Mover pastas com subpastas agora funciona corretamente.
- **Fluxo de permissões no Firefox**: Corrigido o tratamento dos pedidos de permissão no Firefox.

<!-- lang:ar -->

### الجديد

- **تثبيت معاينة الخط الزمني**: يمكنك الآن تثبيت لوحة معاينة الخط الزمني من النافذة المنبثقة.
- **اختصارات قابلة للتخصيص للتنقل**: يمكنك الآن تخصيص الاختصارات المستخدمة للتنقل داخل الخط الزمني.

### الإصلاحات

- **الهيكل الهرمي التجريبي للعُقد**: أصبحت حالة الهيكل الهرمي لعُقد الخط الزمني تُحفظ الآن بشكل منفصل لكل حساب.
- **نقل المجلدات المتداخلة**: أصبح نقل المجلدات التي تحتوي على مجلدات فرعية يعمل بشكل صحيح.
- **تدفق الأذونات في Firefox**: تم إصلاح معالجة طلبات الأذونات في Firefox.

<!-- lang:ko -->

### 새로운 기능

- **타임라인 미리보기 고정**: 이제 팝업에서 타임라인 미리보기 패널을 고정해 둘 수 있습니다.
- **타임라인 이동 단축키 설정**: 타임라인 이동에 사용할 단축키를 직접 설정할 수 있습니다.

### 수정

- **실험적 노드 계층**: 타임라인 노드 계층 상태가 이제 계정별로 따로 저장됩니다.
- **중첩 폴더 이동**: 하위 폴더가 있는 폴더도 이제 정상적으로 이동할 수 있습니다.
- **Firefox 권한 흐름**: Firefox에서 권한 요청 처리 문제를 수정했습니다.

<!-- lang:ru -->

### Новое

- **Закрепляемая панель предпросмотра таймлайна**: Теперь панель предпросмотра таймлайна можно закрепить из попапа.
- **Настраиваемые горячие клавиши навигации**: Теперь можно настроить клавиши для перемещения по таймлайну.

### Исправления

- **Экспериментальная иерархия узлов**: Состояние иерархии узлов таймлайна теперь сохраняется отдельно для каждого аккаунта.
- **Перемещение вложенных папок**: Перемещение папок с дочерними папками теперь работает корректно.
- **Поток разрешений в Firefox**: Исправлена обработка запросов разрешений в Firefox.
`;export{e as default};
