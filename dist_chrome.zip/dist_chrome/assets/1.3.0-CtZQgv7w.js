const n=`<!-- lang:en -->

### Highlights

- Added RTL (right-to-left) layout support for Arabic, Hebrew, Farsi, and Urdu users — the timeline, tooltips, and preview panel now adapt correctly. If you're a native speaker and notice anything that doesn't feel right, feel free to open an issue or PR!
- Fixed several bugs in the timeline, prompt manager, and fork features.
- Experimental conversation branches are now supported (see docs for info).

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner.png)

<!-- lang:zh -->

### 亮点

- 新增对阿拉伯语、希伯来语、波斯语、乌尔都语等从右到左（RTL）语言的布局支持——时间轴、提示框和预览面板现在可以正确适配。如果母语用户在使用中发现插件有适配不好的地方，随时欢迎提交 issue 或 PR，让我们一起获得更好的体验。
- 修复了时间轴、提示词管理器和对话分支等功能的若干 Bug。
- 支持实验性的对话分支功能（详情见文档）。

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner-cn.png)

<!-- lang:zh_TW -->

### 亮點

- 新增阿拉伯語、希伯來語、波斯語、烏爾都語等從右至左（RTL）語言的佈局支援——時間軸、提示框和預覽面板現已正確適配。如果母語用戶在使用中發現插件有適配不好的地方，隨時歡迎提交 issue 或 PR，讓我們一起獲得更好的體驗。
- 修復了時間軸、提示詞管理器和對話分支等功能的若干 Bug。
- 支援實驗性的對話分支功能（詳情請見文件）。

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner-cn.png)

<!-- lang:ja -->

### ハイライト

- アラビア語・ヘブライ語・ペルシャ語・ウルドゥー語などの RTL（右から左）レイアウトに対応しました。タイムライン・ツールチップ・プレビューパネルが正しく適応します。母語話者の方でお気づきの点があれば、気軽に issue や PR をどうぞ！
- タイムライン・プロンプト管理・会話分岐機能のバグをいくつか修正しました。
- 実験的な会話分岐機能をサポート（詳細はドキュメント参照）。

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner-jp.png)

<!-- lang:fr -->

### Points forts

- Ajout du support de la mise en page RTL (de droite à gauche) pour les utilisateurs arabophones, hébraïques, persans et ourdous — la timeline, les infobulles et le panneau de prévisualisation s'adaptent désormais correctement. Si vous êtes locuteur natif et remarquez un problème d'adaptation, n'hésitez pas à ouvrir une issue ou une PR !
- Correction de plusieurs bugs dans la timeline, le gestionnaire de prompts et les branches de conversation.
- Prise en charge expérimentale des branches de conversation (voir la documentation).

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner.png)

<!-- lang:es -->

### Destacados

- Se añade compatibilidad con el diseño RTL (de derecha a izquierda) para usuarios de árabe, hebreo, persa y urdu — la línea de tiempo, las sugerencias y el panel de vista previa ahora se adaptan correctamente. Si eres hablante nativo y notas algo que no se adapta bien, ¡abre un issue o PR cuando quieras!
- Corrección de varios errores en la línea de tiempo, el gestor de prompts y las ramas de conversación.
- Ahora se admite la función experimental de ramas de conversación (ver documentación).

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner.png)

<!-- lang:pt -->

### Destaques

- Suporte a layout RTL (da direita para a esquerda) para usuários de árabe, hebraico, persa e urdu — a linha do tempo, as dicas e o painel de pré-visualização agora se adaptam corretamente. Se você é falante nativo e perceber algo que não está bem adaptado, fique à vontade para abrir uma issue ou PR!
- Corrigidos vários erros na linha do tempo, no gerenciador de prompts e nas ramificações de conversa.
- Suporte experimental para ramificações de conversa (veja a documentação).

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner.png)

<!-- lang:ar -->

### أبرز التحديثات

- إضافة دعم تخطيط RTL (من اليمين إلى اليسار) لمستخدمي اللغات العربية والعبرية والفارسية والأردية — يتكيف شريط الزمن ونصائح الأدوات ولوحة المعاينة الآن بشكل صحيح. إذا لاحظت كمستخدم متحدث أصلي أي مشكلة في التكيف، فلا تتردد في فتح issue أو تقديم PR!
- تم إصلاح عدد من الأخطاء في شريط الزمن وإدارة التعليمات والمحادثات المتفرعة.
- دعم ميزة تجريبية لتفرعات المحادثة (راجع الوثائق للمزيد).

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner.png)

<!-- lang:ru -->

### Основные изменения

- Добавлена поддержка RTL-макета (справа налево) для пользователей арабского, иврита, персидского и урду — временная шкала, подсказки и панель предпросмотра теперь корректно адаптируются. Если вы носитель языка и заметили что-то требующее доработки, смело открывайте issue или PR!
- Исправлено несколько ошибок в таймлайне, менеджере промптов и ветвлении диалогов.
- Добавлена экспериментальная поддержка ветвления диалогов (подробности в документации).

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner.png)

<!-- lang:ko -->

### 주요 변경사항

- 아랍어, 히브리어, 페르시아어, 우르두어 사용자를 위한 RTL(오른쪽에서 왼쪽) 레이아웃 지원이 추가되었습니다 — 타임라인, 툴팁, 미리보기 패널이 이제 올바르게 적응합니다. 해당 언어 원어민 사용자로서 적응이 잘 되지 않는 부분을 발견하시면 언제든지 issue나 PR을 열어주세요!
- 타임라인, 프롬프트 관리자, 대화 분기 기능의 여러 버그를 수정했습니다.
- 실험적인 대화 분기 기능이 추가되었습니다 (자세한 내용은 문서 참고).

![banner](https://github.com/Nagi-ovo/voyager/raw/main/docs/public/assets/promotion/Promo-Banner-KO.png)
`;export{n as default};
