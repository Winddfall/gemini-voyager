const e=`<!-- lang:en -->

### What's New

- **Claude usage bar**: New plugin that shows your current-session and weekly usage bars on Claude pages, styled to match Gemini's usage display.
- **Collapsible folders section**: Collapse the folders section in the sidebar to save space.

### Fixes

- **Steadier auto-scroll prevention**: Now respects Ctrl+Enter send mode and keeps the sidebar history scrollable.
- **Sidebar close button**: Fixed the close button not responding to clicks.
- **More accurate usage stats**: Gemini usage now maps to the correct period.
- **Default model marker**: No longer shows up by mistake on table option menus.
- **Notification false positives**: Copy actions no longer trip the notification keyword match.
- **Formula hover color**: Uses your site's accent color.
- **Math export**: Preserves Gemini's KaTeX radicals (√) and layout, including image exports.
- **Gems sidebar**: Automatically prunes deleted entries.

---

> *"From now on, I think I'll make this a journey to get to know people." — Frieren, 《Frieren: Beyond Journey's End》*

<!-- lang:zh -->

### 新功能

- **Claude 用量条**：新增插件，在 Claude 页面显示当前会话和每周用量进度条，风格与 Gemini 用量一致。
- **文件夹区可折叠**：可以折叠侧边栏的文件夹区，节省空间。

### 修复

- **防自动滚动更稳**：现在会尊重 Ctrl+Enter 发送模式，侧边栏历史也保持可滚动。
- **侧边栏关闭按钮**：修复了关闭按钮点击无效的问题。
- **用量统计更准**：Gemini 用量现在按正确的周期归类。
- **默认模型标记**：不再错误出现在表格选项菜单上。
- **通知误报**：复制操作不再触发通知的关键词误匹配。
- **公式悬停配色**：改用你所在站点的强调色。
- **导出数学公式**：导出时保留 Gemini 的 KaTeX 根号（√）与布局，包括图片导出。
- **Gems 侧边栏**：自动清除已删除的条目。

---

> *“从今往后，我想让这趟旅程，成为一段去了解他人的旅程。” —— 芙莉莲，《葬送的芙莉莲》*

<!-- lang:zh_TW -->

### 新功能

- **Claude 用量條**：新增外掛，在 Claude 頁面顯示目前工作階段和每週用量進度條，風格與 Gemini 用量一致。
- **資料夾區可折疊**：可以折疊側邊欄的資料夾區，節省空間。

### 修復

- **防自動捲動更穩**：現在會尊重 Ctrl+Enter 傳送模式，側邊欄歷史也保持可捲動。
- **側邊欄關閉按鈕**：修復了關閉按鈕點擊無效的問題。
- **用量統計更準**：Gemini 用量現在按正確的週期歸類。
- **預設模型標記**：不再錯誤出現在表格選項選單上。
- **通知誤報**：複製操作不再觸發通知的關鍵字誤比對。
- **公式懸停配色**：改用你所在網站的強調色。
- **匯出數學公式**：匯出時保留 Gemini 的 KaTeX 根號（√）與版面，包括圖片匯出。
- **Gems 側邊欄**：自動清除已刪除的項目。

---

> *「從今以後，我想讓這趟旅程，成為一段去了解他人的旅程。」——芙莉蓮，《葬送的芙莉蓮》*

<!-- lang:ja -->

### 新機能

- **Claude 使用量バー**：新しいプラグインで、Claude ページに現在のセッションと週次の使用量バーを表示します（Gemini の使用量表示に合わせたスタイル）。
- **フォルダーセクションの折りたたみ**：サイドバーのフォルダーセクションを折りたたんでスペースを節約できます。

### 修正

- **自動スクロール防止をより安定に**：Ctrl+Enter の送信モードを尊重し、サイドバーの履歴もスクロール可能なままにします。
- **サイドバーの閉じるボタン**：閉じるボタンをクリックしても反応しない問題を修正しました。
- **使用量統計をより正確に**：Gemini の使用量が正しい期間に対応づけられます。
- **既定モデルの印**：テーブルのオプションメニューに誤って表示されなくなりました。
- **通知の誤検知**：コピー操作が通知のキーワード一致を誤って発火しなくなりました。
- **数式ホバーの配色**：サイトのアクセントカラーを使用します。
- **数式のエクスポート**：エクスポート時に Gemini の KaTeX の根号（√）とレイアウトを保持します（画像エクスポートを含む）。
- **Gems サイドバー**：削除された項目を自動的に整理します。

---

> *「これからは、人を知るための旅にしようと思う。」——フリーレン、《葬送のフリーレン》*

<!-- lang:fr -->

### Nouveautés

- **Barre d'utilisation Claude** : Nouveau plugin qui affiche vos barres d'utilisation de la session en cours et hebdomadaire sur les pages Claude, dans le style de l'affichage d'utilisation de Gemini.
- **Section des dossiers repliable** : Repliez la section des dossiers de la barre latérale pour gagner de la place.

### Corrections

- **Prévention du défilement automatique plus stable** : Respecte désormais le mode d'envoi Ctrl+Entrée et garde l'historique de la barre latérale défilable.
- **Bouton de fermeture de la barre latérale** : Correction du bouton de fermeture qui ne répondait pas aux clics.
- **Statistiques d'utilisation plus précises** : L'utilisation Gemini est associée à la bonne période.
- **Marqueur du modèle par défaut** : N'apparaît plus par erreur dans les menus d'options des tableaux.
- **Faux positifs de notification** : Les actions de copie ne déclenchent plus la correspondance de mots-clés des notifications.
- **Couleur au survol des formules** : Utilise la couleur d'accent de votre site.
- **Export des maths** : Préserve les radicaux KaTeX (√) et la mise en page de Gemini lors de l'export, y compris les exports d'image.
- **Barre latérale Gems** : Élimine automatiquement les entrées supprimées.

---

> *« Désormais, je veux faire de ce voyage un voyage pour apprendre à connaître les gens. » — Frieren, 《Frieren: Beyond Journey's End》*

<!-- lang:es -->

### Novedades

- **Barra de uso de Claude**: Nuevo plugin que muestra tus barras de uso de la sesión actual y semanal en las páginas de Claude, con el estilo del uso de Gemini.
- **Sección de carpetas plegable**: Pliega la sección de carpetas de la barra lateral para ahorrar espacio.

### Correcciones

- **Prevención de desplazamiento automático más estable**: Ahora respeta el modo de envío Ctrl+Intro y mantiene desplazable el historial de la barra lateral.
- **Botón de cerrar de la barra lateral**: Se corrigió que el botón de cerrar no respondía a los clics.
- **Estadísticas de uso más precisas**: El uso de Gemini se asigna al periodo correcto.
- **Marcador del modelo predeterminado**: Ya no aparece por error en los menús de opciones de las tablas.
- **Falsos positivos de notificación**: Las acciones de copiar ya no activan la coincidencia de palabras clave de las notificaciones.
- **Color al pasar el cursor sobre fórmulas**: Usa el color de acento de tu sitio.
- **Exportación de matemáticas**: Conserva los radicales KaTeX (√) y el diseño de Gemini al exportar, incluidas las exportaciones de imagen.
- **Barra lateral de Gems**: Elimina automáticamente las entradas borradas.

---

> *« De ahora en adelante, quiero que este viaje sea un viaje para conocer a las personas. » — Frieren, 《Frieren: Beyond Journey's End》*

<!-- lang:pt -->

### Novidades

- **Barra de uso do Claude**: Novo plugin que mostra suas barras de uso da sessão atual e semanal nas páginas do Claude, no estilo do uso do Gemini.
- **Seção de pastas recolhível**: Recolha a seção de pastas na barra lateral para economizar espaço.

### Correções

- **Prevenção de rolagem automática mais estável**: Agora respeita o modo de envio Ctrl+Enter e mantém o histórico da barra lateral rolável.
- **Botão de fechar da barra lateral**: Corrigido o botão de fechar que não respondia aos cliques.
- **Estatísticas de uso mais precisas**: O uso do Gemini é mapeado para o período correto.
- **Marcador do modelo padrão**: Não aparece mais por engano nos menus de opções das tabelas.
- **Falsos positivos de notificação**: As ações de copiar não disparam mais a correspondência de palavras-chave das notificações.
- **Cor ao passar o mouse sobre fórmulas**: Usa a cor de destaque do seu site.
- **Exportação de matemática**: Preserva os radicais KaTeX (√) e o layout do Gemini ao exportar, incluindo exportações de imagem.
- **Barra lateral do Gems**: Remove automaticamente as entradas excluídas.

---

> *« De agora em diante, quero que esta jornada seja uma jornada para conhecer as pessoas. » — Frieren, 《Frieren: Beyond Journey's End》*

<!-- lang:ar -->

### الجديد

- **شريط استخدام Claude**: إضافة جديدة تعرض أشرطة استخدام الجلسة الحالية والأسبوعية في صفحات Claude، بنمط مطابق لعرض استخدام Gemini.
- **إمكانية طي قسم المجلدات**: اطوِ قسم المجلدات في الشريط الجانبي لتوفير المساحة.

### الإصلاحات

- **منع التمرير التلقائي بثبات أكبر**: يحترم الآن وضع الإرسال بـ Ctrl+Enter ويُبقي سجل الشريط الجانبي قابلًا للتمرير.
- **زر إغلاق الشريط الجانبي**: تم إصلاح عدم استجابة زر الإغلاق للنقر.
- **إحصاءات استخدام أدق**: يُربط استخدام Gemini بالفترة الصحيحة.
- **علامة النموذج الافتراضي**: لم تعد تظهر خطأً في قوائم خيارات الجداول.
- **إنذارات كاذبة للإشعارات**: لم تعد عمليات النسخ تُطلق مطابقة الكلمات المفتاحية للإشعارات.
- **لون تمرير المؤشر على المعادلات**: يستخدم لون التمييز الخاص بموقعك.
- **تصدير الرياضيات**: يحافظ على جذور KaTeX (√) وتخطيط Gemini عند التصدير، بما في ذلك تصدير الصور.
- **الشريط الجانبي لـ Gems**: يزيل تلقائيًا العناصر المحذوفة.

---

> *«من الآن فصاعدًا، أريد أن أجعل هذه الرحلة رحلةً لأتعرّف إلى الناس.» — فريرن، 《Frieren: Beyond Journey's End》*

<!-- lang:ko -->

### 새로운 기능

- **Claude 사용량 막대**: Claude 페이지에 현재 세션과 주간 사용량 막대를 Gemini 사용량 스타일로 표시하는 새 플러그인입니다.
- **폴더 섹션 접기**: 사이드바의 폴더 섹션을 접어 공간을 절약하세요.

### 수정

- **더 안정적인 자동 스크롤 방지**: 이제 Ctrl+Enter 전송 모드를 존중하고 사이드바 기록도 스크롤 가능한 상태로 유지합니다.
- **사이드바 닫기 버튼**: 닫기 버튼이 클릭에 반응하지 않던 문제를 수정했습니다.
- **더 정확한 사용량 통계**: Gemini 사용량이 올바른 기간에 매핑됩니다.
- **기본 모델 표시**: 표 옵션 메뉴에 잘못 표시되지 않습니다.
- **알림 오탐**: 복사 동작이 더 이상 알림 키워드 일치를 잘못 트리거하지 않습니다.
- **수식 호버 색상**: 사이트의 강조 색상을 사용합니다.
- **수식 내보내기**: 내보낼 때 Gemini의 KaTeX 근호(√)와 레이아웃을 유지합니다(이미지 내보내기 포함).
- **Gems 사이드바**: 삭제된 항목을 자동으로 정리합니다.

---

> *"이제부터는, 사람을 알기 위한 여행으로 삼으려고 해." — 프리렌, 《장송의 프리렌》*

<!-- lang:ru -->

### Новое

- **Панель использования Claude**: Новый плагин, показывающий панели использования текущей сессии и за неделю на страницах Claude, в стиле индикатора использования Gemini.
- **Сворачиваемый раздел папок**: Сверните раздел папок на боковой панели, чтобы сэкономить место.

### Исправления

- **Более стабильное предотвращение автопрокрутки**: Теперь учитывает режим отправки Ctrl+Enter и сохраняет прокрутку истории боковой панели.
- **Кнопка закрытия боковой панели**: Исправлена кнопка закрытия, не реагировавшая на нажатия.
- **Более точная статистика использования**: Использование Gemini сопоставляется с правильным периодом.
- **Отметка модели по умолчанию**: Больше не появляется по ошибке в меню параметров таблиц.
- **Ложные срабатывания уведомлений**: Действия копирования больше не запускают совпадение по ключевым словам уведомлений.
- **Цвет при наведении на формулы**: Использует акцентный цвет вашего сайта.
- **Экспорт математики**: Сохраняет радикалы KaTeX (√) и вёрстку из Gemini при экспорте, включая экспорт в изображение.
- **Боковая панель Gems**: Автоматически удаляет удалённые записи.

---

> *«Отныне я хочу сделать это путешествием, чтобы узнать людей.» — Фрирен, 《Frieren: Beyond Journey's End》*
`;export{e as default};
