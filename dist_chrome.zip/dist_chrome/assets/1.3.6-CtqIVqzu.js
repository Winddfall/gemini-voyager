const e=`<!-- lang:en -->

> 📢 **Important announcement about the Chrome Web Store listing — please read.**

### What's New

- **Prompt Manager Theme Toggle**: Independent light/dark mode switch in the Prompt Manager header. Useful for non-Gemini websites where theme detection may not work correctly.
- **Starred Timestamps**: Starred conversations now show precise starredAt timestamps in the popup and timeline preview.

### About the New Chrome Web Store Listing

Starting from v1.3.6, Voyager is published as a **new Chrome Web Store item**.

Here's why: our original listing was taken down back around v1.3.1 due to a report filed by **ENFTracer.ai**. We've been appealing ever since, but Google has only been sending template responses, and the reporting party has never replied to any of our emails. To get the extension back to you faster and more conveniently, we've decided to publish under a new listing.

This means our previous listing — with **160,000+ users** and **700–800 reviews** — is gone, at least for now. It's a real loss, and we're genuinely sad about it. A huge thank-you to everyone who supported us there. We hope you'll follow us to the new home and continue the journey together.

<!-- lang:zh -->

> 📢 **关于 Chrome 商店上架的重要公告，请务必阅读。**

### 新功能

- **提示词管理器主题切换**：在提示词管理器标题栏新增独立的亮色/暗色模式开关，在非 Gemini 网站上主题检测不准确时尤为实用。
- **星标时间戳**：星标对话现在在弹窗和时间线预览中显示精确的标星时间。

### 关于 Chrome 商店新上架

从 v1.3.6 起，Voyager 将以**全新的 Chrome 商店项目**发布。

原因是这样的：我们的原始商品在 v1.3.1 前后被 **ENFTracer.ai** 举报下架。此后我们一直在申诉，但谷歌只回复模板邮件，举报方也始终不回复我们的任何邮件。为了让大家更快、更方便地用上插件，我们决定直接另开一个新的商品来上架。

这意味着我们之前那个积累了 **16 万用户**和 **七八百条评论**的老商品，要暂时和大家告别了。说实话挺可惜的，也非常感谢大家一直以来的支持与陪伴。希望大家能跟我们一起搬到新家，继续这段旅程。

<!-- lang:zh_TW -->

> 📢 **關於 Chrome 商店上架的重要公告，請務必閱讀。**

### 新功能

- **提示詞管理器主題切換**：在提示詞管理器標題列新增獨立的亮色/暗色模式開關，在非 Gemini 網站上主題偵測不準確時尤為實用。
- **星標時間戳記**：星標對話現在在彈窗和時間線預覽中顯示精確的標星時間。

### 關於 Chrome 商店新上架

從 v1.3.6 起，Voyager 將以**全新的 Chrome 商店項目**發佈。

原因是這樣的：我們的原始商品在 v1.3.1 前後被 **ENFTracer.ai** 舉報下架。此後我們一直在申訴，但 Google 只回覆範本郵件，舉報方也始終不回覆我們的任何郵件。為了讓大家更快、更方便地用上外掛，我們決定直接另開一個新的商品來上架。

這意味著我們之前那個累積了 **16 萬使用者**和**七八百則評論**的舊商品，要暫時和大家告別了。說實話挺可惜的，也非常感謝大家一直以來的支持與陪伴。希望大家能跟我們一起搬到新家，繼續這段旅程。

<!-- lang:ja -->

> 📢 **Chrome ウェブストアの掲載に関する重要なお知らせです。ぜひお読みください。**

### 新機能

- **プロンプトマネージャーのテーマ切替**：プロンプトマネージャーのヘッダーにライト/ダークモードの独立トグルを追加。Gemini 以外のサイトでテーマ検出が正しく動作しない場合に便利です。
- **スター付きタイムスタンプ**：スター付き会話のポップアップとタイムラインプレビューに正確なスター付与時刻を表示。

### Chrome ウェブストアの新規掲載について

v1.3.6 より、Voyager は**新しい Chrome ウェブストアアイテム**として公開されます。

経緯：v1.3.1 前後に **ENFTracer.ai** からの報告により、元の掲載が削除されました。以来ずっと異議申し立てを続けてきましたが、Google はテンプレート返信のみで、報告者側も一切メールに返信がありません。皆さんにより早く便利に拡張機能をお届けするため、新しいアイテムとして再公開することを決断しました。

これにより、**16 万人以上のユーザー**と **700〜800 件のレビュー**を集めた元の掲載とは一旦お別れとなります。非常に残念ですが、皆さんのこれまでのご支援に心から感謝しています。新しいページでも引き続きよろしくお願いいたします。

<!-- lang:fr -->

> 📢 **Annonce importante concernant la fiche Chrome Web Store — veuillez lire.**

### Nouveautés

- **Thème du gestionnaire de prompts** : Bouton de basculement clair/sombre indépendant dans l'en-tête du gestionnaire de prompts. Utile sur les sites non-Gemini où la détection du thème peut ne pas fonctionner correctement.
- **Horodatages des favoris** : Les conversations favorites affichent désormais l'heure exacte d'ajout aux favoris dans le popup et l'aperçu de la timeline.

### À propos de la nouvelle fiche Chrome Web Store

À partir de la v1.3.6, Voyager est publié en tant que **nouvel élément Chrome Web Store**.

Voici pourquoi : notre fiche originale a été retirée aux alentours de la v1.3.1 suite à un signalement de **ENFTracer.ai**. Nous avons fait appel depuis, mais Google ne répond qu'avec des messages automatiques, et la partie signalante n'a jamais répondu à aucun de nos e-mails. Pour vous permettre d'accéder à l'extension plus rapidement et plus facilement, nous avons décidé de publier sous une nouvelle fiche.

Cela signifie que notre ancienne fiche — avec **plus de 160 000 utilisateurs** et **700 à 800 avis** — a disparu, au moins pour l'instant. C'est une vraie perte et nous en sommes sincèrement attristés. Un grand merci à tous ceux qui nous ont soutenus. Nous espérons que vous nous suivrez dans notre nouveau foyer.

<!-- lang:es -->

> 📢 **Anuncio importante sobre la ficha de Chrome Web Store — por favor, léelo.**

### Novedades

- **Tema del gestor de prompts**: Interruptor independiente de modo claro/oscuro en la cabecera del gestor de prompts. Útil en sitios que no son Gemini donde la detección de tema puede no funcionar correctamente.
- **Marcas de tiempo de favoritos**: Las conversaciones favoritas ahora muestran la hora exacta de marcado en el popup y la vista previa de la línea de tiempo.

### Sobre la nueva ficha de Chrome Web Store

A partir de la v1.3.6, Voyager se publica como un **nuevo elemento en Chrome Web Store**.

El motivo: nuestra ficha original fue retirada alrededor de la v1.3.1 debido a un reporte de **ENFTracer.ai**. Hemos estado apelando desde entonces, pero Google solo envía respuestas automáticas y la parte denunciante nunca ha respondido a ninguno de nuestros correos. Para que podáis acceder a la extensión de forma más rápida y cómoda, hemos decidido publicar bajo una nueva ficha.

Esto significa que nuestra ficha anterior — con **más de 160 000 usuarios** y **entre 700 y 800 reseñas** — se ha ido, al menos por ahora. Es una verdadera pérdida y lo sentimos mucho. Muchas gracias a todos los que nos apoyasteis allí. Esperamos que nos sigáis en nuestro nuevo hogar.

<!-- lang:pt -->

> 📢 **Anúncio importante sobre a listagem na Chrome Web Store — por favor, leia.**

### Novidades

- **Tema do gestor de prompts**: Interruptor independente de modo claro/escuro no cabeçalho do gestor de prompts. Útil em sites que não são o Gemini, onde a deteção de tema pode não funcionar corretamente.
- **Carimbos de data/hora dos favoritos**: As conversas favoritas agora mostram o momento exato em que foram marcadas no popup e na pré-visualização da linha do tempo.

### Sobre a nova listagem na Chrome Web Store

A partir da v1.3.6, o Voyager é publicado como um **novo item na Chrome Web Store**.

O motivo: a nossa listagem original foi removida por volta da v1.3.1 devido a uma denúncia de **ENFTracer.ai**. Temos estado a recorrer desde então, mas a Google apenas envia respostas automáticas e a parte denunciante nunca respondeu a nenhum dos nossos e-mails. Para que possam aceder à extensão de forma mais rápida e conveniente, decidimos publicar sob uma nova listagem.

Isto significa que a nossa listagem anterior — com **mais de 160 000 utilizadores** e **700 a 800 avaliações** — desapareceu, pelo menos por agora. É uma verdadeira perda e estamos genuinamente tristes. Um grande obrigado a todos os que nos apoiaram. Esperamos que nos sigam para o novo lar.

<!-- lang:ar -->

> 📢 **إعلان مهم بخصوص صفحة Chrome Web Store — يرجى القراءة.**

### الجديد

- **تبديل سمة مدير الأوامر**: مفتاح مستقل للوضع الفاتح/الداكن في رأس مدير الأوامر. مفيد للمواقع غير Gemini حيث قد لا يعمل اكتشاف السمة بشكل صحيح.
- **طوابع زمنية للمفضلة**: تعرض المحادثات المفضلة الآن وقت الإضافة الدقيق في النافذة المنبثقة ومعاينة الخط الزمني.

### حول صفحة Chrome Web Store الجديدة

بدءًا من الإصدار 1.3.6، يتم نشر Voyager كـ**عنصر جديد في Chrome Web Store**.

السبب: تمت إزالة صفحتنا الأصلية حوالي الإصدار 1.3.1 بسبب بلاغ من **ENFTracer.ai**. ظللنا نستأنف منذ ذلك الحين، لكن Google ترسل ردودًا نموذجية فقط، والطرف المُبلِّغ لم يرد على أي من رسائلنا الإلكترونية. لتتمكنوا من الوصول إلى الإضافة بشكل أسرع وأسهل، قررنا النشر تحت صفحة جديدة.

هذا يعني أن صفحتنا السابقة — بأكثر من **160,000 مستخدم** و**700-800 تقييم** — قد اختفت، على الأقل في الوقت الحالي. إنها خسارة حقيقية ونحن حزينون لذلك. شكر كبير لكل من دعمنا هناك. نأمل أن تتابعونا في منزلنا الجديد.

<!-- lang:ko -->

> 📢 **Chrome 웹 스토어 등록에 관한 중요 공지 — 꼭 읽어주세요.**

### 새로운 기능

- **프롬프트 매니저 테마 전환**: 프롬프트 매니저 헤더에 독립적인 라이트/다크 모드 전환 스위치 추가. Gemini가 아닌 웹사이트에서 테마 감지가 제대로 작동하지 않을 때 유용합니다.
- **즐겨찾기 타임스탬프**: 즐겨찾기한 대화에 팝업과 타임라인 미리보기에서 정확한 즐겨찾기 시간이 표시됩니다.

### Chrome 웹 스토어 신규 등록에 대하여

v1.3.6부터 Voyager는 **새로운 Chrome 웹 스토어 항목**으로 게시됩니다.

이유는 다음과 같습니다: v1.3.1 즈음에 **ENFTracer.ai**의 신고로 기존 등록이 삭제되었습니다. 그 이후로 계속 이의를 제기해왔지만, Google은 템플릿 답변만 보내고 신고 측은 우리의 이메일에 한 번도 답장하지 않았습니다. 여러분이 더 빠르고 편리하게 확장 프로그램을 사용할 수 있도록, 새로운 항목으로 게시하기로 결정했습니다.

이는 **16만 명 이상의 사용자**와 **700~800개의 리뷰**가 있던 이전 등록을 잠시 떠나야 한다는 뜻입니다. 정말 아쉽고, 그곳에서 응원해주신 모든 분께 진심으로 감사드립니다. 새로운 곳에서도 함께해주시길 바랍니다.

<!-- lang:ru -->

> 📢 **Важное объявление о странице в Chrome Web Store — пожалуйста, прочитайте.**

### Новое

- **Переключатель темы менеджера промптов**: Независимый переключатель светлого/тёмного режима в заголовке менеджера промптов. Полезно на сайтах, отличных от Gemini, где определение темы может работать некорректно.
- **Метки времени избранного**: Избранные беседы теперь показывают точное время добавления в избранное во всплывающем окне и предпросмотре временной шкалы.

### О новой странице в Chrome Web Store

Начиная с v1.3.6, Voyager публикуется как **новый элемент Chrome Web Store**.

Причина: наша оригинальная страница была удалена примерно в версии 1.3.1 по жалобе **ENFTracer.ai**. С тех пор мы подавали апелляции, но Google отвечает только шаблонными письмами, а заявитель так и не ответил ни на одно наше письмо. Чтобы вы могли быстрее и удобнее пользоваться расширением, мы решили опубликовать его как новый элемент.

Это означает, что наша прежняя страница — с **более 160 000 пользователями** и **700–800 отзывами** — пока недоступна. Это настоящая потеря, и нам очень грустно. Огромное спасибо всем, кто поддерживал нас там. Надеемся, вы последуете за нами на новую страницу.
`;export{e as default};
