const e=`<!-- lang:en -->

### What's New

- **Starred conversation library**: Star important conversations and find them again in a dedicated library section.
- **Response completion notifications** *(off by default)*: Get a desktop notification when Gemini finishes generating a long response.
- **NanoBanana download labels**: Popup now clearly tags the download as recommended and the preview as unstable.

### Fixes

- **Batch-delete in folders**: Restored batch-delete reliability under Gemini's new virtualized sidebar.
- **Copy response as image**: Fixed the icon glyph, button sizing, and click area after Gemini lr26. Generated images now survive image export.
- **Move to folder restored**: The "Move to folder" item is back in the conversation menu after Gemini's recent UI overhaul.
- **Default model with overlay menus**: The default-model lock now works with Gemini's new overlay child menu structure.
- **Watermark during account switch**: No more stuck "processing watermark" toast after switching accounts — downloads are queued while the engine initializes.
- **Watermark status toasts**: Redesigned download status toasts with correct colors in both light and dark themes.
- **Edge: folders temporarily disabled**: Folders runtime is disabled on Edge with an in-product notice until the next compatibility update.

<!-- lang:zh -->

### 新功能

- **收藏对话库**：将重要对话加星，在专属库中快速找回。
- **回复完成通知** *（默认关闭）*：Gemini 完成长回复时通过桌面通知提醒你。
- **NanoBanana 下载标签**：弹窗中明确标注"推荐下载"与"预览版（不稳定）"。

### 修复

- **文件夹批量删除**：恢复了 Gemini 新版虚拟化侧边栏下的批量删除稳定性。
- **回复导出为图片**：修复了 Gemini lr26 后图标显示异常、按钮尺寸不一、点击区域错位的问题。生成的图片现在也能正常导出。
- **"移至文件夹"菜单恢复**：Gemini UI 改版后，对话菜单中的"移至文件夹"项已恢复。
- **默认模型识别浮层菜单**：默认模型锁定可正确识别新的浮层子菜单结构。
- **账号切换时的水印处理**：账号切换后不再卡在"处理水印中"——引擎初始化期间下载请求会先进入队列。
- **水印状态提示重设计**：重新设计了下载状态提示，深浅主题下颜色都正确。
- **Edge：文件夹暂时停用**：在适配修复前，Edge 中已暂时停用文件夹功能并提供产品内提示。

<!-- lang:zh_TW -->

### 新功能

- **收藏對話庫**：將重要對話加星，在專屬庫中快速找回。
- **回覆完成通知** *（預設關閉）*：Gemini 完成長回覆時透過桌面通知提醒你。
- **NanoBanana 下載標籤**：彈窗中明確標註「推薦下載」與「預覽版（不穩定）」。

### 修復

- **資料夾批次刪除**：恢復了 Gemini 新版虛擬化側邊欄下的批次刪除穩定性。
- **回覆匯出為圖片**：修復了 Gemini lr26 後圖示顯示異常、按鈕尺寸不一、點擊區域錯位的問題。生成的圖片現在也能正常匯出。
- **「移至資料夾」選單恢復**：Gemini UI 改版後，對話選單中的「移至資料夾」項目已恢復。
- **預設模型識別浮層選單**：預設模型鎖定可正確識別新的浮層子選單結構。
- **帳號切換時的浮水印處理**：帳號切換後不再卡在「處理浮水印中」——引擎初始化期間下載請求會先進入佇列。
- **浮水印狀態提示重新設計**：重新設計了下載狀態提示，深淺主題下顏色都正確。
- **Edge：資料夾暫時停用**：在相容性修復前，Edge 中已暫時停用資料夾功能並提供產品內提示。

<!-- lang:ja -->

### 新機能

- **スター付き会話ライブラリ**：重要な会話にスターを付け、専用ライブラリからすぐに呼び出せます。
- **応答完了通知** *（デフォルトでオフ）*：Gemini が長い応答を生成し終えたタイミングでデスクトップ通知を受け取れます。
- **NanoBanana ダウンロードラベル**：ポップアップで「推奨ダウンロード」と「プレビュー（不安定）」が明示されるようになりました。

### 修正

- **フォルダの一括削除**：Gemini の新しい仮想化サイドバー上で一括削除が再び安定して動作するようになりました。
- **返信を画像としてコピー**：lr26 以降のアイコン表示崩れ、ボタンサイズ、クリック領域のずれを修正しました。生成画像も画像エクスポートに含まれます。
- **「フォルダへ移動」を復元**：Gemini の UI 改修後、会話メニューの「フォルダへ移動」項目が復活しました。
- **デフォルトモデルとオーバーレイメニュー**：デフォルトモデルのロックが新しいオーバーレイ子メニュー構造でも機能します。
- **アカウント切替時のウォーターマーク処理**：アカウント切替後に「ウォーターマーク処理中」が固まらなくなりました。エンジン初期化中のダウンロードはキューに入ります。
- **ウォーターマーク通知の再デザイン**：ダウンロードステータスのトーストを刷新し、ライト/ダーク両テーマで色が正しく表示されます。
- **Edge：フォルダを一時無効化**：互換性修正までの間、Edge ではフォルダ機能を無効化し、プロダクト内に通知を表示します。

<!-- lang:fr -->

### Nouveautés

- **Bibliothèque de conversations favorites** : Marquez vos conversations importantes d'une étoile et retrouvez-les dans une bibliothèque dédiée.
- **Notifications de fin de réponse** *(désactivé par défaut)* : Recevez une notification de bureau quand Gemini termine une longue réponse.
- **Étiquettes de téléchargement NanoBanana** : Le popup indique clairement le téléchargement recommandé et l'aperçu instable.

### Corrections

- **Suppression groupée dans les dossiers** : Fiabilité restaurée pour la suppression groupée sous la nouvelle barre latérale virtualisée de Gemini.
- **Copier la réponse en image** : Correction du glyphe d'icône, de la taille du bouton et de la zone de clic après Gemini lr26. Les images générées sont désormais incluses dans l'export image.
- **« Déplacer vers le dossier » restauré** : L'entrée « Déplacer vers le dossier » est de retour dans le menu de conversation après le remaniement de l'interface Gemini.
- **Modèle par défaut avec menus en surimpression** : Le verrouillage du modèle par défaut fonctionne avec la nouvelle structure de sous-menu en surimpression.
- **Filigrane lors du changement de compte** : Plus de blocage sur « traitement du filigrane » après un changement de compte — les téléchargements sont mis en file pendant l'initialisation du moteur.
- **Toasts de statut du filigrane** : Toasts redessinés, couleurs correctes en thèmes clair et sombre.
- **Edge : dossiers temporairement désactivés** : Les dossiers sont désactivés sur Edge avec un avis intégré, en attendant la prochaine mise à jour de compatibilité.

<!-- lang:es -->

### Novedades

- **Biblioteca de conversaciones favoritas**: Marca con estrella las conversaciones importantes y encuéntralas en una biblioteca dedicada.
- **Notificaciones al terminar la respuesta** *(desactivado por defecto)*: Recibe una notificación de escritorio cuando Gemini termina una respuesta larga.
- **Etiquetas de descarga NanoBanana**: El popup ahora marca claramente la descarga recomendada y la vista previa como inestable.

### Correcciones

- **Eliminación por lotes en carpetas**: Restaurada la fiabilidad de la eliminación por lotes bajo la nueva barra lateral virtualizada de Gemini.
- **Copiar respuesta como imagen**: Corregidos el glifo del icono, el tamaño del botón y el área de clic tras Gemini lr26. Las imágenes generadas se incluyen en el export como imagen.
- **«Mover a la carpeta» restaurado**: La opción «Mover a la carpeta» vuelve al menú de conversación tras el rediseño de la interfaz de Gemini.
- **Modelo por defecto con menús en superposición**: El bloqueo del modelo por defecto funciona con la nueva estructura de submenús en superposición.
- **Marca de agua al cambiar de cuenta**: Ya no se queda bloqueado en «procesando marca de agua» tras cambiar de cuenta — las descargas se ponen en cola mientras se inicializa el motor.
- **Toasts de estado de la marca de agua**: Toasts rediseñados con colores correctos en temas claro y oscuro.
- **Edge: carpetas desactivadas temporalmente**: Las carpetas están desactivadas en Edge con un aviso integrado, hasta la próxima actualización de compatibilidad.

<!-- lang:pt -->

### Novidades

- **Biblioteca de conversas favoritas**: Marque conversas importantes com estrela e encontre-as numa biblioteca dedicada.
- **Notificações ao concluir resposta** *(desativado por padrão)*: Receba uma notificação de desktop quando o Gemini termina uma resposta longa.
- **Etiquetas de download NanoBanana**: O popup agora marca claramente o download recomendado e a pré-visualização como instável.

### Correções

- **Exclusão em lote nas pastas**: Confiabilidade restaurada para a exclusão em lote sob a nova barra lateral virtualizada do Gemini.
- **Copiar resposta como imagem**: Corrigidos o glifo do ícone, o tamanho do botão e a área de clique após o Gemini lr26. As imagens geradas agora também são exportadas como imagem.
- **«Mover para a pasta» restaurado**: O item «Mover para a pasta» voltou ao menu de conversa após a reformulação da interface do Gemini.
- **Modelo padrão com menus de sobreposição**: O bloqueio do modelo padrão funciona com a nova estrutura de submenu em sobreposição.
- **Marca d'água ao trocar de conta**: Não trava mais em «processando marca d'água» após trocar de conta — os downloads entram em fila enquanto o motor inicializa.
- **Toasts de status da marca d'água**: Toasts redesenhados com cores corretas nos temas claro e escuro.
- **Edge: pastas temporariamente desativadas**: As pastas estão desativadas no Edge com um aviso integrado, até a próxima atualização de compatibilidade.

<!-- lang:ar -->

### الجديد

- **مكتبة المحادثات المميّزة بنجمة**: ضع نجمة على المحادثات المهمة وجدها بسرعة في مكتبة مخصّصة.
- **إشعار اكتمال الرد** *(معطّل افتراضيًا)*: استلم إشعار سطح المكتب عندما يُنهي Gemini توليد رد طويل.
- **علامات تنزيل NanoBanana**: تُميِّز النافذة المنبثقة الآن "التنزيل الموصى به" و"المعاينة (غير مستقرة)" بوضوح.

### الإصلاحات

- **الحذف الجماعي في المجلدات**: استُعيد الاعتماد على الحذف الجماعي ضمن الشريط الجانبي الافتراضي الجديد في Gemini.
- **نسخ الرد كصورة**: أُصلح رمز الأيقونة وحجم الزر ومنطقة النقر بعد Gemini lr26. الصور المُولَّدة تُصدَّر الآن أيضًا ضمن تصدير الصورة.
- **استرداد "نقل إلى المجلد"**: عاد عنصر "نقل إلى المجلد" إلى قائمة المحادثة بعد تجديد واجهة Gemini.
- **النموذج الافتراضي مع قوائم التراكب**: يعمل قفل النموذج الافتراضي مع البنية الجديدة للقوائم الفرعية المتراكِبة.
- **العلامة المائية عند تبديل الحساب**: لا تعليق بعد الآن على "جارٍ معالجة العلامة المائية" بعد تبديل الحساب — تدخل التنزيلات إلى الطابور أثناء تهيئة المحرّك.
- **تنبيهات حالة العلامة المائية**: أُعيد تصميم تنبيهات حالة التنزيل بألوان صحيحة في الوضعين الفاتح والداكن.
- **Edge: تعطيل المجلدات مؤقتًا**: عُطِّلت ميزة المجلدات في Edge مع إشعار داخل المنتج إلى أن يصدر تحديث التوافق التالي.

<!-- lang:ko -->

### 새로운 기능

- **즐겨찾기 대화 라이브러리**: 중요한 대화에 별표를 지정해 전용 라이브러리에서 빠르게 찾을 수 있습니다.
- **응답 완료 알림** *(기본 꺼짐)*: Gemini가 긴 응답을 끝내면 데스크톱 알림을 받을 수 있습니다.
- **NanoBanana 다운로드 라벨**: 팝업이 "추천 다운로드"와 "미리보기(불안정)"를 명확히 구분해 표시합니다.

### 수정

- **폴더 일괄 삭제**: Gemini의 새로운 가상화 사이드바에서도 일괄 삭제가 다시 안정적으로 동작합니다.
- **응답을 이미지로 복사**: lr26 이후 아이콘 글리프, 버튼 크기, 클릭 영역 문제를 수정했습니다. 생성된 이미지도 이미지 내보내기에 포함됩니다.
- **"폴더로 이동" 복원**: Gemini UI 개편 이후 대화 메뉴의 "폴더로 이동" 항목이 복원되었습니다.
- **오버레이 메뉴 환경의 기본 모델**: 기본 모델 잠금이 새로운 오버레이 하위 메뉴 구조에서도 작동합니다.
- **계정 전환 시 워터마크 처리**: 계정 전환 후 "워터마크 처리 중" 상태에서 멈추지 않습니다 — 엔진 초기화 중에는 다운로드가 큐에 들어갑니다.
- **워터마크 상태 토스트**: 다운로드 상태 토스트를 새로 디자인했고, 라이트/다크 테마 모두에서 색상이 올바르게 표시됩니다.
- **Edge: 폴더 일시 비활성화**: 호환성 수정 전까지 Edge에서 폴더 기능을 비활성화하고 제품 내 알림을 제공합니다.

<!-- lang:ru -->

### Новое

- **Библиотека избранных диалогов**: Отмечайте важные диалоги звездой и быстро находите их в отдельной библиотеке.
- **Уведомления о завершении ответа** *(выключено по умолчанию)*: Получайте уведомление на рабочем столе, когда Gemini заканчивает длинный ответ.
- **Метки загрузки NanoBanana**: Попап теперь чётко обозначает «рекомендуемую загрузку» и «предпросмотр (нестабильный)».

### Исправления

- **Пакетное удаление в папках**: Восстановлена надёжность пакетного удаления под новой виртуализированной боковой панелью Gemini.
- **Копировать ответ как изображение**: Исправлены глиф иконки, размер кнопки и область клика после Gemini lr26. Сгенерированные изображения теперь также сохраняются при экспорте в изображение.
- **«Переместить в папку» восстановлен**: Пункт «Переместить в папку» вернулся в меню диалога после обновления интерфейса Gemini.
- **Модель по умолчанию и оверлей-меню**: Блокировка модели по умолчанию работает с новой структурой вложенных оверлей-меню.
- **Водяной знак при смене аккаунта**: Больше нет зависания на «обработка водяного знака» после смены аккаунта — загрузки попадают в очередь во время инициализации движка.
- **Тосты статуса водяного знака**: Тосты статуса загрузки переработаны, цвета корректны в светлой и тёмной темах.
- **Edge: папки временно отключены**: На Edge функция папок отключена с уведомлением в продукте до следующего обновления совместимости.
`;export{e as default};
