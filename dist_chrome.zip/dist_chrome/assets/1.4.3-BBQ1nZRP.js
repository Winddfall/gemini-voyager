const e=`<!-- lang:en -->

### What's New

- **New chat in folder**: Start a fresh Gemini conversation directly from a folder's context menu.
- **Move current chat to folder**: Add the current conversation to a folder from the top conversation menu.
- **Watermark controls**: Preview and download watermark removal now have separate toggles.
- **Folder-as-Project chevron**: The project picker uses a clearer rotating chevron to show expanded state.

### Fixes

- **Cloud sync merging**: Folder imports now merge by path so matching cloud folders combine instead of duplicating.
- **Multi-line prompt paste**: Pasted prompts keep their line breaks.
- **Ctrl+Enter send**: Fixed edge cases around send/update behavior.
- **Timeline timestamps**: Timestamps stay stable instead of shifting as the timeline refreshes.
- **Nested timeline dots**: Level-3 dots render cleanly without clipping artifacts.
- **Export dialog**: The export button stays reachable on smaller viewports.
- **Pinned prompt panel**: The unlock control remains visible by clamping the panel to the viewport.

<!-- lang:zh -->

### 新功能

- **在文件夹中新建对话**：可直接从文件夹右键菜单开启新的 Gemini 对话。
- **当前对话移入文件夹**：可从对话顶部菜单把当前对话加入文件夹。
- **水印控制拆分**：预览图和下载图的去水印开关现在可以分别控制。
- **Folder-as-Project 展开箭头**：项目选择器改用更清晰的旋转箭头显示展开状态。

### 修复

- **云同步合并**：导入文件夹时按路径合并，匹配的云端文件夹不再重复出现。
- **多行 Prompt 粘贴**：粘贴多行内容时会保留换行。
- **Ctrl+Enter 发送**：修复发送和更新按钮相关的边界问题。
- **时间线时间戳**：时间线刷新时，时间戳不再跳动。
- **多级时间线圆点**：三级圆点渲染更稳定，不再出现裁切瑕疵。
- **导出弹窗**：小屏幕下导出按钮仍然可点击。
- **固定 Prompt 面板**：面板会限制在视口内，解锁按钮不再跑出屏幕。

<!-- lang:zh_TW -->

### 新功能

- **在資料夾中新建對話**：可直接從資料夾右鍵選單開啟新的 Gemini 對話。
- **目前對話移入資料夾**：可從對話頂部選單把目前對話加入資料夾。
- **浮水印控制拆分**：預覽圖和下載圖的去浮水印開關現在可分別控制。
- **Folder-as-Project 展開箭頭**：專案選擇器改用更清楚的旋轉箭頭顯示展開狀態。

### 修復

- **雲端同步合併**：匯入資料夾時依路徑合併，匹配的雲端資料夾不再重複出現。
- **多行 Prompt 貼上**：貼上多行內容時會保留換行。
- **Ctrl+Enter 傳送**：修正傳送和更新按鈕相關的邊界問題。
- **時間線時間戳**：時間線重新整理時，時間戳不再跳動。
- **多層時間線圓點**：第 3 層圓點渲染更穩定，不再出現裁切瑕疵。
- **匯出彈窗**：小螢幕下匯出按鈕仍然可點擊。
- **固定 Prompt 面板**：面板會限制在視口內，解鎖按鈕不再跑出畫面。

<!-- lang:ja -->

### 新機能

- **フォルダ内で新規チャット**：フォルダのコンテキストメニューから新しい Gemini 会話を開始できます。
- **現在のチャットをフォルダへ移動**：会話上部のメニューから現在の会話をフォルダに追加できます。
- **ウォーターマーク制御**：プレビュー画像とダウンロード画像のウォーターマーク除去を個別に切り替えられます。
- **Folder-as-Project のシェブロン**：プロジェクト選択の開閉状態が、回転するシェブロンでより分かりやすくなりました。

### 修正

- **クラウド同期のマージ**：フォルダのインポート時にパスで統合し、一致するクラウドフォルダが重複しないようにしました。
- **複数行 Prompt の貼り付け**：複数行の内容を貼り付けても改行が保持されます。
- **Ctrl+Enter 送信**：送信／更新ボタンまわりのエッジケースを修正しました。
- **タイムラインのタイムスタンプ**：タイムライン更新時にタイムスタンプがずれなくなりました。
- **ネストしたタイムラインのドット**：第 3 階層のドットが切れずにきれいに表示されます。
- **エクスポートダイアログ**：小さな画面でもエクスポートボタンにアクセスできます。
- **固定 Prompt パネル**：パネルを画面内に収め、ロック解除ボタンが画面外へ出ないようにしました。

<!-- lang:fr -->

### Nouveautés

- **Nouveau chat dans un dossier** : Lancez une nouvelle conversation Gemini depuis le menu contextuel d'un dossier.
- **Déplacer le chat actuel vers un dossier** : Ajoutez la conversation en cours à un dossier depuis le menu supérieur de la conversation.
- **Contrôles du filigrane** : La suppression du filigrane pour l'aperçu et le téléchargement dispose désormais de deux interrupteurs séparés.
- **Chevron Folder-as-Project** : Le sélecteur de projet affiche plus clairement l'état ouvert grâce à un chevron animé.

### Corrections

- **Fusion de la synchronisation cloud** : Les imports fusionnent les dossiers par chemin afin d'éviter les doublons côté cloud.
- **Collage de prompts multi-lignes** : Les retours à la ligne sont conservés lors du collage.
- **Envoi avec Ctrl+Entrée** : Correction de cas limites autour des boutons d'envoi et de mise à jour.
- **Horodatages de la timeline** : Les horodatages restent stables lors du rafraîchissement de la timeline.
- **Points imbriqués de la timeline** : Les points de niveau 3 s'affichent proprement sans artefacts de découpe.
- **Dialogue d'export** : Le bouton d'export reste accessible sur les petits écrans.
- **Panneau Prompt épinglé** : Le panneau est limité à la zone visible afin que le bouton de déverrouillage reste accessible.

<!-- lang:es -->

### Novedades

- **Nuevo chat en carpeta**: Inicia una conversación nueva de Gemini desde el menú contextual de una carpeta.
- **Mover el chat actual a una carpeta**: Añade la conversación actual a una carpeta desde el menú superior de la conversación.
- **Controles de marca de agua**: La eliminación de marca de agua para vista previa y descarga ahora tiene interruptores separados.
- **Chevron de Folder-as-Project**: El selector de proyecto muestra mejor su estado desplegado con un chevron giratorio.

### Correcciones

- **Fusión de sincronización en la nube**: Las importaciones fusionan carpetas por ruta para evitar duplicados en la nube.
- **Pegado de prompts multilínea**: Los saltos de línea se conservan al pegar.
- **Envío con Ctrl+Enter**: Corregidos casos límite de los botones de enviar y actualizar.
- **Marcas de tiempo de la cronología**: Las marcas de tiempo permanecen estables al refrescar la cronología.
- **Puntos anidados de la cronología**: Los puntos de nivel 3 se renderizan sin artefactos de recorte.
- **Diálogo de exportación**: El botón de exportar sigue accesible en pantallas pequeñas.
- **Panel de prompts fijado**: El panel queda limitado al área visible para que el botón de desbloqueo no salga de la pantalla.

<!-- lang:pt -->

### Novidades

- **Novo chat na pasta**: Inicie uma nova conversa do Gemini diretamente pelo menu de contexto de uma pasta.
- **Mover chat atual para pasta**: Adicione a conversa atual a uma pasta pelo menu superior da conversa.
- **Controles de marca d'água**: A remoção de marca d'água na pré-visualização e no download agora tem interruptores separados.
- **Chevron do Folder-as-Project**: O seletor de projeto mostra melhor o estado expandido com um chevron giratório.

### Correções

- **Mesclagem na sincronização em nuvem**: As importações mesclam pastas por caminho para evitar duplicatas na nuvem.
- **Colagem de prompts com várias linhas**: As quebras de linha são preservadas ao colar.
- **Envio com Ctrl+Enter**: Corrigidos casos de borda nos botões de enviar e atualizar.
- **Carimbos de data da linha do tempo**: Os horários permanecem estáveis quando a linha do tempo é atualizada.
- **Pontos aninhados da linha do tempo**: Os pontos de nível 3 são renderizados sem artefatos de recorte.
- **Diálogo de exportação**: O botão de exportar continua acessível em telas menores.
- **Painel de prompts fixado**: O painel fica dentro da área visível para que o botão de desbloqueio não saia da tela.

<!-- lang:ar -->

### الجديد

- **محادثة جديدة داخل مجلد**: ابدأ محادثة Gemini جديدة مباشرة من قائمة سياق المجلد.
- **نقل المحادثة الحالية إلى مجلد**: أضِف المحادثة الحالية إلى مجلد من القائمة العلوية للمحادثة.
- **عناصر تحكم العلامة المائية**: أصبح لإزالة العلامة المائية من المعاينة والتنزيل مفتاحان منفصلان.
- **سهم Folder-as-Project**: يعرض منتقي المشروع حالة التوسيع بوضوح أكبر عبر سهم دوّار.

### الإصلاحات

- **دمج المزامنة السحابية**: تستورد المجلدات الآن بالدمج حسب المسار، فلا تتكرر المجلدات السحابية المتطابقة.
- **لصق Prompt متعدد الأسطر**: يتم الحفاظ على فواصل الأسطر عند اللصق.
- **الإرسال بـ Ctrl+Enter**: إصلاح حالات حدية في أزرار الإرسال والتحديث.
- **طوابع وقت المخطط الزمني**: تبقى الطوابع الزمنية ثابتة عند تحديث المخطط الزمني.
- **نقاط المخطط الزمني المتداخلة**: تظهر نقاط المستوى الثالث بوضوح دون آثار قص.
- **نافذة التصدير**: يبقى زر التصدير قابلاً للوصول على الشاشات الصغيرة.
- **لوحة Prompt المثبتة**: تبقى اللوحة داخل مساحة العرض كي لا يخرج زر إلغاء التثبيت عن الشاشة.

<!-- lang:ko -->

### 새로운 기능

- **폴더에서 새 채팅**: 폴더의 컨텍스트 메뉴에서 새 Gemini 대화를 바로 시작합니다.
- **현재 채팅을 폴더로 이동**: 대화 상단 메뉴에서 현재 대화를 폴더에 추가합니다.
- **워터마크 제어**: 미리보기와 다운로드의 워터마크 제거를 각각 따로 켜고 끌 수 있습니다.
- **Folder-as-Project 화살표**: 프로젝트 선택기의 펼침 상태를 회전하는 화살표로 더 명확하게 표시합니다.

### 수정

- **클라우드 동기화 병합**: 폴더 가져오기 시 경로 기준으로 병합하여 같은 클라우드 폴더가 중복되지 않습니다.
- **여러 줄 Prompt 붙여넣기**: 붙여넣은 내용의 줄바꿈이 유지됩니다.
- **Ctrl+Enter 보내기**: 보내기와 업데이트 버튼 주변의 예외 상황을 수정했습니다.
- **타임라인 타임스탬프**: 타임라인이 새로고침되어도 시간이 흔들리지 않습니다.
- **중첩 타임라인 점**: 3단계 점이 잘리지 않고 깔끔하게 표시됩니다.
- **내보내기 대화상자**: 작은 화면에서도 내보내기 버튼에 접근할 수 있습니다.
- **고정된 Prompt 패널**: 패널을 화면 안에 고정해 잠금 해제 버튼이 밖으로 나가지 않습니다.

<!-- lang:ru -->

### Новое

- **Новый чат в папке**: Запускайте новый разговор Gemini прямо из контекстного меню папки.
- **Переместить текущий чат в папку**: Добавляйте текущий разговор в папку из верхнего меню разговора.
- **Управление водяными знаками**: Удаление водяного знака для предпросмотра и скачивания теперь включается отдельно.
- **Chevron для Folder-as-Project**: Переключатель проекта яснее показывает раскрытое состояние с помощью вращающегося индикатора.

### Исправления

- **Слияние облачной синхронизации**: Импорт папок теперь объединяет совпадения по пути, чтобы облачные папки не дублировались.
- **Вставка многострочных Prompt**: Переносы строк сохраняются при вставке.
- **Отправка через Ctrl+Enter**: Исправлены пограничные случаи с кнопками отправки и обновления.
- **Метки времени timeline**: Метки времени остаются стабильными при обновлении timeline.
- **Вложенные точки timeline**: Точки третьего уровня отображаются без артефактов обрезки.
- **Диалог экспорта**: Кнопка экспорта остаётся доступной на небольших экранах.
- **Закреплённая панель Prompt**: Панель ограничена областью экрана, поэтому кнопка разблокировки не уезжает за край.
`;export{e as default};
