const a=`<!-- lang:en -->

### Highlights

- Platform-aware keyboard shortcuts: modifier keys now display correctly for your OS (⌘ on macOS, Ctrl on Windows/Linux).
- New export filter: select messages by role (user-only or AI-only) in export mode.
- New keyboard shortcuts for collapsing the input box and other enhanced features.
- Chat width now adapts properly for split-screen / narrow windows and supports Gemini table blocks in widescreen.
- Mermaid diagrams now auto-fit to the viewport when opening the fullscreen viewer.
- Fixed several bugs in folder sync, cloud authentication, KaTeX PDF export, and Ctrl+Enter scoping.

<!-- lang:zh -->

### 亮点

- 快捷键现在会根据操作系统自动显示对应的修饰键（macOS 显示 ⌘，Windows/Linux 显示 Ctrl）。
- 导出模式新增按角色筛选功能：可以只导出用户消息或 AI 消息。
- 新增折叠输入框等增强功能的快捷键。
- 聊天宽度现在能正确适配分屏/窄窗口，并支持 Gemini 宽屏下的表格块。
- Mermaid 图表在全屏查看器中打开时会自动适应视口。
- 修复了文件夹同步、云端认证、KaTeX PDF 导出、Ctrl+Enter 作用域等若干 Bug。

<!-- lang:zh_TW -->

### 亮點

- 快捷鍵現在會根據作業系統自動顯示對應的修飾鍵（macOS 顯示 ⌘，Windows/Linux 顯示 Ctrl）。
- 匯出模式新增按角色篩選功能：可以只匯出使用者訊息或 AI 訊息。
- 新增摺疊輸入框等增強功能的快捷鍵。
- 聊天寬度現在能正確適配分屏/窄視窗，並支援 Gemini 寬螢幕下的表格區塊。
- Mermaid 圖表在全螢幕檢視器中開啟時會自動適應視窗。
- 修復了資料夾同步、雲端驗證、KaTeX PDF 匯出、Ctrl+Enter 作用域等若干 Bug。

<!-- lang:ja -->

### ハイライト

- キーボードショートカットが OS に合わせた修飾キーを表示するようになりました（macOS は ⌘、Windows/Linux は Ctrl）。
- エクスポートモードに送信者別フィルターを追加：ユーザーのみまたは AI のみのメッセージを選択可能に。
- 入力ボックスの折りたたみなど、新しいキーボードショートカットを追加。
- チャット幅が分割画面/狭いウィンドウに正しく適応し、ワイドスクリーンでの Gemini テーブルブロックにも対応。
- Mermaid ダイアグラムがフルスクリーンビューアーで開いた際にビューポートに自動フィットするようになりました。
- フォルダ同期、クラウド認証、KaTeX PDF エクスポート、Ctrl+Enter のスコープなど、複数のバグを修正。

<!-- lang:fr -->

### Points forts

- Les raccourcis clavier affichent désormais les touches modificatrices adaptées à votre système (⌘ sur macOS, Ctrl sur Windows/Linux).
- Nouveau filtre d'exportation : sélectionnez les messages par rôle (utilisateur uniquement ou IA uniquement) en mode export.
- Nouveaux raccourcis clavier pour réduire la zone de saisie et d'autres fonctionnalités améliorées.
- La largeur du chat s'adapte désormais correctement en écran partagé / fenêtre étroite et prend en charge les blocs de tableaux Gemini en mode écran large.
- Les diagrammes Mermaid s'ajustent automatiquement à la fenêtre d'affichage en mode plein écran.
- Correction de plusieurs bugs dans la synchronisation des dossiers, l'authentification cloud, l'export PDF KaTeX et la portée de Ctrl+Entrée.

<!-- lang:es -->

### Destacados

- Los atajos de teclado ahora muestran las teclas modificadoras apropiadas para tu sistema (⌘ en macOS, Ctrl en Windows/Linux).
- Nuevo filtro de exportación: selecciona mensajes por rol (solo usuario o solo IA) en el modo de exportación.
- Nuevos atajos de teclado para colapsar el cuadro de entrada y otras funciones mejoradas.
- El ancho del chat ahora se adapta correctamente a pantallas divididas/ventanas estrechas y soporta bloques de tabla de Gemini en pantalla ancha.
- Los diagramas Mermaid se ajustan automáticamente a la ventana al abrir el visor de pantalla completa.
- Corrección de varios errores en la sincronización de carpetas, autenticación en la nube, exportación PDF KaTeX y el alcance de Ctrl+Enter.

<!-- lang:pt -->

### Destaques

- Os atalhos de teclado agora exibem as teclas modificadoras corretas para seu sistema (⌘ no macOS, Ctrl no Windows/Linux).
- Novo filtro de exportação: selecione mensagens por papel (apenas usuário ou apenas IA) no modo de exportação.
- Novos atalhos de teclado para recolher a caixa de entrada e outras funcionalidades aprimoradas.
- A largura do chat agora se adapta corretamente a telas divididas/janelas estreitas e suporta blocos de tabela do Gemini em tela ampla.
- Os diagramas Mermaid agora se ajustam automaticamente à janela ao abrir o visualizador em tela cheia.
- Correção de vários bugs na sincronização de pastas, autenticação na nuvem, exportação PDF KaTeX e escopo do Ctrl+Enter.

<!-- lang:ar -->

### أبرز التحديثات

- أصبحت اختصارات لوحة المفاتيح تعرض مفاتيح التعديل المناسبة لنظامك (⌘ على macOS، Ctrl على Windows/Linux).
- فلتر تصدير جديد: اختر الرسائل حسب الدور (المستخدم فقط أو الذكاء الاصطناعي فقط) في وضع التصدير.
- اختصارات جديدة لطي مربع الإدخال وميزات محسنة أخرى.
- عرض الدردشة يتكيف الآن بشكل صحيح مع الشاشات المقسمة/النوافذ الضيقة ويدعم كتل جداول Gemini في الشاشة العريضة.
- مخططات Mermaid تتناسب تلقائياً مع إطار العرض عند فتح العارض بملء الشاشة.
- إصلاح عدد من الأخطاء في مزامنة المجلدات والمصادقة السحابية وتصدير KaTeX PDF ونطاق Ctrl+Enter.

<!-- lang:ru -->

### Основные изменения

- Клавиатурные сочетания теперь показывают правильные клавиши-модификаторы для вашей ОС (⌘ на macOS, Ctrl на Windows/Linux).
- Новый фильтр экспорта: выбор сообщений по роли (только пользователь или только ИИ) в режиме экспорта.
- Новые сочетания клавиш для сворачивания поля ввода и других улучшенных функций.
- Ширина чата теперь корректно адаптируется для разделённых экранов / узких окон и поддерживает табличные блоки Gemini в широкоэкранном режиме.
- Диаграммы Mermaid автоматически подстраиваются под область просмотра при открытии в полноэкранном режиме.
- Исправлено несколько ошибок в синхронизации папок, облачной аутентификации, экспорте PDF с KaTeX и области действия Ctrl+Enter.

<!-- lang:ko -->

### 주요 변경사항

- 키보드 단축키가 이제 운영체제에 맞는 수정자 키를 표시합니다 (macOS 는 ⌘, Windows/Linux는 Ctrl).
- 새 내보내기 필터: 내보내기 모드에서 역할별 (사용자만 또는 AI 만) 메시지 선택 가능.
- 입력 상자 접기 등 향상된 기능을 위한 새 키보드 단축키 추가.
- 채팅 너비가 분할 화면/좁은 창에 올바르게 적응하고, 와이드스크린에서 Gemini 표 블록을 지원합니다.
- Mermaid 다이어그램이 전체 화면 뷰어에서 열릴 때 뷰포트에 자동으로 맞춰집니다.
- 폴더 동기화, 클라우드 인증, KaTeX PDF 내보내기, Ctrl+Enter 범위 지정 등 여러 버그를 수정했습니다.
`;export{a as default};
