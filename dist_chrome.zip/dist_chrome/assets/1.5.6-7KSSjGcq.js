const e=`<!-- lang:en -->

### What's New

- **Highlight annotations**: Select text in a Gemini reply to highlight it — highlights are saved, sync to Google Drive, and can be imported/exported.
- **Storage controls**: A new popup panel shows how much storage the extension is using and lets you review and clear it.
- **Compact timeline view**: A new denser layout for the timeline preview with a guided first-run choice — now available on Claude too.

### Fixes

- **Vim mode overlay**: The mode indicator no longer covers the prompt input — it sits below your text again.
- **Vim mode editing & navigation**: Vim keys now work when editing a sent message, and j/k step across blank lines correctly.
- **Default model & thinking level**: Auto-applying your default now handles the inline extended-thinking control, and Firefox's default thinking level is restored.
- **Usage bar refresh icon**: Fixed the refresh icon's size and alignment on the usage bar.
- **Timeline compact view starring**: Restored long-press to star a conversation in the compact timeline view.
- **Smoother timeline & Firefox rendering**: Faster timeline navigation and marker handling, plus a smoother sakura petal animation on Firefox.

---

> *"The palest ink is better than the best memory." — Chinese proverb*

<!-- lang:zh -->

### 新功能

- **高亮标注**：在 Gemini 回复中选中文字即可高亮标记，高亮会自动保存、同步到 Google Drive，也支持导入导出。
- **存储空间管理**：弹窗新增存储用量面板，可查看扩展占用了多少空间并进行清理。
- **时间线紧凑视图**：时间线预览新增更紧凑的布局，并带首次使用引导——Claude 上也能用了。

### 修复

- **Vim 模式状态浮层**：修复了状态浮层挡住输入框的问题，现在它会重新回到文字下方。
- **Vim 模式编辑与导航**：修复了编辑已发送消息时 Vim 按键失效的问题，j/k 现在也能正确跨过空行移动。
- **默认模型与思考强度**：自动应用默认模型时能正确处理内联的扩展思考开关，并修复了 Firefox 上思考强度默认值丢失的问题。
- **用量条刷新图标**：修复了用量条上刷新图标的大小和对齐问题。
- **时间线紧凑视图收藏**：恢复了紧凑视图下长按收藏对话的功能。
- **时间线与 Firefox 渲染更流畅**：时间线跳转和标记处理更快，Firefox 上的樱花动画也更流畅。

---

> *「好记性不如烂笔头。」——中国谚语*

<!-- lang:zh_TW -->

### 新功能

- **重點標註**：在 Gemini 回覆中選取文字即可標記重點，重點會自動儲存、同步到 Google 雲端硬碟，也支援匯入匯出。
- **儲存空間管理**：彈出視窗新增儲存用量面板，可檢視擴充功能佔用了多少空間並進行清理。
- **時間軸精簡檢視**：時間軸預覽新增更精簡的版面，並附首次使用引導——Claude 上也能用了。

### 修復

- **Vim 模式狀態浮層**：修復了狀態浮層擋住輸入框的問題，現在它會重新回到文字下方。
- **Vim 模式編輯與導覽**：修復了編輯已傳送訊息時 Vim 按鍵失效的問題，j/k 現在也能正確跨過空行移動。
- **預設模型與思考強度**：自動套用預設模型時能正確處理內聯的延伸思考開關，並修復了 Firefox 上思考強度預設值遺失的問題。
- **用量列刷新圖示**：修復了用量列上刷新圖示的大小和對齊問題。
- **時間軸精簡檢視收藏**：恢復了精簡檢視下長按收藏對話的功能。
- **時間軸與 Firefox 渲染更流暢**：時間軸跳轉和標記處理更快，Firefox 上的櫻花動畫也更流暢。

---

> *「好記性不如爛筆頭。」——中國諺語*

<!-- lang:ja -->

### 新機能

- **ハイライト注釈**：Gemini の回答内でテキストを選択するとハイライトを付けられます。ハイライトは自動保存され、Google ドライブに同期でき、インポート/エクスポートにも対応しています。
- **ストレージ管理**：使用量パネルをポップアップに追加し、拡張機能が使用しているストレージ量の確認と整理ができるようになりました。
- **タイムラインのコンパクト表示**：タイムラインプレビューに、より省スペースな表示と初回ガイドを追加しました。Claude でも使えます。

### 修正

- **Vim モードのオーバーレイ**：モードインジケーターが入力欄を覆ってしまう問題を修正し、再びテキストの下に表示されるようにしました。
- **Vim モードの編集とナビゲーション**：送信済みメッセージを編集する際に Vim キーが効かない問題を修正し、j/k で空行も正しく移動できるようにしました。
- **既定モデルと思考レベル**：既定モデルの自動適用がインラインの拡張思考トグルを正しく扱うようになり、Firefox で思考レベルの既定値が失われる問題も修正しました。
- **使用量バーの更新アイコン**：使用量バーの更新アイコンのサイズと配置を修正しました。
- **タイムラインのコンパクト表示でのスター付け**：コンパクト表示で長押しして会話にスターを付ける操作を復元しました。
- **タイムラインと Firefox の描画をより滑らかに**：タイムラインの移動とマーカー処理が速くなり、Firefox での桜の花びらのアニメーションも滑らかになりました。

---

> *「どんなに優れた記憶も、薄い墨一滴には及ばない。」——中国のことわざ*

<!-- lang:fr -->

### Nouveautés

- **Annotations en surbrillance** : Sélectionnez du texte dans une réponse de Gemini pour le surligner — les surlignages sont enregistrés, synchronisés sur Google Drive et peuvent être importés/exportés.
- **Contrôles de stockage** : Un nouveau panneau dans le popup indique l'espace de stockage utilisé par l'extension et permet de le consulter et de le libérer.
- **Vue compacte de la chronologie** : Une nouvelle disposition plus dense pour l'aperçu de la chronologie, avec un choix guidé au premier lancement — désormais disponible sur Claude aussi.

### Corrections

- **Superposition du mode Vim** : L'indicateur de mode ne recouvre plus le champ de saisie — il repasse sous votre texte.
- **Édition et navigation en mode Vim** : Les touches Vim fonctionnent désormais lors de la modification d'un message envoyé, et j/k franchissent correctement les lignes vides.
- **Modèle par défaut et niveau de réflexion** : L'application automatique du modèle par défaut gère désormais le réglage de réflexion étendue en ligne, et le niveau de réflexion par défaut de Firefox est rétabli.
- **Icône d'actualisation de la barre d'utilisation** : Correction de la taille et de l'alignement de l'icône d'actualisation sur la barre d'utilisation.
- **Étoile en vue compacte de la chronologie** : Rétablissement de l'appui long pour ajouter une conversation aux favoris en vue compacte.
- **Chronologie et rendu Firefox plus fluides** : Navigation et gestion des marqueurs plus rapides dans la chronologie, et animation des pétales de sakura plus fluide sur Firefox.

---

> *« L'encre la plus pâle vaut mieux que la meilleure mémoire. » — Proverbe chinois*

<!-- lang:es -->

### Novedades

- **Anotaciones resaltadas**: Selecciona texto en una respuesta de Gemini para resaltarlo — los resaltados se guardan, se sincronizan con Google Drive y se pueden importar/exportar.
- **Controles de almacenamiento**: Un nuevo panel en el popup muestra cuánto almacenamiento usa la extensión y te permite revisarlo y liberarlo.
- **Vista compacta de la línea de tiempo**: Un nuevo diseño más denso para la vista previa de la línea de tiempo, con una elección guiada la primera vez — ahora también disponible en Claude.

### Correcciones

- **Superposición del modo Vim**: El indicador de modo ya no tapa el campo de entrada — vuelve a colocarse debajo de tu texto.
- **Edición y navegación en modo Vim**: Las teclas Vim ahora funcionan al editar un mensaje enviado, y j/k avanzan correctamente por las líneas en blanco.
- **Modelo predeterminado y nivel de razonamiento**: La aplicación automática del modelo predeterminado ahora gestiona el control de razonamiento extendido en línea, y se restaura el nivel de razonamiento predeterminado en Firefox.
- **Icono de actualización de la barra de uso**: Se corrigió el tamaño y la alineación del icono de actualización en la barra de uso.
- **Marcar con estrella en la vista compacta de la línea de tiempo**: Se restauró la pulsación larga para marcar una conversación en la vista compacta.
- **Línea de tiempo y renderizado en Firefox más fluidos**: Navegación y gestión de marcadores más rápidas en la línea de tiempo, y una animación de pétalos de sakura más fluida en Firefox.

---

> *« La tinta más pálida es mejor que la mejor memoria. » — Proverbio chino*

<!-- lang:pt -->

### Novidades

- **Anotações destacadas**: Selecione texto em uma resposta do Gemini para destacá-lo — os destaques são salvos, sincronizados com o Google Drive e podem ser importados/exportados.
- **Controles de armazenamento**: Um novo painel no popup mostra quanto armazenamento a extensão usa e permite revisá-lo e liberá-lo.
- **Visão compacta da linha do tempo**: Um novo layout mais denso para a prévia da linha do tempo, com uma escolha guiada na primeira vez — agora também disponível no Claude.

### Correções

- **Sobreposição do modo Vim**: O indicador de modo não cobre mais o campo de entrada — ele volta a ficar abaixo do seu texto.
- **Edição e navegação no modo Vim**: As teclas Vim agora funcionam ao editar uma mensagem enviada, e j/k avançam corretamente pelas linhas em branco.
- **Modelo padrão e nível de raciocínio**: A aplicação automática do modelo padrão agora lida com o controle de raciocínio estendido em linha, e o nível de raciocínio padrão do Firefox foi restaurado.
- **Ícone de atualização da barra de uso**: Corrigidos o tamanho e o alinhamento do ícone de atualização na barra de uso.
- **Favoritar na visão compacta da linha do tempo**: Restaurado o toque longo para favoritar uma conversa na visão compacta.
- **Linha do tempo e renderização no Firefox mais fluidas**: Navegação e tratamento de marcadores mais rápidos na linha do tempo, e uma animação de pétalas de sakura mais fluida no Firefox.

---

> *« A tinta mais pálida é melhor que a melhor memória. » — Provérbio chinês*

<!-- lang:ar -->

### الجديد

- **تعليقات التمييز**: حدّد نصًا في رد Gemini لتمييزه — تُحفظ التمييزات وتُزامَن مع Google Drive ويمكن استيرادها وتصديرها.
- **إدارة التخزين**: لوحة جديدة في النافذة المنبثقة تعرض حجم التخزين الذي يستخدمه الامتداد وتتيح لك مراجعته وتفريغه.
- **العرض المضغوط للخط الزمني**: تخطيط جديد أكثر إحكامًا لمعاينة الخط الزمني مع اختيار موجَّه عند أول استخدام — ومتاح الآن على Claude أيضًا.

### الإصلاحات

- **تراكب وضع Vim**: لم يعد مؤشر الوضع يغطي حقل الإدخال — عاد ليظهر أسفل النص.
- **التحرير والتنقل في وضع Vim**: أصبحت مفاتيح Vim تعمل عند تحرير رسالة مُرسَلة، وأصبح j/k يتنقلان عبر الأسطر الفارغة بشكل صحيح.
- **النموذج الافتراضي ومستوى التفكير**: أصبح التطبيق التلقائي للنموذج الافتراضي يتعامل مع مفتاح التفكير الموسّع المضمّن بشكل صحيح، واستُعيد مستوى التفكير الافتراضي على Firefox.
- **أيقونة التحديث في شريط الاستخدام**: تم إصلاح حجم أيقونة التحديث ومحاذاتها في شريط الاستخدام.
- **التمييز بنجمة في العرض المضغوط للخط الزمني**: تمت استعادة الضغط المطوّل لإضافة محادثة إلى المفضلة في العرض المضغوط.
- **خط زمني وعرض أكثر سلاسة على Firefox**: تنقّل ومعالجة علامات أسرع في الخط الزمني، وحركة بتلات الساكورا أكثر سلاسة على Firefox.

---

> *«أضعف حبر خير من أقوى ذاكرة.» — مثل صيني*

<!-- lang:ko -->

### 새로운 기능

- **하이라이트 주석**: Gemini 답변에서 텍스트를 선택해 강조 표시할 수 있습니다. 강조 표시는 자동 저장되고 Google 드라이브에 동기화되며 가져오기/내보내기도 지원합니다.
- **저장 공간 관리**: 팝업에 사용량 패널을 추가해 확장 프로그램이 사용하는 저장 공간을 확인하고 정리할 수 있습니다.
- **타임라인 압축 보기**: 타임라인 미리보기에 더 조밀한 레이아웃과 첫 사용 안내를 추가했습니다. Claude에서도 사용할 수 있습니다.

### 수정

- **Vim 모드 오버레이**: 모드 표시기가 입력창을 가리던 문제를 수정해 다시 텍스트 아래에 표시됩니다.
- **Vim 모드 편집 및 이동**: 보낸 메시지를 편집할 때 Vim 키가 작동하지 않던 문제를 수정했고, j/k로 빈 줄도 올바르게 이동합니다.
- **기본 모델 및 사고 강도**: 기본 모델 자동 적용이 인라인 확장 사고 토글을 올바르게 처리하도록 했고, Firefox에서 사고 강도 기본값이 사라지던 문제를 수정했습니다.
- **사용량 막대 새로고침 아이콘**: 사용량 막대의 새로고침 아이콘 크기와 정렬을 수정했습니다.
- **타임라인 압축 보기 즐겨찾기**: 압축 보기에서 길게 눌러 대화를 즐겨찾기하는 기능을 복원했습니다.
- **타임라인과 Firefox 렌더링이 더 부드럽게**: 타임라인 이동과 마커 처리가 빨라졌고, Firefox에서 벚꽃(사쿠라) 애니메이션도 더 부드러워졌습니다.

---

> *"아무리 좋은 기억력도 무딘 붓만 못하다." — 중국 속담*

<!-- lang:ru -->

### Новое

- **Аннотации-выделения**: Выделите текст в ответе Gemini, чтобы подсветить его — выделения сохраняются, синхронизируются с Google Диском и поддерживают импорт/экспорт.
- **Управление хранилищем**: Новая панель во всплывающем окне показывает, сколько места занимает расширение, и позволяет просмотреть и очистить его.
- **Компактный вид временной шкалы**: Новый более плотный вид для предпросмотра временной шкалы с подсказкой при первом запуске — теперь доступен и в Claude.

### Исправления

- **Наложение режима Vim**: Индикатор режима больше не закрывает поле ввода — он снова располагается под вашим текстом.
- **Редактирование и навигация в режиме Vim**: Клавиши Vim теперь работают при редактировании отправленного сообщения, а j/k корректно перешагивают пустые строки.
- **Модель по умолчанию и уровень рассуждений**: Автоприменение модели по умолчанию теперь корректно работает со встроенным переключателем расширенного мышления, а уровень рассуждений по умолчанию в Firefox восстановлен.
- **Значок обновления на панели использования**: Исправлены размер и выравнивание значка обновления на панели использования.
- **Избранное в компактном виде временной шкалы**: Восстановлено долгое нажатие для добавления переписки в избранное в компактном виде.
- **Более плавная временная шкала и отрисовка в Firefox**: Быстрее навигация и обработка маркеров на временной шкале, а также более плавная анимация лепестков сакуры в Firefox.

---

> *«Самые бледные чернила лучше самой хорошей памяти.» — китайская пословица*
`;export{e as default};
