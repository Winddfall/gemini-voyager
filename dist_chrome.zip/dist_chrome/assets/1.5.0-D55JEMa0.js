const e=`<!-- lang:en -->

### What's New

- **Usage status bar** *(off by default)*: Show Gemini daily and weekly usage near the composer, with a one-time intro and silent refreshes after responses.
- **Remote Voyager notices**: Voyager reads a public JSON feed as data only (title, body, HTTPS link) and shows it locally; the feed cannot inject or run remote code.
- **Edge Add-ons support continues**: Voyager will keep maintaining the Microsoft Edge Add-ons build for users who need Edge on mobile or tablet.
- **Light-mode code blocks**: Gemini code blocks now follow the page theme, so light pages no longer get a glaring dark code surface.
- **YouTube covers in exports**: Exported conversations now keep YouTube video covers as clickable images.

### Fixes

- **Folders on the new Gemini sidebar**: Restored folders after Gemini moved its sidebar state to a new shell element.
- **Faster sidebar opening**: Large chat histories no longer trigger the worst per-row sidebar scans, especially noticeable in Firefox.
- **Export toolbar placement**: The persistent export toolbar appears immediately on the new logoless UI and stays in the top-right control area.
- **Firefox notification updates**: Notification permission is optional again, so Firefox updates no longer get stuck behind a required-permission prompt.
- **Multi-account gem links**: Sidebar gem links now keep the current Gemini account window instead of reusing another tab's \`/u/N\` path.
- **Conversation restore scrolling**: Voyager no longer blocks Gemini's own scroll restoration when reopening or switching conversations.
- **Default model switching**: Rejected auto-switches and selector flashes are guarded more tightly.
- **Stacked watermarks**: Watermark removal repeats when images contain multiple stacked marks.

<!-- lang:zh -->

### 新功能

- **用量状态栏** *（默认关闭）*：在输入框附近显示 Gemini 每日和每周用量，并在回复后静默刷新，首次开启会有一次性引导。
- **Voyager 远程公告**：Voyager 只把公开 JSON 当数据读取（标题、正文、HTTPS 链接）并在本地提示；公告源不能远程注入或执行代码。
- **继续维护 Edge Add-ons**：考虑到移动端和平板用户需求，Voyager 会继续维护并发布 Microsoft Edge Add-ons 版本。
- **浅色代码块**：Gemini 代码块现在会跟随页面主题，浅色页面不再突然出现刺眼的深色代码区域。
- **导出保留 YouTube 封面**：导出的对话现在会把 YouTube 视频封面保留为可点击图片。

### 修复

- **新版 Gemini 侧边栏中的文件夹**：Gemini 将侧边栏状态移到新的外壳元素后，文件夹消失的问题已修复。
- **侧边栏打开更快**：长历史记录不再触发最重的逐行扫描，Firefox 上尤其明显。
- **导出工具栏位置**：新版无 Logo UI 中，常驻导出工具栏会立即出现，并保持在右上角控制区。
- **Firefox 通知更新**：通知权限重新改为可选，Firefox 更新不再被必需权限确认卡住。
- **多账号 Gem 链接**：侧边栏 Gem 链接现在保留当前 Gemini 账号窗口，不会复用其他标签页的 \`/u/N\` 路径。
- **对话恢复滚动**：重新打开或切换对话时，Voyager 不再阻止 Gemini 自己的滚动恢复。
- **默认模型切换**：更严格地避免被拒绝的自动切换循环和选择器闪烁。
- **叠加水印**：图片里有多层水印时，去水印会重复处理。

<!-- lang:zh_TW -->

### 新功能

- **用量狀態列** *（預設關閉）*：在輸入框附近顯示 Gemini 每日與每週用量，並在回覆後靜默重新整理，首次啟用會有一次性引導。
- **Voyager 遠端公告**：Voyager 只把公開 JSON 當資料讀取（標題、正文、HTTPS 連結）並在本機提示；公告來源不能遠端注入或執行程式碼。
- **繼續維護 Edge Add-ons**：考量到行動端和平板使用者需求，Voyager 會繼續維護並發布 Microsoft Edge Add-ons 版本。
- **淺色程式碼區塊**：Gemini 程式碼區塊現在會跟隨頁面主題，淺色頁面不再突然出現刺眼的深色程式碼區域。
- **匯出保留 YouTube 封面**：匯出的對話現在會把 YouTube 影片封面保留為可點擊圖片。

### 修復

- **新版 Gemini 側邊欄中的資料夾**：Gemini 將側邊欄狀態移到新的外殼元素後，資料夾消失的問題已修復。
- **側邊欄開啟更快**：長歷史記錄不再觸發最重的逐列掃描，Firefox 上尤其明顯。
- **匯出工具列位置**：新版無 Logo UI 中，常駐匯出工具列會立即出現，並保持在右上角控制區。
- **Firefox 通知更新**：通知權限重新改為選用，Firefox 更新不再被必要權限確認卡住。
- **多帳號 Gem 連結**：側邊欄 Gem 連結現在保留目前 Gemini 帳號視窗，不會複用其他分頁的 \`/u/N\` 路徑。
- **對話恢復捲動**：重新開啟或切換對話時，Voyager 不再阻止 Gemini 自己的捲動恢復。
- **預設模型切換**：更嚴格地避免被拒絕的自動切換循環和選擇器閃爍。
- **疊加浮水印**：圖片裡有多層浮水印時，去浮水印會重複處理。

<!-- lang:ja -->

### 新機能

- **使用量ステータスバー** *(デフォルトはオフ)*：入力欄の近くに Gemini の日次・週次使用量を表示し、返信後に静かに更新します。初回は一度だけ案内が出ます。
- **Voyager のリモート通知**：Voyager は公開 JSON をデータ（タイトル、本文、HTTPS リンク）として読むだけでローカル表示します。フィードからコードを注入・実行することはできません。
- **Edge Add-ons のサポート継続**：モバイルやタブレットで Edge が必要なユーザーのため、Voyager は Microsoft Edge Add-ons 版の保守と公開を継続します。
- **ライトモードのコードブロック**：Gemini のコードブロックがページテーマに従うようになり、明るいページで急に濃いコード面が出なくなりました。
- **エクスポートで YouTube カバーを保持**：エクスポートした会話に、YouTube 動画のカバー画像がクリック可能な画像として残るようになりました。

### 修正

- **新しい Gemini サイドバーのフォルダ**：Gemini がサイドバー状態を新しいシェル要素へ移したことでフォルダが消える問題を修正しました。
- **サイドバー表示の高速化**：長いチャット履歴で重い行ごとのスキャンが走りにくくなり、特に Firefox で体感しやすくなりました。
- **エクスポートツールバーの配置**：新しいロゴなし UI で常設エクスポートツールバーがすぐ表示され、右上の操作エリアに収まります。
- **Firefox の通知権限更新**：通知権限が再び任意になり、Firefox の更新が必須権限の確認で止まらなくなりました。
- **複数アカウントの Gem リンク**：サイドバーの Gem リンクが、別タブの \`/u/N\` パスではなく現在の Gemini アカウントを保つようになりました。
- **会話復元時のスクロール**：会話を開き直したり切り替えたりするとき、Voyager が Gemini 本来のスクロール復元を邪魔しなくなりました。
- **デフォルトモデル切り替え**：拒否された自動切り替えループとセレクターのちらつきをより厳しく防ぎます。
- **重なった透かし**：画像に複数の透かしが重なっている場合、除去処理を繰り返すようになりました。

<!-- lang:fr -->

### Nouveautés

- **Barre d'utilisation** *(désactivée par défaut)* : Affiche les limites quotidiennes et hebdomadaires de Gemini près du champ de saisie, avec une introduction unique et des actualisations silencieuses après les réponses.
- **Annonces Voyager à distance** : Voyager lit un JSON public comme de simples données (titre, corps, lien HTTPS) et l'affiche localement ; le flux ne peut pas injecter ni exécuter de code distant.
- **Support Edge Add-ons maintenu** : Voyager continuera de maintenir et publier la version Microsoft Edge Add-ons pour les personnes qui ont besoin d'Edge sur mobile ou tablette.
- **Blocs de code en mode clair** : Les blocs de code de Gemini suivent maintenant le thème de la page, sans surface sombre agressive sur les pages claires.
- **Miniatures YouTube dans les exports** : Les conversations exportées conservent les miniatures YouTube sous forme d'images cliquables.

### Corrections

- **Dossiers dans la nouvelle barre latérale Gemini** : Les dossiers réapparaissent après le déplacement de l'état de barre latérale vers un nouvel élément shell de Gemini.
- **Ouverture plus rapide de la barre latérale** : Les longs historiques ne déclenchent plus les scans ligne par ligne les plus coûteux, surtout visible dans Firefox.
- **Position de la barre d'export** : La barre d'export persistante apparaît immédiatement dans la nouvelle interface sans logo et reste dans la zone de contrôle en haut à droite.
- **Mises à jour Firefox et notifications** : L'autorisation de notifications est de nouveau optionnelle, donc les mises à jour Firefox ne restent plus bloquées derrière une demande de permission obligatoire.
- **Liens Gem multi-comptes** : Les liens Gem de la barre latérale gardent désormais le compte Gemini de la fenêtre courante au lieu de réutiliser le chemin \`/u/N\` d'un autre onglet.
- **Restauration du défilement des conversations** : Voyager ne bloque plus la restauration de défilement native de Gemini lors de la réouverture ou du changement de conversation.
- **Changement de modèle par défaut** : Les boucles de changement automatique refusé et les clignotements du sélecteur sont mieux contenus.
- **Filigranes empilés** : La suppression du filigrane se répète quand une image contient plusieurs marques superposées.

<!-- lang:es -->

### Novedades

- **Barra de uso** *(desactivada por defecto)*: Muestra el uso diario y semanal de Gemini cerca del cuadro de entrada, con una introducción única y actualizaciones silenciosas después de las respuestas.
- **Avisos remotos de Voyager**: Voyager lee un JSON público solo como datos (título, texto y enlace HTTPS) y lo muestra localmente; el feed no puede inyectar ni ejecutar código remoto.
- **Soporte de Edge Add-ons continuo**: Voyager seguirá manteniendo y publicando la versión de Microsoft Edge Add-ons para quienes necesitan Edge en móvil o tablet.
- **Bloques de código en modo claro**: Los bloques de código de Gemini siguen ahora el tema de la página, sin una superficie oscura molesta en páginas claras.
- **Miniaturas de YouTube en exportaciones**: Las conversaciones exportadas conservan las miniaturas de YouTube como imágenes clicables.

### Correcciones

- **Carpetas en la nueva barra lateral de Gemini**: Las carpetas vuelven a mostrarse después de que Gemini moviera el estado de la barra lateral a un nuevo elemento contenedor.
- **Apertura más rápida de la barra lateral**: Los historiales grandes ya no activan los escaneos por fila más pesados, especialmente notable en Firefox.
- **Ubicación de la barra de exportación**: La barra de exportación persistente aparece de inmediato en la nueva interfaz sin logo y se mantiene en el área de controles superior derecha.
- **Actualizaciones de Firefox y notificaciones**: El permiso de notificaciones vuelve a ser opcional, así que las actualizaciones de Firefox ya no se quedan bloqueadas por una solicitud de permiso obligatorio.
- **Enlaces Gem multi-cuenta**: Los enlaces Gem de la barra lateral conservan la cuenta Gemini de la ventana actual en lugar de reutilizar la ruta \`/u/N\` de otra pestaña.
- **Restauración del desplazamiento de conversaciones**: Voyager ya no bloquea la restauración de desplazamiento propia de Gemini al reabrir o cambiar conversaciones.
- **Cambio de modelo predeterminado**: Se controlan mejor los bucles de cambio automático rechazado y los parpadeos del selector.
- **Marcas de agua apiladas**: La eliminación de marca de agua se repite cuando una imagen contiene varias marcas superpuestas.

<!-- lang:pt -->

### Novidades

- **Barra de uso** *(desativada por padrão)*: Mostra o uso diário e semanal do Gemini perto da caixa de entrada, com uma introdução única e atualizações silenciosas depois das respostas.
- **Avisos remotos do Voyager**: O Voyager lê um JSON público apenas como dados (título, corpo e link HTTPS) e mostra localmente; o feed não pode injetar nem executar código remoto.
- **Suporte ao Edge Add-ons continua**: O Voyager continuará mantendo e publicando a versão do Microsoft Edge Add-ons para quem precisa do Edge em celulares ou tablets.
- **Blocos de código no modo claro**: Os blocos de código do Gemini agora seguem o tema da página, sem uma superfície escura chamativa em páginas claras.
- **Capas do YouTube nas exportações**: As conversas exportadas mantêm capas de vídeos do YouTube como imagens clicáveis.

### Correções

- **Pastas na nova barra lateral do Gemini**: As pastas voltam a aparecer depois que o Gemini moveu o estado da barra lateral para um novo elemento de shell.
- **Abertura mais rápida da barra lateral**: Históricos longos já não disparam os scans por linha mais pesados, especialmente perceptível no Firefox.
- **Posição da barra de exportação**: A barra de exportação persistente aparece imediatamente na nova interface sem logo e permanece na área de controlos no canto superior direito.
- **Atualizações do Firefox e notificações**: A permissão de notificações voltou a ser opcional, portanto as atualizações do Firefox já não ficam presas num pedido de permissão obrigatório.
- **Links Gem multi-conta**: Os links Gem da barra lateral agora preservam a conta Gemini da janela atual em vez de reutilizar o caminho \`/u/N\` de outro separador.
- **Restauração de scroll das conversas**: O Voyager já não bloqueia a restauração de scroll nativa do Gemini ao reabrir ou trocar de conversa.
- **Troca do modelo padrão**: Ciclos de troca automática rejeitada e piscadas do seletor ficam mais bem controlados.
- **Marcas d'água empilhadas**: A remoção de marca d'água repete o processo quando uma imagem contém várias marcas sobrepostas.

<!-- lang:ar -->

### الجديد

- **شريط حالة الاستخدام** *(موقوف افتراضيًا)*: يعرض استخدام Gemini اليومي والأسبوعي قرب مربع الإدخال، مع تعريف لمرة واحدة وتحديثات صامتة بعد الردود.
- **إشعارات Voyager البعيدة**: يقرأ Voyager ملف JSON عامًا كبيانات فقط (عنوان ونص ورابط HTTPS) ويعرضه محليًا؛ لا يستطيع الموجز حقن كود بعيد أو تشغيله.
- **استمرار دعم Edge Add-ons**: سيواصل Voyager صيانة ونشر إصدار Microsoft Edge Add-ons لمن يحتاجون Edge على الهاتف أو الجهاز اللوحي.
- **كتل الكود في الوضع الفاتح**: أصبحت كتل الكود في Gemini تتبع سمة الصفحة، فلا تظهر مساحة داكنة مزعجة داخل الصفحات الفاتحة.
- **أغلفة YouTube في التصدير**: تحتفظ المحادثات المصدّرة بأغلفة فيديوهات YouTube كصور قابلة للنقر.

### الإصلاحات

- **المجلدات في الشريط الجانبي الجديد لـ Gemini**: عادت المجلدات للظهور بعد أن نقل Gemini حالة الشريط الجانبي إلى عنصر غلاف جديد.
- **فتح الشريط الجانبي بسرعة أكبر**: لم تعد السجلات الطويلة تشغّل أثقل عمليات الفحص لكل صف، وهذا أوضح خصوصًا في Firefox.
- **موضع شريط التصدير**: يظهر شريط التصدير الدائم فورًا في الواجهة الجديدة بلا شعار، ويبقى داخل منطقة التحكم في أعلى اليمين.
- **تحديثات Firefox وإذن الإشعارات**: عاد إذن الإشعارات اختياريًا، لذلك لا تتوقف تحديثات Firefox خلف طلب إذن إلزامي.
- **روابط Gem متعددة الحسابات**: تحافظ روابط Gem في الشريط الجانبي الآن على حساب Gemini في النافذة الحالية بدل إعادة استخدام مسار \`/u/N\` من تبويب آخر.
- **استعادة تمرير المحادثات**: لم يعد Voyager يمنع Gemini من استعادة موضع التمرير عند إعادة فتح المحادثات أو التبديل بينها.
- **تبديل النموذج الافتراضي**: أصبحت حلقات التبديل التلقائي المرفوضة ووميض المحدد أكثر انضباطًا.
- **علامات مائية متراكبة**: تتكرر إزالة العلامة المائية عندما تحتوي الصورة على عدة علامات فوق بعضها.

<!-- lang:ko -->

### 새로운 기능

- **사용량 상태 표시줄** *(기본 꺼짐)*: 입력창 근처에 Gemini 일일 및 주간 사용량을 표시하고, 첫 안내와 응답 후 조용한 새로고침을 제공합니다.
- **Voyager 원격 공지**: Voyager는 공개 JSON을 데이터(제목, 본문, HTTPS 링크)로만 읽어 로컬에 표시합니다. 이 피드는 원격 코드를 주입하거나 실행할 수 없습니다.
- **Edge Add-ons 지원 계속**: 모바일이나 태블릿에서 Edge가 필요한 사용자를 위해 Voyager는 Microsoft Edge Add-ons 버전을 계속 유지하고 배포합니다.
- **라이트 모드 코드 블록**: Gemini 코드 블록이 이제 페이지 테마를 따라가므로 밝은 페이지에서 갑자기 어두운 코드 영역이 튀어나오지 않습니다.
- **내보내기의 YouTube 커버**: 내보낸 대화에 YouTube 동영상 커버가 클릭 가능한 이미지로 유지됩니다.

### 수정

- **새 Gemini 사이드바의 폴더**: Gemini가 사이드바 상태를 새 셸 요소로 옮긴 뒤 폴더가 사라지던 문제를 복구했습니다.
- **더 빠른 사이드바 열기**: 긴 채팅 기록에서 가장 무거운 행 단위 스캔이 더 이상 실행되지 않으며, 특히 Firefox에서 체감됩니다.
- **내보내기 도구막대 위치**: 새 로고 없는 UI에서 고정 내보내기 도구막대가 즉시 나타나고 오른쪽 위 컨트롤 영역에 머뭅니다.
- **Firefox 알림 업데이트**: 알림 권한이 다시 선택 사항이 되어 Firefox 업데이트가 필수 권한 확인에 막히지 않습니다.
- **다중 계정 Gem 링크**: 사이드바 Gem 링크가 다른 탭의 \`/u/N\` 경로를 재사용하지 않고 현재 Gemini 계정 창을 유지합니다.
- **대화 스크롤 복원**: 대화를 다시 열거나 전환할 때 Voyager가 Gemini의 기본 스크롤 복원을 막지 않습니다.
- **기본 모델 전환**: 거부된 자동 전환 루프와 선택기 깜박임을 더 엄격하게 방지합니다.
- **겹친 워터마크**: 이미지에 여러 워터마크가 겹쳐 있을 때 제거 처리를 반복합니다.

<!-- lang:ru -->

### Новое

- **Панель использования** *(выключена по умолчанию)*: Показывает дневные и недельные лимиты Gemini рядом с полем ввода, с одноразовой подсказкой и тихим обновлением после ответов.
- **Удалённые уведомления Voyager**: Voyager читает публичный JSON только как данные (заголовок, текст, HTTPS-ссылка) и показывает их локально; поток не может внедрять или запускать удалённый код.
- **Поддержка Edge Add-ons продолжается**: Voyager продолжит поддерживать и публиковать версию Microsoft Edge Add-ons для тех, кому нужен Edge на телефоне или планшете.
- **Блоки кода в светлом режиме**: Блоки кода Gemini теперь следуют теме страницы, поэтому на светлых страницах больше не появляется резкая тёмная область кода.
- **Обложки YouTube в экспортах**: Экспортированные диалоги сохраняют обложки видео YouTube как кликабельные изображения.

### Исправления

- **Папки в новой боковой панели Gemini**: Папки снова появляются после того, как Gemini перенёс состояние боковой панели в новый shell-элемент.
- **Более быстрое открытие боковой панели**: Длинные истории больше не запускают самые тяжёлые построчные сканы, особенно заметно в Firefox.
- **Положение панели экспорта**: Постоянная панель экспорта сразу появляется в новом интерфейсе без логотипа и остаётся в правой верхней зоне управления.
- **Обновления Firefox и уведомления**: Разрешение на уведомления снова стало необязательным, поэтому обновления Firefox больше не застревают на обязательном запросе разрешения.
- **Gem-ссылки для нескольких аккаунтов**: Ссылки Gem в боковой панели теперь сохраняют текущий аккаунт Gemini в окне, а не переиспользуют путь \`/u/N\` из другой вкладки.
- **Восстановление прокрутки диалогов**: Voyager больше не мешает Gemini восстанавливать прокрутку при повторном открытии или переключении диалогов.
- **Переключение модели по умолчанию**: Отказанные автоматические переключения и мигание селектора теперь жёстче ограничены.
- **Наложенные водяные знаки**: Удаление водяного знака повторяется, если изображение содержит несколько наложенных отметок.
`;export{e as default};
