const e=`<!-- lang:en -->

> *"Not all those who wander are lost." — J. R. R. Tolkien, The Fellowship of the Ring*

### What's New

- **Safari gains native macOS capabilities — and the app is renamed to Voyager**: The direct-download Safari build now connects its WebExtension to native Google Drive and iCloud sync, macOS response-finished notifications that open the right conversation, and—after this one-time migration—future updates through Sparkle. Image export and watermark removal work again, and iCloud backups can be deleted from the popup without touching local data. The host app has been renamed from "Gemini Voyager" to "Voyager". ⚠️ **If you're upgrading, follow the migration guide once before updating so you don't end up with two apps installed.**
- **Vim input mode comes to Claude and ChatGPT**: The message box now supports Vim-style keyboard editing beyond Gemini.
- **Collapsible long code blocks**: Overly long code blocks can be collapsed with a button so they no longer fill the screen while you scroll.
- **Folder-only search**: Type an \`f:\` (or \`folder:\`) prefix in search to match folder names only, with a badge showing when folder search is active.
- **Uploaded files noted in exports**: Exporting a conversation now lists the non-image files you attached (by name), so that context isn't lost.
- **Choose how release notes appear**: Let Voyager open what's new automatically after an update, or show only a \`NEW\` badge until you open it.

### Fixes

- **Smarter, broader watermark removal**: Handles Gemini's latest watermark variants and more logo sizes (including small and downscaled images), succeeds on more borderline cases, and still only runs when a watermark is actually detected. Notebook (NotebookLM) pages are no longer disturbed, Safari again downloads the full-size watermark-free image, and failed removals fall back to a normal download.
- **More reliable usage indicator**: Works consistently on Chromium browsers (Chrome / Edge), no longer flickers to a wrong lower number from stale data, keeps the reset countdown after a refresh, and shows a clickable load prompt when no data is present.
- **Sturdier folders**: Folder assignments survive Gemini's sidebar scrolling (virtualization), clicking a conversation opens the right one, renaming uses Gemini's native dialog and stays in sync, and imports no longer break under contention.
- **Drafts stay with their conversation**: An unsent draft stays in the conversation you typed it in and won't be overwritten when you switch chats.
- **Onboarding tour no longer exits by accident**: Clicking back into the page during the tour no longer ends it — only an explicit close or Escape does.
- **Highlight is now opt-in**: If you never used Highlight, it now starts off (existing highlights stay on and your data is unchanged).
- **Performance and more**: Faster feature startup and lower memory in long conversations, popup settings scroll right away, fullscreen Mermaid cleans up on close, the timeline preview stays in view, export handles lazy-loaded messages, plugin validation blocks remote and script-scheme URLs, and multi-account isolation is sturdier.

<!-- lang:zh -->

> *「并非所有流浪者都迷失了方向。」——J. R. R. 托尔金，《魔戒：护戒同盟》*

### 新功能

- **Safari 接入 macOS 原生能力，App 更名为 Voyager**：Safari 直装版现已把 WebExtension 接入原生 Google Drive 与 iCloud 云同步、回复完成后可直达对应对话的 macOS 系统通知；完成这次迁移后，后续版本还可通过 Sparkle 自动更新。图片导出与水印去除恢复正常，也可在弹窗中删除 iCloud 备份而不影响本机数据。宿主 App 已从「Gemini Voyager」更名为「Voyager」。⚠️ **老用户更新前请先按迁移指南操作一次，避免两个 App 并存。**
- **Vim 输入模式扩展到 Claude 和 ChatGPT**：消息输入框现在支持 Vim 键位编辑，不再只限 Gemini。
- **长代码块可折叠**：过长的代码块可一键折叠，滚动时不再被大段代码占满屏幕。
- **文件夹专属搜索**：在搜索框输入 \`f:\`（或 \`folder:\`）前缀即可只搜索文件夹名，并有徽标提示当前处于文件夹搜索模式。
- **导出会标注上传的文件**：导出对话时，会把你上传的非图片文件按文件名列出来，不再丢失这部分上下文。
- **新版说明展示方式可选**：可让 Voyager 在更新后自动打开新版说明，或只显示 \`NEW\` 徽标，等你需要时再查看。

### 修复

- **水印去除更智能、覆盖更广**：支持 Gemini 最新的水印变体和更多 logo 尺寸（含小图和缩小的大图），更多临界情况也能成功去除，且仍只在真正检测到水印时才处理；不再影响 Notebook（NotebookLM）页面，Safari 恢复下载全尺寸无水印图，去水印失败时回退到正常下载。
- **用量指示更可靠**：在 Chrome / Edge 等 Chromium 浏览器上稳定工作，不再因过时数据跳到错误的更低数值，刷新后保留重置倒计时，无数据时显示可点击的加载入口。
- **文件夹更稳**：文件夹分类在 Gemini 侧边栏滚动（虚拟化）后不再丢失，点击文件夹里的对话会可靠打开正确的那个，重命名改用 Gemini 原生对话框并保持同步，高并发下导入不再出错。
- **草稿绑定所属对话**：未发送的草稿会留在你输入它的那个对话里，切换对话时不会被覆盖。
- **新手引导不再误退出**：引导过程中点回页面不会中断，只有明确关闭或按 Esc 才结束。
- **高亮改为按需开启**：从未使用过高亮的用户现在默认关闭该功能（已有高亮保持开启，数据不变）。
- **性能与其它**：功能启动更快、长对话下更省内存，弹窗设置即时可滚动，Mermaid 全屏关闭后清理干净，时间线预览不再滑出视野，导出正确处理懒加载消息，插件校验拦截远程与脚本协议 URL，多账户隔离更稳。

<!-- lang:zh_TW -->

> *「並非所有流浪者都迷失了方向。」——J. R. R. 托爾金，《魔戒首部曲：魔戒現身》*

### 新功能

- **Safari 接上 macOS 原生能力，App 更名為 Voyager**：Safari 直裝版現已將 WebExtension 接上原生 Google Drive 與 iCloud 雲端同步、回覆完成後可直達對應對話的 macOS 系統通知；完成這次遷移後，後續版本也可透過 Sparkle 自動更新。圖片匯出與浮水印去除恢復正常，也可在彈出視窗中刪除 iCloud 備份而不影響本機資料。宿主 App 已從「Gemini Voyager」更名為「Voyager」。⚠️ **老用戶更新前請先依遷移指南操作一次，避免兩個 App 並存。**
- **Vim 輸入模式擴展到 Claude 和 ChatGPT**：訊息輸入框現在支援 Vim 鍵位編輯，不再僅限 Gemini。
- **長程式碼區塊可摺疊**：過長的程式碼區塊可一鍵摺疊，捲動時不再被大段程式碼占滿螢幕。
- **資料夾專屬搜尋**：在搜尋框輸入 \`f:\`（或 \`folder:\`）前綴即可只搜尋資料夾名稱，並有徽章提示目前處於資料夾搜尋模式。
- **匯出會標註上傳的檔案**：匯出對話時，會把你上傳的非圖片檔案依檔名列出，不再遺失這部分脈絡。
- **新版說明顯示方式可選**：可讓 Voyager 在更新後自動開啟新版說明，或只顯示 \`NEW\` 徽章，等你需要時再查看。

### 修復

- **浮水印去除更聰明、覆蓋更廣**：支援 Gemini 最新的浮水印變體與更多 logo 尺寸（含小圖與縮小的大圖），更多臨界情況也能成功去除，且仍只在真正偵測到浮水印時才處理；不再影響 Notebook（NotebookLM）頁面，Safari 恢復下載全尺寸無浮水印圖，去浮水印失敗時回退到正常下載。
- **用量指示更可靠**：在 Chrome / Edge 等 Chromium 瀏覽器上穩定運作，不再因過時資料跳到錯誤的更低數值，重新整理後保留重置倒數，無資料時顯示可點擊的載入入口。
- **資料夾更穩**：資料夾分類在 Gemini 側邊欄捲動（虛擬化）後不再遺失，點擊資料夾裡的對話會可靠開啟正確的那個，重新命名改用 Gemini 原生對話框並保持同步，高並發下匯入不再出錯。
- **草稿綁定所屬對話**：未送出的草稿會留在你輸入它的那個對話裡，切換對話時不會被覆蓋。
- **新手引導不再誤退出**：引導過程中點回頁面不會中斷，只有明確關閉或按 Esc 才結束。
- **重點標註改為依需開啟**：從未使用過重點標註的用戶現在預設關閉該功能（已有重點保持開啟，資料不變）。
- **效能與其它**：功能啟動更快、長對話下更省記憶體，彈出視窗設定即時可捲動，Mermaid 全螢幕關閉後清理乾淨，時間軸預覽不再滑出視野，匯出正確處理延遲載入的訊息，外掛校驗攔截遠端與指令碼協定 URL，多帳戶隔離更穩。

<!-- lang:ja -->

> *「さまよう者がみな道に迷うとは限らない。」——J. R. R. トールキン、『旅の仲間』*

### 新機能

- **Safari が macOS ネイティブ機能に対応、アプリ名は Voyager に**：Safari 直販版の WebExtension が、ネイティブの Google Drive / iCloud 同期、応答完了後に該当会話を開く macOS システム通知に対応しました。この一度きりの移行後は、以降の更新も Sparkle 経由で受け取れます。画像エクスポートとウォーターマーク除去も正常に動作し、iCloud バックアップはローカルデータに影響せずポップアップから削除できます。ホストアプリ名は「Gemini Voyager」から「Voyager」に変更されました。⚠️ **更新される方は、アプリが二重にならないよう、更新前に一度だけ移行ガイドの手順を実行してください。**
- **Vim 入力モードが Claude と ChatGPT にも**：メッセージ入力欄で Vim 風のキーボード編集が Gemini 以外でも使えるようになりました。
- **長いコードブロックを折りたたみ可能に**：長すぎるコードブロックをボタンで折りたためるので、スクロール中に画面を占有しなくなります。
- **フォルダ限定検索**：検索欄で \`f:\`（または \`folder:\`）を先頭に付けるとフォルダ名だけを検索でき、フォルダ検索中はバッジで表示されます。
- **アップロードしたファイルをエクスポートに記載**：会話をエクスポートすると、アップロードした画像以外のファイルがファイル名で一覧化され、その文脈が失われなくなりました。
- **リリースノートの表示方法を選択可能に**：更新後に Voyager が新機能を自動表示するか、開くまで \`NEW\` バッジだけを表示するか選べます。

### 修正

- **より賢く、対応範囲も広がったウォーターマーク除去**：Gemini の最新のウォーターマーク種別とより多くのロゴサイズ（小さい画像や縮小された大きい画像を含む）に対応し、より多くの境界ケースでも除去に成功します。実際に検出したときだけ処理する点は変わりません。Notebook（NotebookLM）ページを妨げなくなり、Safari では再びフルサイズのウォーターマークなし画像をダウンロードでき、除去に失敗した場合は通常のダウンロードにフォールバックします。
- **使用量表示がより確実に**：Chromium 系ブラウザ（Chrome / Edge）で安定して動作し、古いデータで誤ってより低い値に表示が飛ぶことがなくなり、更新後もリセットのカウントダウンを保持し、データがないときはクリックで読み込める入口を表示します。
- **フォルダがより安定**：Gemini のサイドバーのスクロール（仮想化）でフォルダの割り当てが失われなくなり、フォルダ内の会話をクリックすると正しい会話が確実に開き、名前変更は Gemini 標準のダイアログを使って同期を保ち、高負荷時でもインポートが壊れなくなりました。
- **下書きが元の会話に紐づく**：未送信の下書きは入力した会話に残り、会話を切り替えても上書きされません。
- **オンボーディングツアーが誤って終了しない**：ツアー中にページをクリックしても終了せず、明示的に閉じるか Esc を押したときだけ終了します。
- **ハイライトはオプトインに**：ハイライトを使ったことがない場合は既定でオフになります（既存のハイライトはオンのまま、データも変わりません）。
- **パフォーマンスとその他**：機能の起動が速くなり長い会話でのメモリ使用が減少、ポップアップ設定がすぐにスクロール可能に、全画面 Mermaid が閉じるときにクリーンアップ、タイムラインのプレビューが視界に収まり、エクスポートが遅延読み込みのメッセージを正しく処理、プラグイン検証がリモートおよびスクリプトスキームの URL を遮断、マルチアカウント分離もより堅牢になりました。

<!-- lang:fr -->

> *« Tous ceux qui errent ne sont pas perdus. » — J. R. R. Tolkien, La Communauté de l'Anneau*

### Nouveautés

- **Safari gagne des fonctions macOS natives — et l'app devient Voyager**: la version Safari en téléchargement direct relie désormais sa WebExtension à la synchronisation native Google Drive et iCloud, ainsi qu'aux notifications macOS de fin de réponse qui ouvrent la bonne conversation. Après cette migration unique, les prochaines mises à jour arriveront via Sparkle. L'export d'images et la suppression de filigrane fonctionnent à nouveau, et les sauvegardes iCloud peuvent être supprimées depuis le popup sans toucher aux données locales. L'app hôte a été renommée de « Gemini Voyager » en « Voyager ». ⚠️ **Si vous mettez à jour, suivez une fois le guide de migration avant la mise à jour pour ne pas vous retrouver avec deux apps installées.**
- **Le mode de saisie Vim arrive sur Claude et ChatGPT**: la zone de message prend maintenant en charge l'édition clavier façon Vim au-delà de Gemini.
- **Blocs de code longs repliables**: les blocs de code trop longs peuvent être repliés d'un bouton pour ne plus envahir l'écran pendant le défilement.
- **Recherche par dossier uniquement**: tapez le préfixe \`f:\` (ou \`folder:\`) dans la recherche pour ne cibler que les noms de dossiers, avec un badge indiquant quand ce mode est actif.
- **Fichiers importés indiqués dans les exports**: l'export d'une conversation liste désormais par leur nom les fichiers non-images que vous avez joints, pour ne pas perdre ce contexte.
- **Affichage des notes de version au choix**: laissez Voyager ouvrir automatiquement les nouveautés après une mise à jour, ou afficher seulement un badge \`NEW\` jusqu'à ce que vous les ouvriez.

### Corrections

- **Suppression de filigrane plus intelligente et plus large**: prend en charge les derniers types de filigrane de Gemini et davantage de tailles de logo (y compris les petites images et les grandes images réduites), réussit sur davantage de cas limites, et ne s'exécute toujours que lorsqu'un filigrane est réellement détecté. Les pages Notebook (NotebookLM) ne sont plus perturbées, Safari télécharge à nouveau l'image sans filigrane en taille réelle, et les échecs se rabattent sur un téléchargement normal.
- **Indicateur d'utilisation plus fiable**: fonctionne de façon constante sur les navigateurs Chromium (Chrome / Edge), ne saute plus à une valeur plus basse erronée à cause de données périmées, conserve le compte à rebours de réinitialisation après un rafraîchissement et affiche un lien cliquable quand aucune donnée n'est présente.
- **Dossiers plus solides**: les affectations de dossier survivent au défilement de la barre latérale de Gemini (virtualisation), cliquer sur une conversation ouvre bien la bonne, le renommage utilise la boîte de dialogue native de Gemini et reste synchronisé, et les imports ne cassent plus en cas de contention.
- **Les brouillons restent avec leur conversation**: un brouillon non envoyé reste dans la conversation où vous l'avez saisi et n'est pas écrasé quand vous changez de discussion.
- **Le tour d'accueil ne se ferme plus par accident**: cliquer dans la page pendant le tour ne l'arrête plus — seule une fermeture explicite ou Échap le fait.
- **La surbrillance devient optionnelle**: si vous n'avez jamais utilisé la surbrillance, elle démarre désormais désactivée (les surbrillances existantes restent actives et vos données sont inchangées).
- **Performances et divers**: démarrage des fonctions plus rapide et mémoire réduite dans les longues conversations, les réglages du popup défilent immédiatement, Mermaid en plein écran se nettoie à la fermeture, l'aperçu de la timeline reste visible, l'export gère les messages chargés à la volée, la validation des plugins bloque les URL distantes et à schéma script, et l'isolation multi-comptes est plus robuste.

<!-- lang:es -->

> *«No todos los que vagan están perdidos.» — J. R. R. Tolkien, La Comunidad del Anillo*

### Novedades

- **Safari incorpora funciones nativas de macOS — y la app pasa a llamarse Voyager**: la versión de Safari por descarga directa conecta ahora su WebExtension con la sincronización nativa de Google Drive e iCloud y con notificaciones de macOS que, al terminar una respuesta, abren la conversación correcta. Tras completar esta migración una vez, las próximas versiones se actualizarán mediante Sparkle. La exportación de imágenes y la eliminación de marcas de agua vuelven a funcionar, y la copia de iCloud puede eliminarse desde el popup sin tocar los datos locales. La app anfitriona pasó de llamarse «Gemini Voyager» a «Voyager». ⚠️ **Si vas a actualizar, sigue una vez la guía de migración antes de actualizar para no acabar con dos apps instaladas.**
- **El modo de entrada Vim llega a Claude y ChatGPT**: el cuadro de mensaje ahora admite edición con teclado estilo Vim más allá de Gemini.
- **Bloques de código largos plegables**: los bloques de código demasiado largos pueden plegarse con un botón para que ya no llenen la pantalla al desplazarte.
- **Búsqueda solo por carpetas**: escribe el prefijo \`f:\` (o \`folder:\`) en la búsqueda para buscar solo nombres de carpetas, con una insignia que indica cuándo está activo ese modo.
- **Los archivos subidos se indican en las exportaciones**: al exportar una conversación ahora se listan por su nombre los archivos que no son imágenes que adjuntaste, para no perder ese contexto.
- **Elige cómo aparecen las notas de versión**: permite que Voyager abra automáticamente las novedades tras actualizar, o muestra solo una insignia \`NEW\` hasta que quieras verlas.

### Correcciones

- **Eliminación de marca de agua más inteligente y amplia**: admite las últimas variantes de marca de agua de Gemini y más tamaños de logo (incluidas imágenes pequeñas y grandes reducidas), tiene éxito en más casos límite y sigue ejecutándose solo cuando se detecta realmente una marca de agua. Las páginas de Notebook (NotebookLM) ya no se ven afectadas, Safari vuelve a descargar la imagen sin marca de agua a tamaño completo y los fallos recurren a una descarga normal.
- **Indicador de uso más fiable**: funciona de forma constante en navegadores Chromium (Chrome / Edge), ya no salta a un valor más bajo erróneo por datos obsoletos, conserva la cuenta atrás de reinicio tras recargar y muestra un enlace pulsable cuando no hay datos.
- **Carpetas más robustas**: las asignaciones de carpeta sobreviven al desplazamiento de la barra lateral de Gemini (virtualización), hacer clic en una conversación abre la correcta, el cambio de nombre usa el diálogo nativo de Gemini y se mantiene sincronizado, y las importaciones ya no fallan bajo contención.
- **Los borradores se quedan con su conversación**: un borrador sin enviar permanece en la conversación donde lo escribiste y no se sobrescribe al cambiar de chat.
- **El recorrido de bienvenida ya no se cierra por accidente**: hacer clic en la página durante el recorrido ya no lo termina; solo lo hace un cierre explícito o Escape.
- **El resaltado ahora es opcional**: si nunca usaste el resaltado, ahora empieza desactivado (los resaltados existentes siguen activos y tus datos no cambian).
- **Rendimiento y más**: inicio de funciones más rápido y menos memoria en conversaciones largas, los ajustes del popup se desplazan de inmediato, Mermaid en pantalla completa se limpia al cerrar, la vista previa de la línea de tiempo se mantiene visible, la exportación gestiona los mensajes cargados de forma diferida, la validación de plugins bloquea las URL remotas y de esquema de script, y el aislamiento entre cuentas es más robusto.

<!-- lang:pt -->

> *«Nem todos os que vagueiam estão perdidos.» — J. R. R. Tolkien, A Sociedade do Anel*

### Novidades

- **O Safari ganha recursos nativos do macOS — e o app passa a se chamar Voyager**: a versão do Safari por download direto agora conecta sua WebExtension à sincronização nativa do Google Drive e iCloud e às notificações do macOS que, ao concluir uma resposta, abrem a conversa correta. Depois desta migração única, as próximas versões serão atualizadas via Sparkle. A exportação de imagens e a remoção de marca d'água voltaram a funcionar, e o backup do iCloud pode ser excluído pelo popup sem alterar os dados locais. O app hospedeiro foi renomeado de "Gemini Voyager" para "Voyager". ⚠️ **Se você for atualizar, siga o guia de migração uma vez antes de atualizar para não ficar com dois apps instalados.**
- **O modo de entrada Vim chega ao Claude e ao ChatGPT**: a caixa de mensagem agora suporta edição por teclado no estilo Vim além do Gemini.
- **Blocos de código longos recolhíveis**: blocos de código muito longos podem ser recolhidos com um botão para não ocuparem a tela enquanto você rola.
- **Busca apenas por pastas**: digite o prefixo \`f:\` (ou \`folder:\`) na busca para procurar apenas nomes de pastas, com um selo indicando quando esse modo está ativo.
- **Arquivos enviados indicados nas exportações**: ao exportar uma conversa, os arquivos que não são imagens que você anexou agora são listados pelo nome, para não perder esse contexto.
- **Escolha como ver as notas da versão**: deixe o Voyager abrir automaticamente as novidades após atualizar ou mostrar apenas um selo \`NEW\` até você querer vê-las.

### Correções

- **Remoção de marca d'água mais inteligente e abrangente**: suporta as variantes mais recentes de marca d'água do Gemini e mais tamanhos de logo (incluindo imagens pequenas e grandes reduzidas), tem sucesso em mais casos limítrofes e continua sendo executada apenas quando uma marca d'água é realmente detectada. As páginas do Notebook (NotebookLM) não são mais afetadas, o Safari volta a baixar a imagem sem marca d'água em tamanho real, e as falhas recorrem a um download normal.
- **Indicador de uso mais confiável**: funciona de forma consistente em navegadores Chromium (Chrome / Edge), não pula mais para um valor menor errado por dados desatualizados, mantém a contagem regressiva de redefinição após atualizar e mostra um link clicável quando não há dados.
- **Pastas mais robustas**: as atribuições de pasta sobrevivem à rolagem da barra lateral do Gemini (virtualização), clicar em uma conversa abre a correta, a renomeação usa a caixa de diálogo nativa do Gemini e se mantém sincronizada, e as importações não quebram mais sob contenção.
- **Os rascunhos ficam com a sua conversa**: um rascunho não enviado permanece na conversa em que você o digitou e não é sobrescrito ao trocar de chat.
- **O tour de boas-vindas não sai mais por acidente**: clicar na página durante o tour não o encerra — apenas um fechamento explícito ou Esc encerra.
- **O destaque agora é opcional**: se você nunca usou o destaque, ele agora começa desativado (os destaques existentes continuam ativos e seus dados não mudam).
- **Desempenho e mais**: inicialização de recursos mais rápida e menos memória em conversas longas, as configurações do popup rolam imediatamente, o Mermaid em tela cheia se limpa ao fechar, a prévia da linha do tempo permanece visível, a exportação lida com mensagens carregadas sob demanda, a validação de plugins bloqueia URLs remotas e de esquema de script, e o isolamento entre contas é mais robusto.

<!-- lang:ar -->

> *«ليس كل من يهيم تائهًا.» — ج. ر. ر. تولكين، رفقة الخاتم*

### الجديد

- **Safari يكتسب قدرات macOS أصلية — وأُعيدت تسمية التطبيق إلى Voyager**: تربط نسخة Safari ذات التنزيل المباشر الآن WebExtension بالمزامنة الأصلية عبر Google Drive و iCloud، وبإشعارات macOS التي تفتح المحادثة الصحيحة عند اكتمال الرد. وبعد إتمام هذا النقل لمرة واحدة، ستصل التحديثات اللاحقة عبر Sparkle. عاد تصدير الصور وإزالة العلامة المائية إلى العمل، ويمكن حذف نسخة iCloud الاحتياطية من النافذة المنبثقة دون المساس بالبيانات المحلية. أُعيدت تسمية التطبيق المضيف من «Gemini Voyager» إلى «Voyager». ⚠️ **إذا كنت ستحدّث، فاتّبع دليل النقل مرة واحدة قبل التحديث حتى لا يتبقى لديك تطبيقان مثبَّتان.**
- **وضع إدخال Vim يصل إلى Claude و ChatGPT**: يدعم صندوق الرسالة الآن التحرير بأسلوب لوحة مفاتيح Vim خارج Gemini أيضًا.
- **طيّ كتل الشيفرة الطويلة**: يمكن طيّ كتل الشيفرة الطويلة جدًا بزر واحد حتى لا تملأ الشاشة أثناء التمرير.
- **بحث ضمن المجلدات فقط**: اكتب البادئة \`f:\` (أو \`folder:\`) في البحث للبحث في أسماء المجلدات فقط، مع شارة تشير إلى تفعيل هذا الوضع.
- **الإشارة إلى الملفات المرفوعة في التصدير**: عند تصدير محادثة تُدرَج الآن الملفات غير الصورية التي أرفقتها بأسمائها، حتى لا يضيع هذا السياق.
- **اختر طريقة عرض ملاحظات الإصدار**: دع Voyager يفتح الجديد تلقائيًا بعد التحديث، أو يعرض شارة \`NEW\` فقط إلى أن تختار فتحه.

### الإصلاحات

- **إزالة أذكى وأوسع للعلامة المائية**: تدعم أحدث أنواع العلامة المائية في Gemini والمزيد من أحجام الشعار (بما في ذلك الصور الصغيرة والكبيرة المصغّرة)، وتنجح في مزيد من الحالات الحدّية، ولا تُنفَّذ إلا عند اكتشاف علامة مائية فعليًا. لم تعد صفحات Notebook (NotebookLM) تتأثر، ويعيد Safari تنزيل الصورة الخالية من العلامة المائية بالحجم الكامل، وعند الفشل يجري الرجوع إلى تنزيل عادي.
- **مؤشر استخدام أكثر موثوقية**: يعمل بثبات على متصفحات Chromium‏ (Chrome / Edge)، ولم يعد يقفز إلى قيمة أقل خاطئة بسبب بيانات قديمة، ويحتفظ بالعدّ التنازلي لإعادة التعيين بعد التحديث، ويعرض رابطًا قابلًا للنقر عند غياب البيانات.
- **مجلدات أكثر متانة**: تبقى تعيينات المجلدات سليمة عند تمرير الشريط الجانبي في Gemini (المحاكاة الافتراضية)، والنقر على محادثة يفتح الصحيحة، وتستخدم إعادة التسمية مربع حوار Gemini الأصلي وتبقى متزامنة، ولم يعد الاستيراد ينكسر عند التزاحم.
- **المسودات تبقى مع محادثتها**: تبقى المسودة غير المرسَلة في المحادثة التي كتبتها فيها ولا يُكتب فوقها عند تبديل المحادثات.
- **جولة التعريف لم تعد تُغلق بالخطأ**: النقر داخل الصفحة أثناء الجولة لم يعد ينهيها — فقط الإغلاق الصريح أو Esc ينهيها.
- **التمييز أصبح اختياريًا**: إن لم تستخدم التمييز من قبل، فسيبدأ الآن معطَّلًا (تبقى تمييزاتك الحالية مفعَّلة وبياناتك دون تغيير).
- **الأداء وأمور أخرى**: بدء تشغيل أسرع للميزات واستهلاك ذاكرة أقل في المحادثات الطويلة، وإعدادات النافذة المنبثقة تُمرَّر فورًا، وتنظيف Mermaid في وضع ملء الشاشة عند الإغلاق، وبقاء معاينة الخط الزمني ضمن الرؤية، ومعالجة التصدير للرسائل المحمَّلة تدريجيًا، وحجب التحقق من الإضافات لعناوين URL البعيدة وعناوين مخطط السكربت، وعزل متعدد الحسابات أكثر متانة.

<!-- lang:ko -->

> *“방랑하는 이들이 모두 길을 잃은 것은 아니다.” — J. R. R. 톨킨, 《반지 원정대》*

### 새로운 기능

- **Safari에 macOS 네이티브 기능 추가 — 앱 이름도 Voyager로 변경**: 직접 다운로드하는 Safari 버전의 WebExtension이 네이티브 Google Drive 및 iCloud 동기화와, 응답 완료 후 올바른 대화를 여는 macOS 알림에 연결됩니다. 이번 일회성 마이그레이션을 마치면 이후 버전은 Sparkle로 자동 업데이트됩니다. 이미지 내보내기와 워터마크 제거도 다시 정상 동작하며, 로컬 데이터에 영향 없이 팝업에서 iCloud 백업을 삭제할 수 있습니다. 호스트 앱 이름이 「Gemini Voyager」에서 「Voyager」로 변경되었습니다. ⚠️ **업데이트하실 경우, 두 앱이 함께 남지 않도록 업데이트 전에 마이그레이션 안내를 한 번 따라 주세요.**
- **Vim 입력 모드가 Claude와 ChatGPT에도**: 메시지 입력창에서 Gemini 외에도 Vim 방식의 키보드 편집을 사용할 수 있습니다.
- **긴 코드 블록 접기**: 너무 긴 코드 블록을 버튼으로 접을 수 있어 스크롤 중 화면을 가득 채우지 않습니다.
- **폴더 전용 검색**: 검색창에 \`f:\`(또는 \`folder:\`) 접두사를 입력하면 폴더 이름만 검색하며, 해당 모드일 때 배지로 표시됩니다.
- **업로드한 파일을 내보내기에 표시**: 대화를 내보낼 때 첨부한 이미지가 아닌 파일이 이제 이름으로 나열되어 해당 맥락이 사라지지 않습니다.
- **릴리스 노트 표시 방식 선택**: 업데이트 후 Voyager가 새 기능을 자동으로 열게 하거나, 직접 열 때까지 \`NEW\` 배지만 표시하도록 선택할 수 있습니다.

### 수정

- **더 똑똑하고 폭넓은 워터마크 제거**: Gemini의 최신 워터마크 변형과 더 많은 로고 크기(작은 이미지와 축소된 큰 이미지 포함)를 지원하고, 더 많은 경계 사례에서 성공하며, 여전히 실제로 워터마크가 감지된 경우에만 실행됩니다. Notebook(NotebookLM) 페이지가 더 이상 방해받지 않고, Safari에서 다시 전체 크기의 워터마크 없는 이미지를 다운로드하며, 제거 실패 시 일반 다운로드로 대체됩니다.
- **더 안정적인 사용량 표시**: Chromium 브라우저(Chrome / Edge)에서 일관되게 동작하고, 오래된 데이터로 잘못된 더 낮은 값으로 튀지 않으며, 새로고침 후에도 초기화 카운트다운을 유지하고, 데이터가 없을 때 클릭 가능한 불러오기 링크를 표시합니다.
- **더 튼튼한 폴더**: Gemini 사이드바 스크롤(가상화) 후에도 폴더 지정이 유지되고, 폴더 안의 대화를 클릭하면 올바른 대화가 안정적으로 열리며, 이름 변경은 Gemini 기본 대화상자를 사용해 동기화를 유지하고, 경합 상황에서도 가져오기가 깨지지 않습니다.
- **초안이 해당 대화에 고정**: 보내지 않은 초안은 입력한 대화에 남고 대화를 전환해도 덮어써지지 않습니다.
- **온보딩 투어가 실수로 종료되지 않음**: 투어 중 페이지를 클릭해도 종료되지 않고, 명시적으로 닫거나 Esc를 눌러야 종료됩니다.
- **하이라이트가 선택적 기능으로 변경**: 하이라이트를 사용한 적이 없다면 이제 기본적으로 꺼진 상태로 시작합니다(기존 하이라이트는 켜진 상태로 유지되고 데이터는 변경되지 않습니다).
- **성능 및 기타**: 기능 시작이 빨라지고 긴 대화에서 메모리 사용이 줄었으며, 팝업 설정이 즉시 스크롤되고, 전체 화면 Mermaid가 닫을 때 정리되며, 타임라인 미리보기가 화면에 유지되고, 내보내기가 지연 로드된 메시지를 올바르게 처리하며, 플러그인 검증이 원격 및 스크립트 스킴 URL을 차단하고, 다중 계정 격리가 더 견고해졌습니다.

<!-- lang:ru -->

> *«Не все, кто странствует, сбились с пути.» — Дж. Р. Р. Толкин, «Братство Кольца»*

### Новое

- **Safari получает нативные возможности macOS — а приложение переименовано в Voyager**: версия Safari для прямой загрузки теперь связывает WebExtension с нативной синхронизацией Google Drive и iCloud и уведомлениями macOS, которые по завершении ответа открывают нужную беседу. После этой однократной миграции следующие версии будут обновляться через Sparkle. Экспорт изображений и удаление водяных знаков снова работают, а резервную копию iCloud можно удалить из всплывающего окна, не затрагивая локальные данные. Хост-приложение переименовано с «Gemini Voyager» на «Voyager». ⚠️ **Если вы обновляетесь, один раз выполните инструкцию по переносу перед обновлением, чтобы не осталось двух установленных приложений.**
- **Режим ввода Vim появился в Claude и ChatGPT**: поле сообщения теперь поддерживает редактирование в стиле Vim не только в Gemini.
- **Сворачиваемые длинные блоки кода**: слишком длинные блоки кода можно свернуть кнопкой, чтобы они не занимали весь экран при прокрутке.
- **Поиск только по папкам**: введите префикс \`f:\` (или \`folder:\`) в поиске, чтобы искать только по именам папок; значок показывает, когда этот режим активен.
- **Загруженные файлы отмечаются в экспорте**: при экспорте беседы прикреплённые вами файлы (кроме изображений) теперь перечисляются по имени, чтобы этот контекст не терялся.
- **Выберите способ показа заметок о выпуске**: Voyager может автоматически открывать список новинок после обновления или показывать только значок \`NEW\`, пока вы сами его не откроете.

### Исправления

- **Умнее и шире удаление водяных знаков**: поддерживает новейшие варианты водяных знаков Gemini и больше размеров логотипа (включая маленькие и уменьшённые большие изображения), срабатывает в большем числе пограничных случаев и по-прежнему выполняется только при реальном обнаружении водяного знака. Страницы Notebook (NotebookLM) больше не затрагиваются, Safari снова загружает изображение без водяного знака в полном размере, а при неудаче происходит откат к обычной загрузке.
- **Более надёжный индикатор использования**: стабильно работает в браузерах на Chromium (Chrome / Edge), больше не скачет к ошибочному меньшему значению из-за устаревших данных, сохраняет обратный отсчёт до сброса после обновления и показывает кликабельную ссылку загрузки, когда данных нет.
- **Более устойчивые папки**: назначения папок сохраняются при прокрутке боковой панели Gemini (виртуализация), клик по беседе открывает нужную, переименование использует нативный диалог Gemini и остаётся синхронным, а импорт больше не ломается при конкуренции.
- **Черновики остаются со своей беседой**: неотправленный черновик остаётся в той беседе, где вы его набрали, и не перезаписывается при переключении чатов.
- **Ознакомительный тур больше не закрывается случайно**: клик по странице во время тура больше не завершает его — только явное закрытие или Esc.
- **Подсветка теперь по желанию**: если вы никогда не пользовались подсветкой, теперь она стартует выключенной (существующие подсветки остаются включёнными, а данные не меняются).
- **Производительность и прочее**: более быстрый запуск функций и меньше памяти в длинных беседах, настройки во всплывающем окне прокручиваются сразу, полноэкранный Mermaid очищается при закрытии, предпросмотр таймлайна остаётся в поле зрения, экспорт корректно обрабатывает лениво загруженные сообщения, проверка плагинов блокирует удалённые и script-схемные URL, а изоляция нескольких аккаунтов стала надёжнее.
`;export{e as default};
