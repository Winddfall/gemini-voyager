const e=`<!-- lang:en -->

### Highlights

- Drag-and-drop reordering for folders and conversations — rearrange your sidebar freely.
- New changelog notification mode: choose between a popup or a "NEW" badge on the floating button. Switch modes directly from the changelog popup.
- Visual effects: sakura petal effect, cinematic rain effect, and smooth drain transitions when switching between effects.
- Width adjuster toggle: enable or disable CSS injection for chat width and sidebar width features.
- Extension renamed from "Gemini Voyager" to "Voyager".
- Fixed folder drag-and-drop bugs (conversation duplication, reorder index, Chrome split-screen trigger).
- Improved Google Drive Sync authentication flow handling.

<!-- lang:zh -->

### 亮点

- 文件夹和对话支持拖拽排序——自由调整侧边栏顺序。
- 新增更新提醒方式选择：可以选择弹窗提醒，或在悬浮球上显示 NEW 标记。可在更新日志弹窗中直接切换模式。
- 视觉效果：新增樱花飘落效果、电影感雨滴效果，切换效果时支持平滑过渡。
- 宽度调节开关：可选择是否注入聊天宽度和侧边栏宽度的 CSS。
- 扩展正式更名为 "Voyager"（原 "Gemini Voyager"）。
- 修复文件夹拖拽排序的多个 Bug（对话重复、排序索引、Chrome 分屏触发）。
- 改进 Google Drive 同步的认证流程处理。

<!-- lang:zh_TW -->

### 亮點

- 資料夾和對話支援拖曳排序——自由調整側邊欄順序。
- 新增更新提醒方式選擇：可以選擇彈窗提醒，或在懸浮球上顯示 NEW 標記。可在更新日誌彈窗中直接切換模式。
- 視覺效果：新增櫻花飄落效果、電影感雨滴效果，切換效果時支援平滑過渡。
- 寬度調節開關：可選擇是否注入聊天寬度和側邊欄寬度的 CSS。
- 擴充功能正式更名為「Voyager」（原「Gemini Voyager」）。
- 修復資料夾拖曳排序的多個 Bug（對話重複、排序索引、Chrome 分屏觸發）。
- 改進 Google Drive 同步的驗證流程處理。

<!-- lang:ja -->

### ハイライト

- フォルダと会話のドラッグ＆ドロップ並べ替え——サイドバーを自由に整理できます。
- 新しい更新通知モード：ポップアップまたはフローティングボタンの「NEW」バッジから選択可能。変更履歴ポップアップから直接モードを切り替えられます。
- ビジュアルエフェクト：桜の花びらエフェクト、シネマティックな雨エフェクト、エフェクト切り替え時のスムーズなトランジション。
- 幅調整トグル：チャット幅とサイドバー幅の CSS 注入を有効/無効に切り替え可能。
- 拡張機能の名称を「Gemini Voyager」から「Voyager」に変更。
- フォルダのドラッグ＆ドロップに関する複数のバグを修正（会話の重複、並べ替えインデックス、Chrome の分割画面トリガー）。
- Google Drive 同期の認証フロー処理を改善。

<!-- lang:fr -->

### Points forts

- Glisser-deposer pour reordonner les dossiers et les conversations — organisez votre barre laterale librement.
- Nouveau mode de notification des mises a jour : choisissez entre une fenetre contextuelle ou un badge "NEW" sur le bouton flottant. Changez de mode directement depuis la fenetre du changelog.
- Effets visuels : petales de sakura, effet de pluie cinematique et transitions fluides entre les effets.
- Bouton d'ajustement de largeur : activez ou desactivez l'injection CSS pour la largeur du chat et de la barre laterale.
- L'extension a ete renommee de "Gemini Voyager" en "Voyager".
- Correction de plusieurs bugs de glisser-deposer des dossiers (duplication de conversations, index de tri, declenchement d'ecran divise Chrome).
- Amelioration du flux d'authentification Google Drive Sync.

<!-- lang:es -->

### Destacados

- Reordenamiento por arrastrar y soltar para carpetas y conversaciones — organiza tu barra lateral libremente.
- Nuevo modo de notificacion de actualizaciones: elige entre una ventana emergente o una insignia "NEW" en el boton flotante. Cambia de modo directamente desde la ventana del registro de cambios.
- Efectos visuales: petalos de sakura, efecto de lluvia cinematica y transiciones suaves entre efectos.
- Interruptor de ajuste de ancho: activa o desactiva la inyeccion CSS para las funciones de ancho del chat y la barra lateral.
- La extension fue renombrada de "Gemini Voyager" a "Voyager".
- Correccion de varios errores de arrastrar y soltar en carpetas (duplicacion de conversaciones, indice de reorden, activacion de pantalla dividida en Chrome).
- Mejora del flujo de autenticacion de Google Drive Sync.

<!-- lang:pt -->

### Destaques

- Reordenacao por arrastar e soltar para pastas e conversas — organize sua barra lateral livremente.
- Novo modo de notificacao de atualizacoes: escolha entre um pop-up ou um selo "NEW" no botao flutuante. Alterne o modo diretamente na janela do changelog.
- Efeitos visuais: petalas de sakura, efeito de chuva cinematica e transicoes suaves entre efeitos.
- Botao de ajuste de largura: ative ou desative a injecao CSS para as funcoes de largura do chat e da barra lateral.
- A extensao foi renomeada de "Gemini Voyager" para "Voyager".
- Correcao de varios bugs de arrastar e soltar em pastas (duplicacao de conversas, indice de reordenacao, ativacao de tela dividida no Chrome).
- Melhoria no fluxo de autenticacao do Google Drive Sync.

<!-- lang:ar -->

### أبرز التحديثات

- إعادة ترتيب المجلدات والمحادثات بالسحب والإفلات — نظّم شريطك الجانبي بحرية.
- وضع إشعار تحديث جديد: اختر بين نافذة منبثقة أو شارة "NEW" على الزر العائم. يمكنك التبديل بين الأوضاع مباشرة من نافذة سجل التغييرات.
- تأثيرات بصرية: تأثير بتلات الساكورا، تأثير المطر السينمائي، وانتقالات سلسة بين التأثيرات.
- مفتاح تبديل ضبط العرض: تفعيل أو تعطيل حقن CSS لميزات عرض الدردشة والشريط الجانبي.
- تم تغيير اسم الإضافة من "Gemini Voyager" إلى "Voyager".
- إصلاح عدة أخطاء في السحب والإفلات للمجلدات (تكرار المحادثات، فهرس الترتيب، تشغيل الشاشة المقسمة في Chrome).
- تحسين معالجة تدفق المصادقة في مزامنة Google Drive.

<!-- lang:ru -->

### Основные изменения

- Перетаскивание для изменения порядка папок и бесед — организуйте боковую панель по своему усмотрению.
- Новый режим уведомлений об обновлениях: выберите между всплывающим окном или значком «NEW» на плавающей кнопке. Режим можно переключить прямо в окне списка изменений.
- Визуальные эффекты: лепестки сакуры, кинематографический эффект дождя и плавные переходы между эффектами.
- Переключатель настройки ширины: включение или отключение CSS-инъекции для функций ширины чата и боковой панели.
- Расширение переименовано из «Gemini Voyager» в «Voyager».
- Исправлено несколько ошибок перетаскивания папок (дублирование бесед, индекс сортировки, срабатывание разделённого экрана Chrome).
- Улучшена обработка потока аутентификации синхронизации Google Drive.

<!-- lang:ko -->

### 주요 변경사항

- 폴더와 대화의 드래그 앤 드롭 재정렬 — 사이드바를 자유롭게 정리하세요.
- 새로운 업데이트 알림 모드: 팝업 또는 플로팅 버튼의 "NEW" 배지 중 선택할 수 있습니다. 변경 로그 팝업에서 직접 모드를 전환할 수 있습니다.
- 시각 효과: 벚꽃잎 효과, 시네마틱 비 효과, 효과 전환 시 부드러운 트랜지션.
- 너비 조절 토글: 채팅 너비와 사이드바 너비 기능의 CSS 주입을 활성화/비활성화할 수 있습니다.
- 확장 프로그램 이름이 "Gemini Voyager"에서 "Voyager"로 변경되었습니다.
- 폴더 드래그 앤 드롭 관련 여러 버그 수정 (대화 중복, 재정렬 인덱스, Chrome 분할 화면 트리거).
- Google Drive 동기화 인증 흐름 처리 개선.
`;export{e as default};
