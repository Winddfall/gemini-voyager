const e=`<!-- lang:en -->

> 📢 **This update includes an important announcement — please take a moment to read the changelog.**

### 🔖 Name Change Notice

Due to trademark and copyright concerns, this extension has been officially renamed to **Voyager**. The Chrome Web Store review is still pending — if you can't find it under the new name, please search for the old name or install directly from GitHub.

### What's New

- **AI Folder Organization**: Automatically sort conversations into folders using AI. Supports paste-import from clipboard for bulk operations.
- **Safari DMG Link**: Safari popup now surfaces a direct DMG download link extracted from GitHub Releases.
- **UI Refresh**: Refined color system with neutral cool grays and a green accent; unified folder panel design throughout.

### Bug Fixes

- Fixed default model selector breaking after Gemini updated its menu structure (new \`role="menuitem"\` variant).
- Fixed Fork button not opening on Firefox and Safari due to popup blockers.
- Fixed Fork button vertical misalignment with native action buttons.
- Fixed folder import dialog: light mode color rendering and menu icon alignment.
- Fixed drag-and-drop onto conversations inside folders not applying correctly.
- Fixed AI Studio history titles being stripped when dragging into a folder.
- Fixed chat width input-container gradient not expanding to match custom chat width.

### A note from the developer

Hi there — just a quick word from me. I'm a grad student, and Voyager is a free, open-source side project I maintain in my spare time. Occasionally, Google updates Gemini's UI without notice, which can temporarily break things on our end. Similarly, features like watermark removal depend on your local network environment and may not work for everyone. If something isn't working, I'd really appreciate it if you could open a GitHub issue first — I read every single one. Jumping straight to a 1-star review doesn't help me fix the problem, and honestly, it stings a little. Thanks for your patience and understanding. :)

<!-- lang:zh -->

> 📢 **本次更新包含重要公告，建议阅读本次 Changelog。**

### 🔖 改名公告

由于商标版权问题，本插件已正式改名为 **Voyager**。Chrome 商店审核仍在进行中——如果通过新名称找不到，请搜索旧名称或直接从 GitHub 安装。

### 新功能

- **AI 智能文件夹整理**：使用 AI 自动将对话分类到文件夹，支持从剪贴板粘贴批量导入。
- **Safari DMG 直链**：Safari 弹窗现在直接显示从 GitHub Releases 提取的 DMG 下载链接。
- **UI 焕新**：采用中性冷灰 + 绿色强调色的新配色系统，文件夹面板设计统一。

### Bug 修复

- 修复 Gemini 更新菜单结构后（新 \`role="menuitem"\` 变体）默认模型选择器失效的问题。
- 修复 Firefox 和 Safari 上因弹窗拦截导致 Fork 按钮无法打开的问题。
- 修复 Fork 按钮与原生操作按钮的垂直对齐偏移。
- 修复文件夹导入对话框浅色模式配色错误和菜单图标对齐问题。
- 修复拖拽对话到文件夹内的对话上不生效的问题。
- 修复将 AI Studio 历史记录拖入文件夹时标题丢失的问题。
- 修复聊天宽度调整后输入框渐变未随自定义宽度扩展的问题。

### 开发者碎碎念

大家好，我是一名在读研究生，Voyager 是我课余时间维护的免费开源项目。Google 偶尔会悄悄改动 Gemini 的界面，导致插件的部分功能临时出问题——这不是 bug，是"被动挨打"。去水印等功能也依赖你的本地网络环境，不一定对所有人都有效。遇到问题的话，麻烦先到 GitHub 提个 issue，我每条都会看。上来就甩一星差评，问题修不了，开发者的心倒是碎了。感谢理解 :)

<!-- lang:zh_TW -->

> 📢 **本次更新包含重要公告，建議閱讀本次 Changelog。**

### 🔖 改名公告

由於商標版權問題，本外掛已正式改名為 **Voyager**。Chrome 商店審核仍在進行中——如果透過新名稱找不到，請搜尋舊名稱或直接從 GitHub 安裝。

### 新功能

- **AI 智慧資料夾整理**：使用 AI 自動將對話分類到資料夾，支援從剪貼簿貼上批次匯入。
- **Safari DMG 直連**：Safari 彈窗現在直接顯示從 GitHub Releases 提取的 DMG 下載連結。
- **UI 煥新**：採用中性冷灰 + 綠色強調色的新配色系統，資料夾面板設計統一。

### Bug 修復

- 修復 Gemini 更新選單結構後（新 \`role="menuitem"\` 變體）預設模型選擇器失效的問題。
- 修復 Firefox 和 Safari 上因彈出式視窗攔截導致 Fork 按鈕無法開啟的問題。
- 修復 Fork 按鈕與原生操作按鈕的垂直對齊偏移。
- 修復資料夾匯入對話框淺色模式配色錯誤和選單圖示對齊問題。
- 修復拖曳對話到資料夾內的對話上不生效的問題。
- 修復將 AI Studio 歷史紀錄拖入資料夾時標題遺失的問題。
- 修復聊天寬度調整後輸入框漸層未隨自訂寬度擴展的問題。

### 開發者碎碎念

大家好，我是一名在讀研究生，Voyager 是我課餘時間維護的免費開源專案。Google 偶爾會悄悄改動 Gemini 的介面，導致外掛的部分功能暫時出問題——這不是 bug，是「被動挨打」。去浮水印等功能也依賴你的本地網路環境，不一定對所有人都有效。遇到問題的話，麻煩先到 GitHub 提個 issue，我每條都會看。上來就甩一星負評，問題修不了，開發者的心倒是碎了。感謝理解 :)

<!-- lang:ja -->

> 📢 **本アップデートには重要なお知らせが含まれています。Changelog をご一読ください。**

### 🔖 名称変更のお知らせ

商標・著作権の問題により、本拡張機能は正式に **Voyager** へと名称変更されました。Chrome ウェブストアの審査はまだ進行中です。新しい名前で見つからない場合は、旧名称で検索するか、GitHub から直接インストールしてください。

### 新機能

- **AI フォルダ整理**：AI を使って会話を自動的にフォルダに分類。クリップボードからの一括貼り付けインポートにも対応。
- **Safari DMG リンク**：Safari ポップアップに GitHub Releases から抽出した DMG ダウンロードリンクを直接表示。
- **UI リフレッシュ**：ニュートラルなクールグレーとグリーンアクセントの新配色システム、統一されたフォルダパネルデザイン。

### バグ修正

- Gemini がメニュー構造を更新後（新 \`role="menuitem"\` バリアント）、デフォルトモデルセレクターが機能しない問題を修正。
- Firefox と Safari でポップアップブロッカーにより Fork ボタンが開けない問題を修正。
- Fork ボタンのネイティブアクションボタンとの垂直方向のズレを修正。
- フォルダインポートダイアログのライトモードカラーとメニューアイコンの配置を修正。
- フォルダ内の会話へのドラッグ＆ドロップが正しく適用されない問題を修正。
- AI Studio の履歴タイトルがフォルダにドラッグした際に失われる問題を修正。
- チャット幅の入力コンテナグラデーションがカスタム幅に合わせて拡張されない問題を修正。

### 開発者よりひとこと

こんにちは。私は大学院生で、Voyager は空き時間にメンテナンスしている無料のオープンソースプロジェクトです。Google が Gemini の UI を予告なく変更することがあり、一時的に機能が壊れることがあります。また、透かし除去などの機能はお使いのネットワーク環境に依存するため、すべての方に有効とは限りません。問題が発生した場合は、まず GitHub で issue を開いていただけると助かります——すべて目を通しています。いきなり星1のレビューをされても問題は解決しませんし、正直ちょっと凹みます。ご理解いただけると嬉しいです :)

<!-- lang:fr -->

> 📢 **Cette mise à jour contient une annonce importante — veuillez prendre un moment pour lire le changelog.**

### 🔖 Avis de changement de nom

En raison de problemes de marque et de droits d'auteur, cette extension a ete officiellement renommee **Voyager**. La validation sur le Chrome Web Store est toujours en cours — si vous ne la trouvez pas sous le nouveau nom, recherchez l'ancien nom ou installez-la directement depuis GitHub.

### Nouveautes

- **Organisation des dossiers par IA** : Triez automatiquement les conversations dans des dossiers grace a l'IA. Supporte l'import en lot par collage depuis le presse-papiers.
- **Lien DMG Safari** : Le popup Safari affiche maintenant un lien de telechargement DMG direct extrait des GitHub Releases.
- **Interface rafraichie** : Nouveau systeme de couleurs avec des gris froids neutres et un accent vert, design unifie du panneau de dossiers.

### Corrections de bugs

- Correction du selecteur de modele par defaut qui ne fonctionnait plus apres la mise a jour de la structure de menu de Gemini (nouvelle variante \`role="menuitem"\`).
- Correction du bouton Fork qui ne s'ouvrait pas sur Firefox et Safari a cause des bloqueurs de pop-ups.
- Correction du desalignement vertical du bouton Fork avec les boutons d'action natifs.
- Correction des couleurs du mode clair et de l'alignement de l'icone du menu dans la boite de dialogue d'import de dossiers.
- Correction du glisser-deposer sur les conversations a l'interieur des dossiers qui ne fonctionnait pas correctement.
- Correction de la perte des titres d'historique AI Studio lors du glissement dans les dossiers.
- Correction du degrade du conteneur de saisie qui ne s'etendait pas pour correspondre a la largeur de chat personnalisee.

### Un mot du developpeur

Bonjour — petit message de ma part. Je suis etudiant en master et Voyager est un projet open source gratuit que je maintiens sur mon temps libre. Google modifie parfois l'interface de Gemini sans prevenir, ce qui peut temporairement casser certaines fonctionnalites. De meme, des fonctions comme la suppression du filigrane dependent de votre environnement reseau et peuvent ne pas fonctionner pour tout le monde. Si quelque chose ne marche pas, je vous serais reconnaissant d'ouvrir d'abord une issue sur GitHub — je les lis toutes. Mettre directement un avis 1 etoile ne m'aide pas a resoudre le probleme, et franchement, ca fait un peu mal. Merci pour votre patience et votre comprehension :)

<!-- lang:es -->

> 📢 **Esta actualización incluye un anuncio importante — por favor, tómate un momento para leer el changelog.**

### 🔖 Aviso de cambio de nombre

Debido a problemas de marcas registradas y derechos de autor, esta extension ha sido renombrada oficialmente a **Voyager**. La revision en Chrome Web Store aun esta pendiente — si no la encuentras con el nuevo nombre, busca el nombre anterior o instalala directamente desde GitHub.

### Novedades

- **Organizacion de carpetas con IA**: Ordena automaticamente las conversaciones en carpetas usando IA. Admite importacion masiva por pegado desde el portapapeles.
- **Enlace DMG de Safari**: El popup de Safari ahora muestra un enlace directo de descarga DMG extraido de GitHub Releases.
- **Interfaz renovada**: Nuevo sistema de colores con grises frios neutros y acento verde, diseno unificado del panel de carpetas.

### Correcciones de errores

- Corregido el selector de modelo predeterminado que no funcionaba tras la actualizacion de la estructura de menu de Gemini (nueva variante \`role="menuitem"\`).
- Corregido el boton Fork que no se abria en Firefox y Safari debido a bloqueadores de ventanas emergentes.
- Corregido el desalineamiento vertical del boton Fork con los botones de accion nativos.
- Corregidos los colores del modo claro y la alineacion del icono del menu en el dialogo de importacion de carpetas.
- Corregido el arrastrar y soltar sobre conversaciones dentro de carpetas que no se aplicaba correctamente.
- Corregida la perdida de titulos del historial de AI Studio al arrastrar a carpetas.
- Corregido el degradado del contenedor de entrada que no se extendia para coincidir con el ancho de chat personalizado.

### Una nota del desarrollador

Hola — un mensaje rapido de mi parte. Soy estudiante de posgrado y Voyager es un proyecto de codigo abierto y gratuito que mantengo en mi tiempo libre. A veces Google actualiza la interfaz de Gemini sin previo aviso, lo que puede romper temporalmente algunas funciones. Del mismo modo, funciones como la eliminacion de marcas de agua dependen de tu entorno de red y pueden no funcionar para todos. Si algo no funciona, te agradeceria mucho que primero abrieras un issue en GitHub — leo todos y cada uno. Ir directamente a dejar una resena de 1 estrella no me ayuda a solucionar el problema, y sinceramente, duele un poco. Gracias por tu paciencia y comprension :)

<!-- lang:pt -->

> 📢 **Esta atualização contém um anúncio importante — por favor, reserve um momento para ler o changelog.**

### 🔖 Aviso de mudanca de nome

Devido a problemas de marca registrada e direitos autorais, esta extensao foi oficialmente renomeada para **Voyager**. A revisao na Chrome Web Store ainda esta pendente — se nao encontra-la pelo novo nome, pesquise pelo nome antigo ou instale diretamente do GitHub.

### Novidades

- **Organizacao de pastas com IA**: Organize automaticamente as conversas em pastas usando IA. Suporta importacao em lote por colagem a partir da area de transferencia.
- **Link DMG no Safari**: O popup do Safari agora exibe um link direto para download do DMG extraido do GitHub Releases.
- **Interface renovada**: Novo sistema de cores com cinzas frios neutros e destaque verde, design unificado do painel de pastas.

### Correcoes de bugs

- Corrigido o seletor de modelo padrao que nao funcionava apos o Gemini atualizar a estrutura do menu (nova variante \`role="menuitem"\`).
- Corrigido o botao Fork que nao abria no Firefox e Safari devido a bloqueadores de pop-ups.
- Corrigido o desalinhamento vertical do botao Fork com os botoes de acao nativos.
- Corrigidas as cores do modo claro e o alinhamento do icone do menu no dialogo de importacao de pastas.
- Corrigido o arrastar e soltar em conversas dentro de pastas que nao se aplicava corretamente.
- Corrigida a perda de titulos do historico do AI Studio ao arrastar para pastas.
- Corrigido o gradiente do contentor de entrada que nao se estendia para corresponder a largura de chat personalizada.

### Uma nota do desenvolvedor

Ola — uma palavrinha rapida. Sou estudante de pos-graduacao e o Voyager e um projeto de codigo aberto e gratuito que mantenho no meu tempo livre. As vezes o Google atualiza a interface do Gemini sem aviso, o que pode temporariamente quebrar algumas funcoes. Da mesma forma, funcoes como a remocao de marca d'agua dependem do seu ambiente de rede e podem nao funcionar para todos. Se algo nao estiver funcionando, agradeco muito se voce puder abrir uma issue no GitHub primeiro — eu leio todas. Ir direto para uma avaliacao de 1 estrela nao me ajuda a resolver o problema, e sinceramente, doi um pouco. Obrigado pela paciencia e compreensao :)

<!-- lang:ar -->

> 📢 **يتضمن هذا التحديث إعلاناً مهماً — يُرجى أخذ لحظة لقراءة Changelog.**

### 🔖 إشعار تغيير الاسم

بسبب مخاوف تتعلق بالعلامات التجارية وحقوق النشر، تم تغيير اسم هذا الامتداد رسمياً إلى **Voyager**. مراجعة متجر Chrome لا تزال جارية — إذا لم تتمكن من إيجاده باسمه الجديد، فابحث بالاسم القديم أو ثبّته مباشرة من GitHub.

### الجديد

- **تنظيم المجلدات بالذكاء الاصطناعي**: ترتيب المحادثات تلقائياً في مجلدات بالذكاء الاصطناعي. يدعم الاستيراد الجماعي بالصق من الحافظة.
- **رابط DMG في Safari**: نافذة Safari المنبثقة تعرض الآن رابط تحميل DMG مباشر مستخرج من GitHub Releases.
- **واجهة محدثة**: نظام ألوان جديد برمادي بارد محايد ولون أخضر مميز، تصميم موحد لوحة المجلدات.

### إصلاحات الأخطاء

- إصلاح محدد النموذج الافتراضي الذي توقف عن العمل بعد تحديث بنية قائمة Gemini (متغير \`role="menuitem"\` الجديد).
- إصلاح زر Fork الذي لم يفتح في Firefox وSafari بسبب حاصرات النوافذ المنبثقة.
- إصلاح عدم توافق المحاذاة العمودية لزر Fork مع أزرار الإجراءات الأصلية.
- إصلاح ألوان الوضع الفاتح ومحاذاة أيقونة القائمة في مربع حوار استيراد المجلدات.
- إصلاح السحب والإفلات على المحادثات داخل المجلدات الذي لم يُطبَّق بشكل صحيح.
- إصلاح فقدان عناوين سجل AI Studio عند السحب إلى المجلدات.
- إصلاح تدرج حاوية الإدخال الذي لم يمتد ليتوافق مع عرض الدردشة المخصص.

### كلمة من المطور

مرحباً — كلمة سريعة مني. أنا طالب دراسات عليا، و Voyager مشروع مفتوح المصدر ومجاني أطوره في وقت فراغي. أحياناً تقوم Google بتحديث واجهة Gemini دون إشعار مسبق، مما قد يتسبب في تعطل بعض الميزات مؤقتاً. كذلك، ميزات مثل إزالة العلامة المائية تعتمد على بيئة شبكتك المحلية وقد لا تعمل مع الجميع. إذا واجهت مشكلة، أرجو أن تفتح issue على GitHub أولاً — أقرأ كل واحدة منها. القفز مباشرة إلى تقييم نجمة واحدة لا يساعدني في حل المشكلة، وبصراحة، يؤلم قليلاً. شكراً لصبركم وتفهمكم :)

<!-- lang:ru -->

> 📢 **Это обновление содержит важное объявление — пожалуйста, уделите минуту и прочитайте changelog.**

### 🔖 Уведомление о смене названия

В связи с вопросами товарных знаков и авторских прав расширение было официально переименовано в **Voyager**. Проверка в Chrome Web Store ещё не завершена — если не можете найти его под новым названием, ищите по старому или устанавливайте напрямую с GitHub.

### Что нового

- **AI-организация папок**: Автоматическая сортировка бесед по папкам с помощью ИИ. Поддерживается массовый импорт через вставку из буфера обмена.
- **Ссылка DMG в Safari**: Всплывающее окно Safari теперь отображает прямую ссылку для скачивания DMG из GitHub Releases.
- **Обновлённый интерфейс**: Новая цветовая схема с нейтральными холодными серыми тонами и зелёным акцентом, унифицированный дизайн панели папок.

### Исправление ошибок

- Исправлен селектор модели по умолчанию, который не работал после обновления структуры меню Gemini (новый вариант \`role="menuitem"\`).
- Исправлена кнопка Fork, которая не открывалась в Firefox и Safari из-за блокировщиков всплывающих окон.
- Исправлено вертикальное смещение кнопки Fork относительно нативных кнопок действий.
- Исправлены цвета светлого режима и выравнивание иконки меню в диалоге импорта папок.
- Исправлено перетаскивание на беседы внутри папок, которое не применялось корректно.
- Исправлена потеря заголовков истории AI Studio при перетаскивании в папки.
- Исправлен градиент контейнера ввода, который не расширялся в соответствии с пользовательской шириной чата.

### Слово от разработчика

Привет — пара слов от меня. Я аспирант, и Voyager — это бесплатный open-source проект, который я поддерживаю в свободное время. Иногда Google обновляет интерфейс Gemini без предупреждения, что может временно ломать некоторые функции. Также функции вроде удаления водяных знаков зависят от вашей сетевой среды и могут работать не у всех. Если что-то не работает, пожалуйста, сначала откройте issue на GitHub — я читаю каждый. Ставить сразу 1 звезду в отзывах не помогает мне исправить проблему, и, честно говоря, немного обидно. Спасибо за терпение и понимание :)

<!-- lang:ko -->

> 📢 **이번 업데이트에는 중요한 공지가 포함되어 있습니다 — 잠시 시간을 내어 changelog를 읽어주세요.**

### 🔖 이름 변경 공지

상표 및 저작권 문제로 인해 이 확장 프로그램은 공식적으로 **Voyager**로 이름이 변경되었습니다. Chrome 웹 스토어 검토가 아직 진행 중입니다 — 새 이름으로 찾을 수 없는 경우 이전 이름으로 검색하거나 GitHub에서 직접 설치해 주세요.

### 새로운 기능

- **AI 폴더 정리**: AI를 사용하여 대화를 자동으로 폴더에 분류. 클립보드에서 붙여넣기로 일괄 가져오기 지원.
- **Safari DMG 링크**: Safari 팝업에서 GitHub Releases에서 추출한 DMG 직접 다운로드 링크 표시.
- **UI 새단장**: 중립적인 쿨 그레이와 그린 액센트의 새로운 색상 시스템, 통합된 폴더 패널 디자인.

### 버그 수정

- Gemini가 메뉴 구조를 업데이트한 후(새 \`role="menuitem"\` 변형) 기본 모델 선택기가 작동하지 않는 문제 수정.
- Firefox 및 Safari에서 팝업 차단기로 인해 Fork 버튼이 열리지 않는 문제 수정.
- Fork 버튼과 기본 작업 버튼의 수직 정렬 불일치 수정.
- 폴더 가져오기 대화상자의 라이트 모드 색상 및 메뉴 아이콘 정렬 수정.
- 폴더 내 대화에 드래그 앤 드롭이 올바르게 적용되지 않는 문제 수정.
- AI Studio 기록 제목이 폴더로 드래그할 때 손실되는 문제 수정.
- 채팅 너비에 맞게 입력 컨테이너 그라데이션이 확장되지 않는 문제 수정.

### 개발자의 한마디

안녕하세요 — 잠깐 한마디 드립니다. 저는 대학원생이고, Voyager는 여가 시간에 유지하는 무료 오픈소스 프로젝트입니다. Google이 예고 없이 Gemini UI를 변경하면 일부 기능이 일시적으로 작동하지 않을 수 있습니다. 또한 워터마크 제거 같은 기능은 사용자의 네트워크 환경에 따라 달라질 수 있어 모든 분께 동작하지 않을 수 있습니다. 문제가 발생하면 먼저 GitHub에서 issue를 열어주시면 감사하겠습니다 — 모두 읽고 있습니다. 바로 별 1개 리뷰를 남기시면 문제 해결에 도움이 되지 않고, 솔직히 마음이 좀 아픕니다. 이해해 주셔서 감사합니다 :)
`;export{e as default};
