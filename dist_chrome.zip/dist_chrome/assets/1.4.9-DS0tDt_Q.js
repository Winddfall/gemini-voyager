const e=`<!-- lang:en -->

### What's New

- **Recently used gems first**: The sidebar gems list now ranks gems by how recently you used them — and premade Google gems appear too, no visit to the gems manager required.
- **Instant tab-title sync toggle**: Turning tab title sync on or off now takes effect immediately, no page reload needed.

### Fixes

- **Sidebar collapse button clickable again**: With a custom sidebar width, an invisible strip of Gemini's top bar swallowed clicks on the sidebar's collapse button, leaving only its edges clickable — it now works across its full area.
- **Watermark removal on slow networks**: Download detection now waits up to 60 seconds instead of 10, so slower connections no longer make watermark removal silently fail.
- **Folder picker no longer clipped**: Gemini's input box started cropping the upward-opening folder picker to a thin sliver — it now shows in full.
- **Folder panel survives window resizes**: Crossing Gemini's mobile breakpoint could remove the folder panel until a full reload; it now restores itself automatically within about a second.
- **Open folder chats in a new tab**: Conversations inside folders now support native new-tab opening (Ctrl/Cmd-click or middle-click).
- **1.4.8 release-notes links**: Repaired the documentation links in the previous release notes that pointed to missing pages.

<!-- lang:zh -->

### 新功能

- **Gem 按最近使用排序**：侧边栏 Gem 列表现在按你最近使用的顺序排列——预置的 Google Gem 也会出现，无需先访问 Gem 管理页。
- **标签页标题同步即时生效**：开关标签页标题同步后立即生效，无需刷新页面。

### 修复

- **侧边栏收起按钮恢复可点击**：自定义侧边栏宽度后，Gemini 顶栏的一条不可见横带会吞掉收起按钮中间区域的点击，只剩上下边缘能点——现在整个按钮都能正常点击。
- **慢速网络下的去水印**：下载检测的等待时间从 10 秒延长到 60 秒，网络较慢时去水印不会再悄悄失效。
- **文件夹选择器不再被裁剪**：Gemini 输入框开始裁切向上展开的文件夹选择器，只剩底部一条缝——现在可以完整显示。
- **窗口缩放后文件夹面板自动恢复**：窗口宽度跨过 Gemini 移动端断点时，文件夹面板可能消失且需刷新才能恢复；现在约一秒内自动恢复。
- **文件夹内对话支持新标签页打开**：文件夹内的对话现在支持原生的新标签页打开方式（Ctrl/Cmd + 点击或中键点击）。
- **1.4.8 更新说明链接**：修复了上一版更新说明中指向缺失页面的文档链接。

<!-- lang:zh_TW -->

### 新功能

- **Gem 依最近使用排序**：側邊欄 Gem 清單現在按你最近使用的順序排列——預置的 Google Gem 也會出現，無需先造訪 Gem 管理頁。
- **分頁標題同步即時生效**：開關分頁標題同步後立即生效，無需重新整理頁面。

### 修復

- **側邊欄收合按鈕恢復可點擊**：自訂側邊欄寬度後，Gemini 頂欄的一條不可見橫帶會吞掉收合按鈕中間區域的點擊，只剩上下邊緣能點——現在整顆按鈕都能正常點擊。
- **慢速網路下的去浮水印**：下載偵測的等待時間從 10 秒延長到 60 秒，網路較慢時去浮水印不會再悄悄失效。
- **資料夾選擇器不再被裁切**：Gemini 輸入框開始裁切向上展開的資料夾選擇器，只剩底部一條縫——現在可以完整顯示。
- **視窗縮放後資料夾面板自動恢復**：視窗寬度跨過 Gemini 行動版斷點時，資料夾面板可能消失且需重新整理才能恢復；現在約一秒內自動恢復。
- **資料夾內對話支援新分頁開啟**：資料夾內的對話現在支援原生的新分頁開啟方式（Ctrl/Cmd + 點擊或中鍵點擊）。
- **1.4.8 更新說明連結**：修復了上一版更新說明中指向遺失頁面的文件連結。

<!-- lang:ja -->

### 新機能

- **Gem を最近使った順に表示**：サイドバーの Gem リストが最近使った順に並ぶようになりました。プリメイドの Google Gem も表示され、Gem 管理ページを開く必要はありません。
- **タブタイトル同期の即時反映**：タブタイトル同期のオン／オフが、ページを再読み込みせずに即座に反映されるようになりました。

### 修正

- **サイドバー折りたたみボタンが再びクリック可能に**：サイドバー幅をカスタムすると、Gemini トップバーの不可視の帯が折りたたみボタン中央のクリックを奪い、上下の端しか押せませんでした。ボタン全体がクリックできるようになりました。
- **低速ネットワークでのウォーターマーク除去**：ダウンロード検出の待ち時間を 10 秒から 60 秒に延長し、回線が遅くてもウォーターマーク除去が静かに失敗しなくなりました。
- **フォルダピッカーの見切れを解消**：Gemini の入力欄が上向きに開くフォルダピッカーを細い帯まで切り詰めるようになっていましたが、全体が表示されるようになりました。
- **ウィンドウリサイズ後のフォルダパネル復元**：ウィンドウ幅が Gemini のモバイルブレークポイントをまたぐとフォルダパネルが消え、再読み込みが必要でしたが、約 1 秒で自動復元されるようになりました。
- **フォルダ内チャットを新しいタブで開く**：フォルダ内の会話が、ネイティブの新規タブ操作（Ctrl/Cmd+クリック、ミドルクリック）に対応しました。
- **1.4.8 リリースノートのリンク**：前回のリリースノートで存在しないページを指していたドキュメントリンクを修正しました。

<!-- lang:fr -->

### Nouveautés

- **Gems triés par utilisation récente** : La liste des gems de la barre latérale est désormais classée selon vos utilisations récentes — les gems préconçus de Google y figurent aussi, sans passer par le gestionnaire de gems.
- **Synchronisation du titre d'onglet instantanée** : Activer ou désactiver la synchronisation du titre d'onglet prend effet immédiatement, sans recharger la page.

### Corrections

- **Bouton de repli de la barre latérale à nouveau cliquable** : Avec une largeur de barre latérale personnalisée, une bande invisible de la barre supérieure de Gemini avalait les clics sur le bouton de repli, ne laissant que ses bords cliquables — il fonctionne désormais sur toute sa surface.
- **Suppression du filigrane sur réseaux lents** : La détection du téléchargement attend désormais jusqu'à 60 secondes au lieu de 10, pour que les connexions lentes ne fassent plus échouer silencieusement la suppression du filigrane.
- **Sélecteur de dossier plus tronqué** : Le champ de saisie de Gemini s'était mis à rogner le sélecteur de dossier s'ouvrant vers le haut jusqu'à une fine bande — il s'affiche désormais en entier.
- **Panneau de dossiers conservé au redimensionnement** : Franchir le point de rupture mobile de Gemini pouvait faire disparaître le panneau de dossiers jusqu'au rechargement ; il se restaure désormais automatiquement en une seconde environ.
- **Ouvrir les conversations d'un dossier dans un nouvel onglet** : Les conversations des dossiers prennent désormais en charge l'ouverture native dans un nouvel onglet (Ctrl/Cmd-clic ou clic molette).
- **Liens des notes de version 1.4.8** : Réparation des liens de documentation des notes précédentes qui pointaient vers des pages manquantes.

<!-- lang:es -->

### Novedades

- **Gems ordenadas por uso reciente**: La lista de gems de la barra lateral ahora se ordena según tu uso más reciente — y las gems predefinidas de Google también aparecen, sin pasar por el gestor de gems.
- **Sincronización del título de pestaña al instante**: Activar o desactivar la sincronización del título de pestaña surte efecto inmediatamente, sin recargar la página.

### Correcciones

- **Botón de plegado de la barra lateral clicable de nuevo**: Con un ancho de barra lateral personalizado, una franja invisible de la barra superior de Gemini se tragaba los clics sobre el botón de plegado, dejando solo sus bordes clicables — ahora funciona en toda su superficie.
- **Eliminación de marca de agua en redes lentas**: La detección de descarga espera ahora hasta 60 segundos en lugar de 10, así las conexiones lentas ya no hacen fallar en silencio la eliminación de la marca de agua.
- **Selector de carpetas sin recortar**: El campo de entrada de Gemini empezó a recortar el selector de carpetas que se abre hacia arriba hasta dejar una franja — ahora se muestra completo.
- **El panel de carpetas sobrevive al redimensionar**: Cruzar el punto de quiebre móvil de Gemini podía eliminar el panel de carpetas hasta recargar; ahora se restaura automáticamente en aproximadamente un segundo.
- **Abrir conversaciones de carpeta en pestaña nueva**: Las conversaciones dentro de carpetas admiten ahora la apertura nativa en una pestaña nueva (Ctrl/Cmd-clic o clic con la rueda).
- **Enlaces de las notas de la 1.4.8**: Reparados los enlaces de documentación de las notas anteriores que apuntaban a páginas inexistentes.

<!-- lang:pt -->

### Novidades

- **Gems ordenadas por uso recente**: A lista de gems da barra lateral agora é ordenada pelo seu uso mais recente — e as gems predefinidas do Google também aparecem, sem precisar visitar o gestor de gems.
- **Sincronização do título do separador imediata**: Ligar ou desligar a sincronização do título do separador passa a ter efeito imediato, sem recarregar a página.

### Correções

- **Botão de recolher a barra lateral clicável de novo**: Com uma largura de barra lateral personalizada, uma faixa invisível da barra superior do Gemini engolia os cliques no botão de recolher, deixando apenas as bordas clicáveis — agora funciona em toda a sua área.
- **Remoção de marca d'água em redes lentas**: A deteção de download espera agora até 60 segundos em vez de 10, para que ligações lentas não façam mais a remoção da marca d'água falhar silenciosamente.
- **Seletor de pastas sem cortes**: O campo de entrada do Gemini passou a cortar o seletor de pastas que abre para cima até restar uma faixa — agora aparece por inteiro.
- **Painel de pastas sobrevive ao redimensionamento**: Cruzar o breakpoint móvel do Gemini podia remover o painel de pastas até recarregar; agora ele restaura-se automaticamente em cerca de um segundo.
- **Abrir conversas de pasta em novo separador**: As conversas dentro de pastas agora suportam a abertura nativa em novo separador (Ctrl/Cmd-clique ou clique do meio).
- **Links das notas da versão 1.4.8**: Reparados os links de documentação das notas anteriores que apontavam para páginas em falta.

<!-- lang:ar -->

### الجديد

- **ترتيب الـ Gems حسب آخر استخدام**: أصبحت قائمة الـ Gems في الشريط الجانبي تُرتَّب حسب آخر استخدام لك — وتظهر فيها أيضًا Gems جوجل الجاهزة دون الحاجة إلى زيارة صفحة إدارة الـ Gems.
- **تطبيق فوري لمزامنة عنوان التبويب**: تفعيل مزامنة عنوان التبويب أو تعطيلها يسري الآن فورًا، دون إعادة تحميل الصفحة.

### الإصلاحات

- **زر طي الشريط الجانبي يعمل من جديد**: عند تخصيص عرض الشريط الجانبي، كان شريط غير مرئي من أعلى صفحة Gemini يبتلع النقرات على زرّ الطي، فلا تستجيب سوى حافّتيه — أصبح الزر الآن قابلًا للنقر بكامل مساحته.
- **إزالة العلامة المائية على الشبكات البطيئة**: أصبح اكتشاف التنزيل ينتظر حتى 60 ثانية بدلًا من 10، فلا تفشل إزالة العلامة المائية بصمت على الاتصالات البطيئة.
- **منتقي المجلدات لم يعد مقصوصًا**: بدأ حقل الإدخال في Gemini يقصّ منتقي المجلدات المفتوح للأعلى حتى لا يظهر منه سوى شريط رفيع — أصبح يظهر كاملًا الآن.
- **لوحة المجلدات تنجو من تغيير حجم النافذة**: كان عبور نقطة التحوّل للجوال في Gemini قد يُزيل لوحة المجلدات حتى إعادة تحميل كاملة؛ تستعيد نفسها الآن تلقائيًا خلال نحو ثانية.
- **فتح محادثات المجلد في تبويب جديد**: تدعم المحادثات داخل المجلدات الآن الفتح الأصلي في تبويب جديد (Ctrl/Cmd مع النقر أو النقر بالزر الأوسط).
- **روابط ملاحظات إصدار 1.4.8**: أُصلحت روابط التوثيق في ملاحظات الإصدار السابق التي كانت تشير إلى صفحات مفقودة.

<!-- lang:ko -->

### 새로운 기능

- **최근 사용한 Gem 우선 표시**: 사이드바 Gem 목록이 이제 최근 사용 순으로 정렬됩니다 — Google 기본 제공 Gem도 Gem 관리 페이지를 방문하지 않아도 표시됩니다.
- **탭 제목 동기화 즉시 적용**: 탭 제목 동기화를 켜거나 끄면 페이지 새로고침 없이 즉시 적용됩니다.

### 수정

- **사이드바 접기 버튼 클릭 복구**: 사이드바 너비를 사용자 지정하면 Gemini 상단 바의 보이지 않는 띠가 접기 버튼 가운데 클릭을 삼켜 위아래 가장자리만 눌렸습니다 — 이제 버튼 전체가 정상적으로 클릭됩니다.
- **느린 네트워크에서의 워터마크 제거**: 다운로드 감지 대기 시간을 10초에서 60초로 늘려, 느린 연결에서 워터마크 제거가 조용히 실패하지 않습니다.
- **폴더 선택기 잘림 해결**: Gemini 입력창이 위로 열리는 폴더 선택기를 가느다란 띠만 남도록 잘라냈는데, 이제 전체가 표시됩니다.
- **창 크기 조절 후 폴더 패널 자동 복구**: 창 너비가 Gemini 모바일 분기점을 넘나들면 폴더 패널이 사라져 새로고침이 필요했지만, 이제 약 1초 안에 자동 복구됩니다.
- **폴더 대화를 새 탭에서 열기**: 폴더 안의 대화가 네이티브 새 탭 열기(Ctrl/Cmd+클릭, 휠 클릭)를 지원합니다.
- **1.4.8 릴리스 노트 링크**: 이전 릴리스 노트에서 없는 페이지를 가리키던 문서 링크를 수정했습니다.

<!-- lang:ru -->

### Новое

- **Gems в порядке недавнего использования**: Список gems в боковой панели теперь упорядочен по недавнему использованию — готовые gems от Google тоже появляются, без захода в менеджер gems.
- **Мгновенное применение синхронизации заголовка вкладки**: Включение и выключение синхронизации заголовка вкладки теперь действует сразу, без перезагрузки страницы.

### Исправления

- **Кнопка сворачивания боковой панели снова кликабельна**: При пользовательской ширине боковой панели невидимая полоса верхней панели Gemini перехватывала клики по кнопке сворачивания, оставляя кликабельными только её края — теперь кнопка работает по всей площади.
- **Удаление водяного знака в медленных сетях**: Обнаружение загрузки теперь ждёт до 60 секунд вместо 10, поэтому на медленных соединениях удаление водяного знака больше не срывается незаметно.
- **Селектор папок больше не обрезается**: Поле ввода Gemini стало обрезать открывающийся вверх селектор папок до тонкой полоски — теперь он отображается целиком.
- **Панель папок переживает изменение размера окна**: Пересечение мобильного брейкпоинта Gemini могло убрать панель папок до полной перезагрузки; теперь она автоматически восстанавливается примерно за секунду.
- **Открытие чатов из папок в новой вкладке**: Диалоги внутри папок теперь поддерживают нативное открытие в новой вкладке (Ctrl/Cmd-клик или клик колёсиком).
- **Ссылки в заметках к версии 1.4.8**: Исправлены ссылки на документацию в предыдущих заметках о выпуске, которые вели на отсутствующие страницы.
`;export{e as default};
