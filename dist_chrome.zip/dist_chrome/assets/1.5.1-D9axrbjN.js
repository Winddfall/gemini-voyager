const e=`<!-- lang:en -->

### What's New

- **Pin the gems you actually use**: A pin toggle now lives right on Gemini's Gems page, and your pinned gems float to the top of the sidebar list — always within reach.
- **Paragraph spacing, your way**: A new control loosens or tightens the space between paragraphs in replies, so long answers read the way you like.
- **Clear out AI Studio in one sweep**: Select several saved items in your AI Studio library and delete them together, instead of one at a time.
- **A calmer conversation timeline**: The hover zone is wider, so the slider wakes up without hunting for a one-pixel line, and jump-to search got a clean command-palette look.

### Fixes

- **The copy button stays with you**: On long code blocks, the copy and download buttons now stick to the top as you scroll, instead of slipping away upward.
- **One reply, one ping**: Completion alerts are deduped, so a finished response no longer notifies you twice.
- **Crisp math in exported images**: Image exports now embed their fonts, so formulas come out sharp instead of broken or boxed.
- **A smoother full-hide sidebar**: Collapsing the fully hidden sidebar now glides to zero width instead of snapping shut.
- **The usage pill counts down to reset** *(off by default)*: When the usage bar is on, the pill shows when your limit resets — in days, hours, or minutes as the moment gets close.
- **AI folder sorting is more forgiving**: Auto-organizing into folders no longer stalls when the AI wraps its reply a little differently.
- **Exported images keep loading**: Google image links now keep their query parameters, so pictures in exports don't turn into broken thumbnails.
- **Your default model stays put**: The model selector no longer loops retrying a switch that Gemini refused.
- **Lighter visual effects on Firefox**: Effects ease off their frame rate and particle count on Firefox, for a smoother, cooler-running page.

---

> *"Life is but a wayside inn; I too am a traveler passing through." — Su Shi*

<!-- lang:zh -->

### 新功能

- **把常用的 Gem 钉在最上面**：现在可以直接在 Gemini 的 Gems 页面点选固定，被钉住的 Gem 会浮到侧边栏列表最前面，伸手就够得到。
- **段落间距，松紧随你**：新增段落间距调节，回复里的段落想松一点、紧一点都行，长答案读起来更顺眼。
- **AI Studio 一次清空**：在 AI Studio 资料库里勾选多个条目，一次性批量删除，不用再一条一条点。
- **更顺手的对话时间轴**：悬停区变宽了，不用再精准戳那条细线就能唤醒滑块；跳转搜索也换上了清爽的命令面板样式。

### 修复

- **复制按钮一路跟着你**：代码很长时，复制和下载按钮会贴在顶部随你滚动，不会再滚着滚着就溜走。
- **一条回复，只响一次**：完成提醒做了去重，一次回复结束不会再连弹两下。
- **导出图片里的公式更清晰**：图片导出现在会内嵌字体，公式不再糊成一团或缺字。
- **侧边栏完全隐藏更顺滑**：完全收起侧边栏时会平滑收到零宽，而不是「啪」地一下消失。
- **用量胶囊会倒数到重置** *（默认关闭）*：开启用量条后，胶囊会显示额度还有多久重置——临近时按天、小时、分钟细化。
- **AI 整理文件夹更稳**：AI 自动归类时，回复格式稍有不同也能正确解析，不会卡住。
- **导出的图片不再失效**：Google 图片链接会保留查询参数，导出里的图片不会变成裂图。
- **默认模型不再乱跳**：模型选择器不会再反复重试一个被 Gemini 拒绝的切换。
- **Firefox 视觉特效更轻**：在 Firefox 上特效会降低帧率和粒子数量，页面更顺、机器更凉。

---

> *“人生如逆旅，我亦是行人。” —— 苏轼《临江仙·送钱穆父》*

<!-- lang:zh_TW -->

### 新功能

- **把常用的 Gem 釘在最上面**：現在可以直接在 Gemini 的 Gems 頁面點選固定，被釘住的 Gem 會浮到側邊欄列表最前面，伸手就夠得到。
- **段落間距，鬆緊隨你**：新增段落間距調整，回覆裡的段落想鬆一點、緊一點都行，長答案讀起來更順眼。
- **AI Studio 一次清空**：在 AI Studio 資料庫裡勾選多個項目，一次性批次刪除，不用再一條一條點。
- **更順手的對話時間軸**：懸停區變寬了，不用再精準戳那條細線就能喚醒滑桿；跳轉搜尋也換上了清爽的命令面板樣式。

### 修復

- **複製按鈕一路跟著你**：程式碼很長時，複製和下載按鈕會貼在頂部隨你捲動，不會再捲著捲著就溜走。
- **一則回覆，只響一次**：完成提醒做了去重，一次回覆結束不會再連彈兩下。
- **匯出圖片裡的公式更清晰**：圖片匯出現在會內嵌字型，公式不再糊成一團或缺字。
- **側邊欄完全隱藏更順滑**：完全收起側邊欄時會平滑收到零寬，而不是「啪」地一下消失。
- **用量膠囊會倒數到重置** *（預設關閉）*：開啟用量列後，膠囊會顯示額度還有多久重置——臨近時按天、小時、分鐘細化。
- **AI 整理資料夾更穩**：AI 自動歸類時，回覆格式稍有不同也能正確解析，不會卡住。
- **匯出的圖片不再失效**：Google 圖片連結會保留查詢參數，匯出裡的圖片不會變成裂圖。
- **預設模型不再亂跳**：模型選擇器不會再反覆重試一個被 Gemini 拒絕的切換。
- **Firefox 視覺特效更輕**：在 Firefox 上特效會降低影格率和粒子數量，頁面更順、機器更涼。

---

> *「人生如逆旅，我亦是行人。」——蘇軾〈臨江仙·送錢穆父〉*

<!-- lang:ja -->

### 新機能

- **よく使う Gem をいちばん上に固定**：Gemini の Gems ページからそのままピン留めでき、固定した Gem がサイドバー一覧の先頭に並びます。
- **段落の間隔を自分好みに**：返信の段落間隔を広げたり詰めたりできるようになり、長い回答も読みやすく整えられます。
- **AI Studio をまとめて整理**：AI Studio ライブラリで複数の項目を選んで一括削除できます。1 件ずつ消す必要はありません。
- **使いやすくなった会話タイムライン**：ホバー範囲が広がり、細い線を狙わなくてもスライダーが反応します。ジャンプ検索もすっきりしたコマンドパレット風になりました。

### 修正

- **コピーボタンが追従**：長いコードブロックでも、コピー／ダウンロードのボタンがスクロール中も上部に貼り付いて消えなくなりました。
- **1 つの返信に通知は 1 回**：完了通知の重複をなくし、返信が終わっても二度鳴らないようにしました。
- **書き出した画像の数式がくっきり**：画像エクスポートにフォントを埋め込むようにし、数式が崩れたり欠けたりしなくなりました。
- **全隠しサイドバーがなめらかに**：完全に隠すとき、サイドバーが幅ゼロまでスムーズに縮むようになりました。
- **使用量ピルにリセットまでのカウントダウン** *(デフォルトはオフ)*：使用量バーをオンにすると、上限がリセットされるまでの残り時間を、近づくにつれて日・時間・分で表示します。
- **AI のフォルダ整理がより寛容に**：AI の応答形式が少し違っても、自動振り分けが止まりにくくなりました。
- **書き出した画像が表示され続ける**：Google 画像のリンクがクエリパラメータを保持するようになり、エクスポート内の画像がリンク切れになりません。
- **デフォルトモデルが固定される**：Gemini に拒否された切り替えを、セレクターが何度も再試行しなくなりました。
- **Firefox の視覚エフェクトを軽量化**：Firefox ではエフェクトのフレームレートとパーティクル数を抑え、ページがより軽く動きます。

---

> *「人生は旅の宿、我もまた行く人にすぎない。」——蘇軾*

<!-- lang:fr -->

### Nouveautés

- **Épinglez les gems que vous utilisez vraiment** : Un bouton d'épinglage se trouve désormais directement sur la page Gems de Gemini, et vos gems épinglés remontent en haut de la liste de la barre latérale — toujours à portée.
- **L'espacement des paragraphes, à votre goût** : Un nouveau réglage aère ou resserre l'espace entre les paragraphes des réponses, pour que les longues réponses se lisent comme vous aimez.
- **Videz la bibliothèque AI Studio d'un coup** : Sélectionnez plusieurs éléments enregistrés dans votre bibliothèque AI Studio et supprimez-les ensemble, au lieu d'un par un.
- **Une chronologie de conversation plus sereine** : La zone de survol est plus large, donc le curseur se réveille sans viser une ligne d'un pixel, et la recherche de saut adopte un look de palette de commandes épuré.

### Corrections

- **Le bouton copier vous suit** : Sur les longs blocs de code, les boutons copier et télécharger restent collés en haut pendant le défilement, au lieu de disparaître vers le haut.
- **Une réponse, une notification** : Les notifications de fin sont dédupliquées, donc une réponse terminée ne vous alerte plus deux fois.
- **Des maths nettes dans les images exportées** : Les exports d'images intègrent désormais leurs polices, pour des formules nettes plutôt que cassées ou encadrées.
- **Un masquage complet de la barre latérale plus fluide** : Replier la barre latérale entièrement masquée glisse jusqu'à une largeur nulle au lieu de se fermer d'un coup.
- **La pastille d'utilisation décompte jusqu'à la réinitialisation** *(désactivée par défaut)* : Quand la barre d'utilisation est activée, la pastille indique quand votre limite se réinitialise — en jours, heures ou minutes à l'approche.
- **Le tri par dossiers de l'IA est plus tolérant** : L'organisation automatique en dossiers ne bloque plus quand l'IA formule sa réponse un peu différemment.
- **Les images exportées restent affichées** : Les liens d'images Google conservent leurs paramètres de requête, pour que les images des exports ne deviennent pas des vignettes cassées.
- **Votre modèle par défaut reste en place** : Le sélecteur de modèle ne réessaie plus en boucle un changement refusé par Gemini.
- **Des effets visuels plus légers sur Firefox** : Les effets réduisent leur fréquence d'images et leur nombre de particules sur Firefox, pour une page plus fluide.

---

> *« La vie n'est qu'une auberge sur la route ; moi aussi, je ne suis qu'un voyageur de passage. » — Su Shi*

<!-- lang:es -->

### Novedades

- **Fija las gems que de verdad usas**: Un botón para fijar aparece ahora directamente en la página de Gems de Gemini, y tus gems fijadas suben al principio de la lista de la barra lateral — siempre a mano.
- **El espaciado de párrafos, a tu gusto**: Un nuevo control amplía o ajusta el espacio entre párrafos en las respuestas, para que las respuestas largas se lean como prefieres.
- **Vacía la biblioteca de AI Studio de una vez**: Selecciona varios elementos guardados en tu biblioteca de AI Studio y bórralos juntos, en lugar de uno por uno.
- **Una línea de tiempo de conversación más serena**: La zona de hover es más ancha, así el control deslizante se activa sin apuntar a una línea de un píxel, y la búsqueda de salto estrena un aspecto limpio de paleta de comandos.

### Correcciones

- **El botón de copiar te acompaña**: En bloques de código largos, los botones de copiar y descargar se quedan fijos arriba mientras te desplazas, en vez de desaparecer hacia arriba.
- **Una respuesta, un aviso**: Las notificaciones de finalización se deduplican, así una respuesta terminada ya no te avisa dos veces.
- **Matemáticas nítidas en las imágenes exportadas**: Las exportaciones de imágenes ahora incrustan sus fuentes, para fórmulas nítidas en lugar de rotas o recuadradas.
- **Ocultar del todo la barra lateral, más suave**: Plegar la barra lateral totalmente oculta se desliza hasta ancho cero en vez de cerrarse de golpe.
- **La píldora de uso cuenta atrás hasta el reinicio** *(desactivada por defecto)*: Con la barra de uso activada, la píldora muestra cuándo se reinicia tu límite — en días, horas o minutos según se acerca.
- **El orden por carpetas de la IA es más tolerante**: La organización automática en carpetas ya no se atasca cuando la IA formula su respuesta de forma algo distinta.
- **Las imágenes exportadas siguen cargando**: Los enlaces de imágenes de Google conservan sus parámetros de consulta, así las imágenes de las exportaciones no se convierten en miniaturas rotas.
- **Tu modelo predeterminado se queda fijo**: El selector de modelo ya no reintenta en bucle un cambio que Gemini rechazó.
- **Efectos visuales más ligeros en Firefox**: Los efectos reducen su tasa de fotogramas y número de partículas en Firefox, para una página más fluida.

---

> *«La vida no es más que una posada en el camino; yo también soy un viajero de paso.» — Su Shi*

<!-- lang:pt -->

### Novidades

- **Fixe as gems que você realmente usa**: Um botão de fixar fica agora direto na página de Gems do Gemini, e as suas gems fixadas sobem para o topo da lista da barra lateral — sempre à mão.
- **O espaçamento de parágrafos, do seu jeito**: Um novo controlo alarga ou aperta o espaço entre parágrafos nas respostas, para que respostas longas se leiam como você gosta.
- **Esvazie a biblioteca do AI Studio de uma vez**: Selecione vários itens guardados na sua biblioteca do AI Studio e apague-os juntos, em vez de um a um.
- **Uma linha do tempo de conversa mais serena**: A zona de passagem do rato ficou mais larga, por isso o controlo deslizante acorda sem mirar uma linha de um pixel, e a busca de salto ganhou um visual limpo de paleta de comandos.

### Correções

- **O botão de copiar acompanha você**: Em blocos de código longos, os botões de copiar e baixar ficam fixos no topo enquanto você rola, em vez de sumir para cima.
- **Uma resposta, um aviso**: As notificações de conclusão são desduplicadas, então uma resposta terminada não avisa mais duas vezes.
- **Matemática nítida nas imagens exportadas**: As exportações de imagem agora incorporam as fontes, para fórmulas nítidas em vez de quebradas ou enquadradas.
- **Ocultar totalmente a barra lateral, mais suave**: Recolher a barra lateral totalmente oculta desliza até largura zero em vez de fechar de repente.
- **A pílula de uso faz a contagem até o reinício** *(desativada por padrão)*: Com a barra de uso ligada, a pílula mostra quando o seu limite reinicia — em dias, horas ou minutos à medida que se aproxima.
- **A organização por pastas da IA é mais tolerante**: A organização automática em pastas já não trava quando a IA formula a resposta de forma um pouco diferente.
- **As imagens exportadas continuam a carregar**: Os links de imagens do Google mantêm os parâmetros de consulta, para que as imagens nas exportações não virem miniaturas quebradas.
- **O seu modelo padrão permanece**: O seletor de modelo já não tenta repetidamente uma troca que o Gemini recusou.
- **Efeitos visuais mais leves no Firefox**: Os efeitos reduzem a taxa de quadros e o número de partículas no Firefox, para uma página mais fluida.

---

> *«A vida não passa de uma estalagem na estrada; eu também sou apenas um viajante de passagem.» — Su Shi*

<!-- lang:ar -->

### الجديد

- **ثبّت الـ Gems التي تستخدمها فعلًا**: أصبح زر التثبيت متاحًا مباشرةً في صفحة Gems داخل Gemini، وتظهر الـ Gems المثبّتة في أعلى قائمة الشريط الجانبي — دائمًا في متناول يدك.
- **تباعد الفقرات كما يحلو لك**: عنصر تحكّم جديد يوسّع أو يضيّق المسافة بين الفقرات في الردود، لتقرأ الإجابات الطويلة بالشكل الذي تفضّله.
- **أفرغ مكتبة AI Studio دفعة واحدة**: حدّد عدة عناصر محفوظة في مكتبة AI Studio واحذفها معًا بدل حذفها واحدًا تلو الآخر.
- **خط زمني للمحادثة أكثر هدوءًا**: اتّسعت منطقة التمرير فوقها، فيستيقظ المنزلق دون الحاجة لإصابة خط رفيع، وحصل بحث الانتقال على مظهر أنيق يشبه لوحة الأوامر.

### الإصلاحات

- **زر النسخ يبقى معك**: في كتل الكود الطويلة، يبقى زرّا النسخ والتنزيل ملتصقَين بالأعلى أثناء التمرير بدل أن يختفيا للأعلى.
- **رد واحد، تنبيه واحد**: أصبحت إشعارات الاكتمال بلا تكرار، فلا ينبّهك الرد المنتهي مرتين.
- **رياضيات واضحة في الصور المصدَّرة**: تضمّن الصور المصدَّرة خطوطها الآن، فتظهر المعادلات واضحة بدل أن تتكسّر أو تُحاط بإطار.
- **إخفاء الشريط الجانبي بالكامل بسلاسة**: عند الإخفاء الكامل ينزلق الشريط الجانبي إلى عرض صفري بدل أن يُغلق فجأة.
- **كبسولة الاستخدام تعدّ تنازليًا حتى التصفير** *(موقوفة افتراضيًا)*: عند تفعيل شريط الاستخدام، تعرض الكبسولة موعد تصفير حدّك — بالأيام أو الساعات أو الدقائق كلما اقترب.
- **تنظيم المجلدات بالذكاء الاصطناعي أكثر تسامحًا**: لم يعد التنظيم التلقائي في المجلدات يتوقف عندما يصوغ الذكاء الاصطناعي رده بشكل مختلف قليلًا.
- **الصور المصدَّرة تبقى ظاهرة**: تحتفظ روابط صور Google بمعاملات الاستعلام، فلا تتحول صور التصدير إلى صور مكسورة.
- **النموذج الافتراضي يبقى ثابتًا**: لم يعد محدد النماذج يعيد محاولة تبديل رفضه Gemini مرارًا.
- **مؤثرات بصرية أخف على Firefox**: تقلّل المؤثرات معدّل الإطارات وعدد الجسيمات على Firefox، لصفحة أكثر سلاسة.

---

> *«ما الحياة إلا نُزُلٌ على الطريق، وأنا أيضًا مسافرٌ عابر.» — سو شي*

<!-- lang:ko -->

### 새로운 기능

- **자주 쓰는 Gem을 맨 위에 고정**: 이제 Gemini의 Gems 페이지에서 바로 고정할 수 있고, 고정한 Gem이 사이드바 목록 맨 앞으로 올라옵니다 — 언제나 손 닿는 곳에.
- **문단 간격을 취향대로**: 답변의 문단 사이 간격을 넓히거나 좁힐 수 있는 설정이 생겨, 긴 답변도 원하는 대로 읽기 좋게 다듬을 수 있습니다.
- **AI Studio 라이브러리를 한 번에 정리**: AI Studio 라이브러리에서 여러 항목을 선택해 한꺼번에 삭제할 수 있습니다. 하나씩 지울 필요가 없습니다.
- **한결 편해진 대화 타임라인**: 호버 영역이 넓어져 가느다란 선을 정확히 겨누지 않아도 슬라이더가 반응하고, 이동 검색은 깔끔한 명령 팔레트 느낌으로 바뀌었습니다.

### 수정

- **복사 버튼이 따라옵니다**: 긴 코드 블록에서 복사·다운로드 버튼이 스크롤하는 동안 위로 사라지지 않고 상단에 붙어 있습니다.
- **하나의 답변, 하나의 알림**: 완료 알림의 중복을 없애, 답변이 끝나도 두 번 울리지 않습니다.
- **내보낸 이미지의 수식이 또렷하게**: 이미지 내보내기에 글꼴을 포함해, 수식이 깨지거나 네모로 나오지 않습니다.
- **완전 숨김 사이드바가 더 부드럽게**: 사이드바를 완전히 숨길 때 갑자기 닫히지 않고 너비 0까지 매끄럽게 줄어듭니다.
- **사용량 알약이 초기화까지 카운트다운** *(기본 꺼짐)*: 사용량 바를 켜면 알약이 한도가 언제 초기화되는지 — 가까워질수록 일·시간·분 단위로 — 보여줍니다.
- **AI 폴더 정리가 더 너그럽게**: AI가 답변 형식을 조금 다르게 내놓아도 자동 분류가 멈추지 않습니다.
- **내보낸 이미지가 계속 표시됩니다**: Google 이미지 링크가 쿼리 매개변수를 유지해, 내보내기 속 이미지가 깨진 썸네일로 바뀌지 않습니다.
- **기본 모델이 그대로 유지됩니다**: 모델 선택기가 Gemini가 거부한 전환을 반복해서 재시도하지 않습니다.
- **Firefox에서 더 가벼운 시각 효과**: Firefox에서 효과의 프레임 속도와 입자 수를 줄여 페이지가 더 부드럽게 동작합니다.

---

> *"인생은 길 위의 여인숙, 나 또한 지나가는 나그네일 뿐." — 소식(蘇軾)*

<!-- lang:ru -->

### Новое

- **Закрепляйте нужные gems сверху**: Кнопка закрепления теперь прямо на странице Gems в Gemini, а закреплённые gems поднимаются в начало списка боковой панели — всегда под рукой.
- **Межабзацный интервал — как вам удобно**: Новый регулятор расширяет или сжимает расстояние между абзацами в ответах, чтобы длинные ответы читались так, как вы любите.
- **Очистите библиотеку AI Studio разом**: Выберите несколько сохранённых элементов в библиотеке AI Studio и удалите их вместе, а не по одному.
- **Более спокойная лента беседы**: Зона наведения стала шире, так что ползунок просыпается без прицеливания в тонкую линию, а поиск перехода получил аккуратный вид командной палитры.

### Исправления

- **Кнопка копирования следует за вами**: В длинных блоках кода кнопки копирования и загрузки остаются вверху при прокрутке, а не уезжают наверх.
- **Один ответ — одно уведомление**: Уведомления о завершении больше не дублируются, поэтому готовый ответ не оповещает дважды.
- **Чёткая математика в экспортированных изображениях**: Экспорт изображений теперь встраивает шрифты, поэтому формулы получаются чёткими, а не сломанными или в рамках.
- **Плавное полное скрытие боковой панели**: При полном скрытии боковая панель плавно сжимается до нулевой ширины, а не захлопывается.
- **Плашка использования ведёт отсчёт до сброса** *(выключена по умолчанию)*: При включённой панели использования плашка показывает, когда сбрасывается лимит — в днях, часах или минутах по мере приближения.
- **Разбор папок ИИ стал терпимее**: Автосортировка по папкам больше не застревает, когда ИИ оформляет ответ немного иначе.
- **Экспортированные изображения продолжают загружаться**: Ссылки на изображения Google сохраняют параметры запроса, поэтому картинки в экспортах не превращаются в битые миниатюры.
- **Модель по умолчанию остаётся на месте**: Селектор модели больше не повторяет в цикле переключение, которое Gemini отклонил.
- **Более лёгкие визуальные эффекты в Firefox**: Эффекты снижают частоту кадров и число частиц в Firefox для более плавной страницы.

---

> *«Жизнь — лишь постоялый двор в пути; я тоже только странник, идущий мимо.» — Су Ши*
`;export{e as default};
