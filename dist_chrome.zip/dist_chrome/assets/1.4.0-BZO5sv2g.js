const e=`<!-- lang:en -->

### What's New

- **Prompt manager refresh**: Compact list view with name labels and a fast hover preview.
- **Sidebar auto-hide**: Smooth animation with predictive aiming makes the sidebar feel more intentional.
- **Image export width**: Pick the export width, and your last choice is remembered.
- **Folder as project**: Turn any folder into a lightweight project — set per-folder instructions that prepend to your first message, and new chats auto-file into the folder.
- **Settings in sync & export**: Your settings now ride along in cloud sync and backup exports.
- **Prompt click action**: Configure what happens when you click a prompt in the library.

### Fixes

- **Safari send behavior**: Fixed the double-Enter-to-send issue on Safari.
- **Fork account route**: Forking now preserves the correct account route.
- **Folder sidebar spacing**: Removed excess dead space below the last folder.
- **Duplicate folder UI**: Import/export and create-folder buttons no longer spawn duplicate panels on repeated clicks.
- **Quote reply IME**: IME composition is preserved after quoting a message.
- **Gems notebook sections**: The notebook sections in Gems can now be hidden.
- **Empty prompt import**: Clearer messaging when imported prompts are empty.
- **Archived folder navigation**: Hardened navigation for archived conversations.

<!-- lang:zh -->

### 新功能

- **Prompt 管理器焕新**：紧凑列表视图 + 名称标签 + 极速悬浮预览。
- **侧边栏自动隐藏**：平滑动画 + 预判式瞄准，交互更自然。
- **图片导出宽度**：可选择导出宽度，并自动记住上次选择。
- **文件夹即项目**：把任意文件夹变成轻量级项目——设置文件夹专属说明（自动前置到首条消息），新对话也会自动归入该文件夹。
- **设置纳入同步与导出**：设置项现在会一并参与云同步和备份导出。
- **Prompt 点击行为可配置**：可自定义在 Prompt 库中点击 prompt 时的行为。

### 修复

- **Safari 发送行为**：修复 Safari 下双 Enter 才发送的问题。
- **分支账号路由**：分支对话时保留当前账号路由。
- **文件夹底部间距**：收紧侧边栏最后一个文件夹下方的空白区域。
- **文件夹按钮重复弹出**：导入/导出和新建文件夹按钮重复点击时不再产生重复面板。
- **引用回复 IME**：引用消息后保留输入法组合状态。
- **Gems 笔记本分区**：现在可以隐藏 Gems 中的笔记本分区。
- **空 prompt 导入**：导入空 prompt 时给出更清晰的提示。
- **归档文件夹导航**：增强了归档对话的导航稳定性。

<!-- lang:zh_TW -->

### 新功能

- **Prompt 管理器煥新**：緊湊列表檢視 + 名稱標籤 + 極速懸浮預覽。
- **側邊欄自動隱藏**：平滑動畫 + 預判式瞄準，互動更自然。
- **圖片匯出寬度**：可選擇匯出寬度，並自動記住上次的選擇。
- **資料夾即專案**：將任一資料夾變成輕量級專案——設定資料夾專屬說明（自動前置到首條訊息），新對話也會自動歸入該資料夾。
- **設定納入同步與匯出**：設定項目現在會一併參與雲端同步和備份匯出。
- **Prompt 點擊行為可設定**：可自訂在 Prompt 庫中點擊 prompt 時的行為。

### 修復

- **Safari 傳送行為**：修復 Safari 下需按兩次 Enter 才傳送的問題。
- **分支帳號路由**：分支對話時保留目前帳號路由。
- **資料夾底部間距**：收緊側邊欄最後一個資料夾下方的空白區域。
- **資料夾按鈕重複彈出**：匯入/匯出和新建資料夾按鈕重複點擊時不再產生重複面板。
- **引用回覆 IME**：引用訊息後保留輸入法組字狀態。
- **Gems 筆記本分區**：現在可以隱藏 Gems 中的筆記本分區。
- **空 prompt 匯入**：匯入空 prompt 時給出更清晰的提示。
- **封存資料夾導航**：增強了封存對話的導航穩定性。

<!-- lang:ja -->

### 新機能

- **プロンプトマネージャー刷新**：名前ラベル付きのコンパクトリスト表示と高速ホバープレビュー。
- **サイドバー自動非表示**：スムーズなアニメーションと予測エイミングで、より自然な操作感に。
- **画像エクスポートの幅選択**：エクスポート幅を選択でき、前回の選択を記憶します。
- **フォルダをプロジェクトに**：任意のフォルダを軽量プロジェクトに変換できます — フォルダごとの説明を設定すると最初のメッセージに自動で前置され、新しい会話はそのフォルダに自動で振り分けられます。
- **設定をクラウド同期とエクスポートに含める**：設定項目がクラウド同期とバックアップエクスポートに含まれるようになりました。
- **プロンプトクリック動作**：ライブラリでプロンプトをクリックしたときの動作を設定できます。

### 修正

- **Safari の送信挙動**：Safari で Enter を 2 回押さないと送信されない問題を修正しました。
- **フォーク時のアカウントルート**：フォーク時に正しいアカウントルートを保持するようになりました。
- **フォルダのサイドバー余白**：最後のフォルダの下の余分な空白を詰めました。
- **フォルダボタンの重複表示**：インポート/エクスポートやフォルダ作成ボタンを連打しても重複パネルが出ないようになりました。
- **引用返信の IME**：メッセージを引用した後も IME の入力中状態が保持されます。
- **Gems のノートブックセクション**：Gems のノートブックセクションを非表示にできるようになりました。
- **空プロンプトのインポート**：インポートされたプロンプトが空のときのメッセージを分かりやすくしました。
- **アーカイブフォルダのナビゲーション**：アーカイブ済みの会話のナビゲーションを強化しました。

<!-- lang:fr -->

### Nouveautés

- **Gestionnaire de prompts revu** : Liste compacte avec étiquettes de nom et aperçu rapide au survol.
- **Masquage automatique de la sidebar** : Animations fluides et visée prédictive pour une interaction plus naturelle.
- **Largeur d'export d'image** : Choisissez la largeur d'export ; votre dernier choix est mémorisé.
- **Dossier comme projet** : Transformez n'importe quel dossier en projet léger — définissez des instructions par dossier (ajoutées automatiquement en préambule au premier message) et les nouvelles conversations sont classées dans ce dossier.
- **Paramètres dans la sync et l'export** : Vos paramètres sont désormais inclus dans la synchronisation cloud et les exports de sauvegarde.
- **Action au clic sur un prompt** : Configurez ce qui se passe lorsque vous cliquez sur un prompt dans la bibliothèque.

### Corrections

- **Envoi sur Safari** : Correction du problème nécessitant deux appuis sur Entrée pour envoyer.
- **Route de compte lors du fork** : Le fork préserve désormais la bonne route de compte.
- **Espacement des dossiers dans la sidebar** : Suppression de l'espace vide sous le dernier dossier.
- **Duplication d'éléments de dossier** : Les boutons import/export et nouveau dossier ne créent plus de panneaux dupliqués lors de clics répétés.
- **IME lors de la réponse citée** : La composition IME est préservée après avoir cité un message.
- **Sections de notebook dans Gems** : Les sections de notebook dans Gems peuvent désormais être masquées.
- **Import de prompt vide** : Messages plus clairs lorsque les prompts importés sont vides.
- **Navigation des dossiers archivés** : Renforcement de la navigation pour les conversations archivées.

<!-- lang:es -->

### Novedades

- **Gestor de prompts renovado**: Vista de lista compacta con etiquetas de nombre y vista previa rápida al pasar el cursor.
- **Ocultamiento automático de la barra lateral**: Animación fluida y apuntado predictivo hacen la barra más natural.
- **Ancho de exportación de imagen**: Elige el ancho de exportación y se recuerda tu última elección.
- **Carpeta como proyecto**: Convierte cualquier carpeta en un proyecto ligero — define instrucciones por carpeta (se anteponen automáticamente a tu primer mensaje) y las nuevas conversaciones se archivan automáticamente en esa carpeta.
- **Ajustes en sincronización y exportación**: Tus ajustes ahora se incluyen en la sincronización en la nube y las exportaciones de respaldo.
- **Acción al hacer clic en un prompt**: Configura qué ocurre al hacer clic en un prompt en la biblioteca.

### Correcciones

- **Envío en Safari**: Corregido el problema del doble Enter para enviar en Safari.
- **Ruta de cuenta al hacer fork**: El fork ahora preserva la ruta de cuenta correcta.
- **Espaciado de la barra lateral**: Eliminado el espacio vacío sobrante debajo de la última carpeta.
- **Elementos duplicados en carpetas**: Los botones de importar/exportar y crear carpeta ya no generan paneles duplicados al hacer clic repetidamente.
- **IME en respuesta citada**: La composición del IME se conserva al citar un mensaje.
- **Secciones de notebook en Gems**: Ahora se pueden ocultar las secciones de notebook en Gems.
- **Importación de prompt vacío**: Mensajes más claros cuando los prompts importados están vacíos.
- **Navegación en carpetas archivadas**: Navegación reforzada para conversaciones archivadas.

<!-- lang:pt -->

### Novidades

- **Gestor de prompts renovado**: Lista compacta com etiquetas de nome e pré-visualização rápida ao passar o cursor.
- **Ocultação automática da barra lateral**: Animações suaves e mira preditiva tornam a barra lateral mais natural.
- **Largura de exportação de imagem**: Escolha a largura de exportação; a sua última escolha é memorizada.
- **Pasta como projeto**: Transforme qualquer pasta num projeto leve — defina instruções por pasta (antepostas automaticamente à primeira mensagem) e novas conversas são arquivadas automaticamente nessa pasta.
- **Definições na sincronização e exportação**: As suas definições passam agora a ser incluídas na sincronização na nuvem e nas exportações de backup.
- **Ação ao clicar num prompt**: Configure o que acontece ao clicar num prompt na biblioteca.

### Correções

- **Envio no Safari**: Corrigido o problema do duplo Enter para enviar no Safari.
- **Rota de conta ao criar fork**: O fork preserva agora a rota de conta correta.
- **Espaçamento da barra lateral**: Removido o espaço vazio abaixo da última pasta.
- **Elementos duplicados em pastas**: Os botões de importar/exportar e criar pasta já não criam painéis duplicados quando clicados repetidamente.
- **IME na resposta citada**: A composição do IME é preservada após citar uma mensagem.
- **Secções de notebook no Gems**: As secções de notebook do Gems podem agora ser ocultadas.
- **Importação de prompt vazio**: Mensagens mais claras quando os prompts importados estão vazios.
- **Navegação em pastas arquivadas**: Navegação reforçada para conversas arquivadas.

<!-- lang:ar -->

### الجديد

- **تحديث مدير التعليمات**: عرض قائمة مدمج مع تسميات الأسماء ومعاينة سريعة عند التمرير.
- **الإخفاء التلقائي للشريط الجانبي**: رسوم متحركة سلسة مع استهداف تنبؤي لتفاعل أكثر طبيعية.
- **عرض تصدير الصور**: اختر عرض التصدير، وسيتم تذكّر آخر اختيار لك.
- **المجلد كمشروع**: حوّل أي مجلد إلى مشروع خفيف — عيّن تعليمات خاصة بالمجلد (تُضاف تلقائيًا قبل رسالتك الأولى) وتُصنَّف المحادثات الجديدة داخل ذلك المجلد تلقائيًا.
- **الإعدادات في المزامنة والتصدير**: باتت إعداداتك تُرافق المزامنة السحابية وعمليات تصدير النسخ الاحتياطية.
- **إجراء النقر على التعليمة**: اضبط ما يحدث عند النقر على تعليمة في المكتبة.

### الإصلاحات

- **سلوك الإرسال في Safari**: تم إصلاح مشكلة الحاجة إلى الضغط على Enter مرتين للإرسال في Safari.
- **مسار الحساب عند التفرع**: يحافظ التفرع الآن على مسار الحساب الصحيح.
- **تباعد المجلدات في الشريط الجانبي**: تمت إزالة الفراغ الزائد أسفل آخر مجلد.
- **عناصر مكررة في المجلدات**: لم تعد أزرار الاستيراد/التصدير وإنشاء مجلد تُنتج لوحات مكررة عند النقر المتكرر.
- **IME في الرد المقتبس**: يتم الحفاظ على حالة تركيب IME بعد اقتباس رسالة.
- **أقسام notebook في Gems**: يمكن الآن إخفاء أقسام notebook في Gems.
- **استيراد تعليمة فارغة**: رسائل أوضح عندما تكون التعليمات المستوردة فارغة.
- **تصفح المجلدات المؤرشفة**: تم تعزيز استقرار التنقل في المحادثات المؤرشفة.

<!-- lang:ko -->

### 새로운 기능

- **프롬프트 관리자 개편**: 이름 라벨이 붙은 콤팩트 목록 뷰와 빠른 호버 미리보기.
- **사이드바 자동 숨김**: 부드러운 애니메이션과 예측 조준으로 더 자연스러운 인터랙션.
- **이미지 내보내기 너비**: 내보내기 너비를 선택할 수 있으며, 마지막 선택이 기억됩니다.
- **폴더를 프로젝트로**: 어떤 폴더든 가벼운 프로젝트로 변환하세요 — 폴더별 지시사항을 설정하면 첫 메시지 앞에 자동으로 추가되고, 새 대화는 해당 폴더로 자동 분류됩니다.
- **설정을 동기화와 내보내기에 포함**: 설정 항목이 이제 클라우드 동기화와 백업 내보내기에 함께 포함됩니다.
- **프롬프트 클릭 동작**: 라이브러리에서 프롬프트를 클릭했을 때의 동작을 설정할 수 있습니다.

### 수정

- **Safari 전송 동작**: Safari에서 Enter를 두 번 눌러야 전송되던 문제를 수정했습니다.
- **포크 시 계정 경로**: 포크 시 올바른 계정 경로가 유지됩니다.
- **폴더 사이드바 여백**: 마지막 폴더 아래의 빈 공간을 줄였습니다.
- **폴더 UI 중복**: 가져오기/내보내기와 폴더 만들기 버튼을 연속으로 눌러도 중복 패널이 생기지 않습니다.
- **인용 답장 IME**: 메시지를 인용한 후에도 IME 조합 상태가 유지됩니다.
- **Gems 노트북 섹션**: Gems의 노트북 섹션을 숨길 수 있게 되었습니다.
- **빈 프롬프트 가져오기**: 가져온 프롬프트가 비어 있을 때 더 명확한 메시지를 표시합니다.
- **아카이브 폴더 탐색**: 아카이브된 대화의 탐색 안정성이 향상되었습니다.

<!-- lang:ru -->

### Новое

- **Обновлённый менеджер промптов**: Компактный список с метками имён и быстрым предпросмотром при наведении.
- **Автоскрытие боковой панели**: Плавная анимация с предиктивным наведением делает боковую панель более естественной.
- **Ширина экспорта изображений**: Выбирайте ширину экспорта — последний выбор запоминается.
- **Папка как проект**: Превратите любую папку в облегчённый проект — задайте инструкции для папки (они автоматически добавляются перед первым сообщением), а новые диалоги автоматически попадают в эту папку.
- **Настройки в синхронизации и экспорте**: Настройки теперь включаются в облачную синхронизацию и резервный экспорт.
- **Действие по клику на промпт**: Настройте, что происходит при клике на промпт в библиотеке.

### Исправления

- **Отправка в Safari**: Исправлена проблема двойного Enter для отправки в Safari.
- **Маршрут аккаунта при форке**: Форк теперь сохраняет правильный маршрут аккаунта.
- **Отступы папок в боковой панели**: Убран лишний пустой промежуток под последней папкой.
- **Дубли элементов папок**: Кнопки импорта/экспорта и создания папки больше не создают дублирующих панелей при повторных кликах.
- **IME в цитируемом ответе**: После цитирования сообщения сохраняется состояние композиции IME.
- **Разделы notebook в Gems**: Разделы notebook в Gems теперь можно скрыть.
- **Импорт пустого промпта**: Более понятные сообщения при импорте пустых промптов.
- **Навигация в архивных папках**: Усилена надёжность навигации для архивных диалогов.
`;export{e as default};
