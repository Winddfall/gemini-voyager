const e=`<!-- lang:en -->

### What's New

- **Real message timestamps**: The timeline now shows the actual time Gemini recorded on its servers, not just when your device first saw the message — fixing wrong or missing times when browsing history from another device.
- **Easier Prompt Manager discovery on ChatGPT/Claude**: A toolbar dot and an "Enable on this site" toggle in the popup point you to the Prompt Manager, and the import/export/cloud-sync panel now works directly on those sites too.
- **Prompts-only cloud sync**: New "Pull (merge)" / "Push (merge)" buttons sync just your prompt library to Google Drive, merging both sides non-destructively.

### Fixes

- **Claude timeline jitter**: Fixed the timeline growing/shrinking during scroll and stars/the active marker landing on the wrong turn, caused by Claude's virtualized conversation DOM.
- **Default model auto-apply**: Fixed occasional flicker, double-starred rows, and stolen input focus when auto-applying your default model or thinking level.
- **Gems sidebar**: Fixed the sidebar showing another account's cached Gems after switching accounts.
- **Folder stability**: Fixed a batch of issues including occasional message-send hangs and duplicate re-renders.
- **Sidebar collapse button**: Fixed the collapse button sometimes not responding to clicks after resizing the sidebar.
- **Folder recency sort**: Fixed unstable ordering in the recently-used conversation list.
- **Claude usage bar**: Fixed the bar occasionally reappearing on its own after being disabled.
- **Popup cloud-sync icons**: Now match the style used in the folder panel.
- **Prompt import/export**: Restored the import/export controls that were missing from the main settings panel.

---

> *"You meet the one you meet amongst thousands and tens of thousands of people, amidst thousands and tens of thousands of years, in the boundless wilderness of time — not a step sooner, not a step later." — Eileen Chang*

<!-- lang:zh -->

### 新功能

- **真实消息时间戳**：时间线现在显示 Gemini 服务器记录的真实发送时间，而不是你的设备第一次看到消息的时间——修复了跨设备查看历史记录时间不准或缺失的问题。
- **ChatGPT / Claude 提示词管理更易发现**：访问这两个网站时，弹窗会提示"在此网站启用提示词管理器"，工具栏图标也会出现小红点提醒；启用后，提示词的导入导出和云同步面板也能直接在这些网站上使用。
- **提示词专属云同步**：新增"拉取（合并）"和"推送（合并）"按钮，只同步你的提示词库到 Google Drive，双向合并、不覆盖数据。

### 修复

- **Claude 时间线抖动**：修复了 Claude 虚拟化对话导致时间线滚动时忽长忽短、收藏和当前位置标记错位的问题。
- **默认模型自动应用**：修复了自动应用默认模型/思考强度时偶尔画面闪烁、双重高亮星标、抢占输入框焦点的问题。
- **Gems 侧边栏**：修复切换 Google 账号后，侧边栏仍显示上一个账号缓存 Gems 的问题。
- **文件夹功能稳定性**：修复了一批问题，包括消息发送偶尔卡死、页面重复渲染。
- **侧边栏折叠按钮**：修复调整侧边栏宽度后，折叠按钮偶尔点击无效的问题。
- **文件夹最近使用排序**：修复最近对话排序不稳定的问题。
- **Claude 用量条**：修复关闭后偶尔又自动"复活"显示的问题。
- **弹窗云同步图标**：云同步按钮图标改为和文件夹面板一致的样式。
- **提示词导入导出**：修复主设置面板里提示词导入导出功能缺失的问题。

---

> *"于千万人之中遇见你所要遇见的人，于千万年之中，时间的无涯的荒野里，没有早一步，也没有晚一步，刚巧赶上了。" —— 张爱玲，《爱》*

<!-- lang:zh_TW -->

### 新功能

- **真實訊息時間戳記**：時間軸現在顯示 Gemini 伺服器記錄的真實傳送時間，而不是你的裝置第一次看到訊息的時間——修復了跨裝置檢視歷史紀錄時間不準或缺失的問題。
- **ChatGPT / Claude 提示詞管理更容易發現**：造訪這兩個網站時，彈出視窗會提示「在此網站啟用提示詞管理器」，工具列圖示也會出現小紅點提醒；啟用後，提示詞的匯入匯出和雲端同步面板也能直接在這些網站上使用。
- **提示詞專屬雲端同步**：新增「提取（合併）」和「推送（合併）」按鈕，只同步你的提示詞庫到 Google 雲端硬碟，雙向合併、不覆蓋資料。

### 修復

- **Claude 時間軸抖動**：修復了 Claude 虛擬化對話導致時間軸捲動時忽長忽短、收藏和目前位置標記錯位的問題。
- **預設模型自動套用**：修復了自動套用預設模型／思考強度時偶爾畫面閃爍、雙重高亮星號、搶走輸入框焦點的問題。
- **Gems 側邊欄**：修復切換 Google 帳號後，側邊欄仍顯示上一個帳號快取 Gems 的問題。
- **資料夾功能穩定性**：修復了一批問題，包括訊息傳送偶爾卡住、頁面重複渲染。
- **側邊欄折疊按鈕**：修復調整側邊欄寬度後，折疊按鈕偶爾點擊無效的問題。
- **資料夾最近使用排序**：修復最近對話排序不穩定的問題。
- **Claude 用量條**：修復關閉後偶爾又自動「復活」顯示的問題。
- **彈出視窗雲端同步圖示**：雲端同步按鈕圖示改為和資料夾面板一致的樣式。
- **提示詞匯入匯出**：修復主要設定面板裡提示詞匯入匯出功能缺失的問題。

---

> *「於千萬人之中遇見你所要遇見的人，於千萬年之中，時間的無涯的荒野裡，沒有早一步，也沒有晚一步，剛巧趕上了。」——張愛玲，《愛》*

<!-- lang:ja -->

### 新機能

- **実際のメッセージタイムスタンプ**：タイムラインに、デバイスが最初にメッセージを検出した時刻ではなく、Gemini のサーバーに記録された実際の送信時刻が表示されるようになりました。他のデバイスの履歴を見たときに時刻がずれたり表示されなかったりする問題を修正しています。
- **ChatGPT / Claude でのプロンプトマネージャーを見つけやすく**：これらのサイトにアクセスすると、ポップアップに「このサイトで有効にする」トグルが表示され、ツールバーアイコンにも赤いドットが表示されます。有効化後は、インポート/エクスポートとクラウド同期パネルもこれらのサイトで直接使えます。
- **プロンプト専用クラウド同期**：Google ドライブにプロンプトライブラリだけを同期する「取得（マージ）」「送信（マージ）」ボタンを追加しました。双方向にマージされ、データは上書きされません。

### 修正

- **Claude タイムラインのジッター**：Claude の仮想化された会話 DOM が原因で、スクロール時にタイムラインが伸び縮みしたり、スターや現在位置マーカーがずれたりする問題を修正しました。
- **既定モデルの自動適用**：既定モデルや思考レベルを自動適用する際に、たまに画面がちらつく、星印が二重に点灯する、入力欄のフォーカスを奪う問題を修正しました。
- **Gems サイドバー**：Google アカウントを切り替えた後、サイドバーに前のアカウントのキャッシュされた Gems が表示され続ける問題を修正しました。
- **フォルダーの安定性**：メッセージ送信が稀に固まる、画面が二重に再描画されるなど、複数の問題をまとめて修正しました。
- **サイドバーの折りたたみボタン**：サイドバーの幅を調整した後、折りたたみボタンがクリックに反応しないことがある問題を修正しました。
- **フォルダーの最近使った順の並び替え**：最近の会話の並び順が不安定になる問題を修正しました。
- **Claude 使用量バー**：無効化した後に、まれに勝手に再表示される問題を修正しました。
- **ポップアップのクラウド同期アイコン**：フォルダーパネルと同じスタイルのアイコンに統一しました。
- **プロンプトのインポート/エクスポート**：メイン設定パネルから消えていたインポート/エクスポート機能を復元しました。

---

> *「幾千万の人々の中で、出会うべき人に出会う。幾千万年という、涯てしない時間の荒野の中で、一歩早すぎることもなく、一歩遅すぎることもなく、ちょうど巡り合えた。」——張愛玲、《愛》*

<!-- lang:fr -->

### Nouveautés

- **Horodatage réel des messages** : La chronologie affiche désormais l'heure d'envoi réelle enregistrée par les serveurs de Gemini, plutôt que l'heure à laquelle votre appareil a vu le message pour la première fois — corrige les horaires erronés ou manquants lors de la consultation de l'historique depuis un autre appareil.
- **Gestionnaire de prompts plus facile à découvrir sur ChatGPT/Claude** : Un point sur l'icône de la barre d'outils et un interrupteur « Activer sur ce site » dans le popup vous orientent vers le Gestionnaire de prompts ; le panneau d'import/export et de synchronisation cloud fonctionne désormais directement sur ces sites aussi.
- **Synchronisation cloud dédiée aux prompts** : Nouveaux boutons « Récupérer (fusionner) » / « Envoyer (fusionner) » pour synchroniser uniquement votre bibliothèque de prompts sur Google Drive, en fusionnant les deux côtés sans rien écraser.

### Corrections

- **Instabilité de la chronologie Claude** : Correction de la chronologie qui grandissait/rétrécissait pendant le défilement, avec des étoiles et le marqueur actif mal positionnés, à cause du DOM de conversation virtualisé de Claude.
- **Application automatique du modèle par défaut** : Correction d'un scintillement occasionnel, de lignes doublement étoilées et d'un vol de focus du champ de saisie lors de l'application automatique du modèle ou du niveau de réflexion par défaut.
- **Barre latérale Gems** : Correction de l'affichage des Gems mis en cache d'un autre compte après un changement de compte Google.
- **Stabilité des dossiers** : Correction d'un ensemble de problèmes, dont des blocages occasionnels à l'envoi de messages et des rendus en double.
- **Bouton de repli de la barre latérale** : Correction du bouton de repli qui ne répondait parfois plus aux clics après redimensionnement de la barre latérale.
- **Tri par utilisation récente des dossiers** : Correction d'un tri instable dans la liste des conversations récentes.
- **Barre d'utilisation Claude** : Correction de la barre qui réapparaissait parfois d'elle-même après avoir été désactivée.
- **Icônes de synchronisation cloud du popup** : Elles correspondent désormais au style du panneau de dossiers.
- **Import/export des prompts** : Restauration des contrôles d'import/export qui avaient disparu du panneau de réglages principal.

---

> *« On rencontre, parmi des milliers et des dizaines de milliers de personnes, celui qu'on devait rencontrer ; parmi des milliers et des dizaines de milliers d'années, dans l'immensité sans limites du temps — ni un pas trop tôt, ni un pas trop tard. » — Eileen Chang*

<!-- lang:es -->

### Novedades

- **Marcas de tiempo reales de los mensajes**: La línea de tiempo ahora muestra la hora real registrada por los servidores de Gemini, en lugar de la hora en que tu dispositivo vio el mensaje por primera vez, corrigiendo horas incorrectas o ausentes al consultar el historial desde otro dispositivo.
- **Gestor de prompts más fácil de descubrir en ChatGPT/Claude**: Un punto en el icono de la barra de herramientas y un interruptor "Activar en este sitio" en el popup te guían hacia el Gestor de prompts; el panel de importación/exportación y sincronización en la nube ahora también funciona directamente en esos sitios.
- **Sincronización en la nube solo para prompts**: Nuevos botones "Extraer (fusionar)" / "Enviar (fusionar)" para sincronizar únicamente tu biblioteca de prompts con Google Drive, fusionando ambos lados sin sobrescribir nada.

### Correcciones

- **Inestabilidad de la línea de tiempo de Claude**: Se corrigió que la línea de tiempo creciera o encogiera al desplazarse, con estrellas y el marcador activo mal ubicados, debido al DOM de conversación virtualizado de Claude.
- **Aplicación automática del modelo predeterminado**: Se corrigió un parpadeo ocasional, filas con doble estrella y el robo de foco del campo de entrada al aplicar automáticamente el modelo o nivel de razonamiento predeterminado.
- **Barra lateral de Gems**: Se corrigió que mostrara los Gems en caché de otra cuenta tras cambiar de cuenta de Google.
- **Estabilidad de carpetas**: Se corrigió un conjunto de problemas, incluidos bloqueos ocasionales al enviar mensajes y renderizados duplicados.
- **Botón de plegado de la barra lateral**: Se corrigió que el botón de plegado a veces no respondiera a los clics tras redimensionar la barra lateral.
- **Orden por uso reciente en carpetas**: Se corrigió un orden inestable en la lista de conversaciones recientes.
- **Barra de uso de Claude**: Se corrigió que a veces reapareciera por sí sola después de desactivarla.
- **Iconos de sincronización en la nube del popup**: Ahora coinciden con el estilo del panel de carpetas.
- **Importación/exportación de prompts**: Se restauraron los controles de importación/exportación que faltaban en el panel de ajustes principal.

---

> *« Entre miles y decenas de miles de personas, te encuentras con quien debías encontrar; entre miles y decenas de miles de años, en la infinita extensión del tiempo — ni un paso antes, ni un paso después. » — Eileen Chang*

<!-- lang:pt -->

### Novidades

- **Carimbos de data/hora reais das mensagens**: A linha do tempo agora mostra a hora real registrada pelos servidores do Gemini, em vez da hora em que seu dispositivo viu a mensagem pela primeira vez, corrigindo horários incorretos ou ausentes ao ver o histórico de outro dispositivo.
- **Gerenciador de prompts mais fácil de encontrar no ChatGPT/Claude**: Um ponto no ícone da barra de ferramentas e um alternador "Ativar neste site" no popup indicam o Gerenciador de prompts; o painel de importação/exportação e sincronização na nuvem agora também funciona diretamente nesses sites.
- **Sincronização na nuvem só de prompts**: Novos botões "Buscar (mesclar)" / "Enviar (mesclar)" para sincronizar apenas sua biblioteca de prompts com o Google Drive, mesclando os dois lados sem sobrescrever nada.

### Correções

- **Instabilidade da linha do tempo do Claude**: Corrigido o crescimento/encolhimento da linha do tempo ao rolar, com estrelas e o marcador ativo mal posicionados, causado pelo DOM de conversa virtualizado do Claude.
- **Aplicação automática do modelo padrão**: Corrigido um piscar ocasional, linhas com estrela dupla e o roubo de foco do campo de entrada ao aplicar automaticamente o modelo ou nível de raciocínio padrão.
- **Barra lateral do Gems**: Corrigido exibir Gems em cache de outra conta após trocar de conta do Google.
- **Estabilidade das pastas**: Corrigido um conjunto de problemas, incluindo travamentos ocasionais ao enviar mensagens e renderizações duplicadas.
- **Botão de recolher a barra lateral**: Corrigido o botão de recolher às vezes não responder a cliques após redimensionar a barra lateral.
- **Ordenação por uso recente nas pastas**: Corrigida uma ordenação instável na lista de conversas recentes.
- **Barra de uso do Claude**: Corrigido reaparecer sozinha às vezes depois de desativada.
- **Ícones de sincronização na nuvem do popup**: Agora combinam com o estilo do painel de pastas.
- **Importação/exportação de prompts**: Restaurados os controles de importação/exportação que estavam ausentes no painel de configurações principal.

---

> *« Entre milhares e dezenas de milhares de pessoas, você encontra aquele que devia encontrar; entre milhares e dezenas de milhares de anos, na vastidão sem fim do tempo — nem um passo antes, nem um passo depois. » — Eileen Chang*

<!-- lang:ar -->

### الجديد

- **طوابع زمنية حقيقية للرسائل**: يعرض الخط الزمني الآن الوقت الفعلي المُسجَّل على خوادم Gemini، بدلاً من الوقت الذي رأى فيه جهازك الرسالة لأول مرة — ما يصلح الأوقات الخاطئة أو المفقودة عند تصفح السجل من جهاز آخر.
- **اكتشاف أسهل لمدير المحفزات على ChatGPT/Claude**: نقطة على أيقونة شريط الأدوات ومفتاح "تفعيل على هذا الموقع" في النافذة المنبثقة يوجهانك إلى مدير المحفزات؛ وأصبحت لوحة الاستيراد/التصدير والمزامنة السحابية تعمل مباشرة على هذين الموقعين أيضًا.
- **مزامنة سحابية خاصة بالمحفزات فقط**: أزرار جديدة "سحب (دمج)" / "دفع (دمج)" لمزامنة مكتبة محفزاتك فقط مع Google Drive، مع دمج الجانبين دون الكتابة فوق أي بيانات.

### الإصلاحات

- **اهتزاز الخط الزمني في Claude**: تم إصلاح تمدد/تقلّص الخط الزمني أثناء التمرير، وسوء موضع النجوم والعلامة النشطة، بسبب DOM المحادثة الافتراضي في Claude.
- **التطبيق التلقائي للنموذج الافتراضي**: تم إصلاح وميض عرضي، وتمييز صفوف بنجمتين، وسرقة تركيز حقل الإدخال عند التطبيق التلقائي للنموذج أو مستوى التفكير الافتراضي.
- **الشريط الجانبي لـ Gems**: تم إصلاح عرض عناصر Gems المخزّنة مؤقتًا من حساب آخر بعد تبديل حساب Google.
- **ثبات المجلدات**: تم إصلاح مجموعة من المشكلات، منها تجمّد عرضي عند إرسال الرسائل وإعادة عرض مكرَّرة.
- **زر طي الشريط الجانبي**: تم إصلاح عدم استجابة زر الطي أحيانًا للنقر بعد تغيير عرض الشريط الجانبي.
- **ترتيب الاستخدام الأخير للمجلدات**: تم إصلاح ترتيب غير مستقر في قائمة المحادثات الأخيرة.
- **شريط استخدام Claude**: تم إصلاح ظهوره من تلقاء نفسه أحيانًا بعد تعطيله.
- **أيقونات المزامنة السحابية في النافذة المنبثقة**: أصبحت مطابقة لنمط لوحة المجلدات.
- **استيراد/تصدير المحفزات**: تمت استعادة عناصر التحكم بالاستيراد/التصدير التي كانت مفقودة من لوحة الإعدادات الرئيسية.

---

> *«بين آلاف وعشرات آلاف البشر، تلتقي بمن كان عليك أن تلتقيه؛ وبين آلاف وعشرات آلاف السنين، في برية الزمن التي لا حدود لها — لا خطوة أبكر، ولا خطوة أبطأ.» — إيلين تشانغ*

<!-- lang:ko -->

### 새로운 기능

- **실제 메시지 타임스탬프**: 타임라인이 이제 기기가 메시지를 처음 감지한 시각이 아니라 Gemini 서버에 기록된 실제 전송 시각을 표시합니다. 다른 기기의 기록을 볼 때 시각이 틀리거나 표시되지 않던 문제를 수정했습니다.
- **ChatGPT/Claude에서 프롬프트 매니저를 더 쉽게 찾을 수 있음**: 이 사이트를 방문하면 툴바 아이콘에 점이 표시되고 팝업에 "이 사이트에서 활성화" 토글이 나타나 프롬프트 매니저로 안내합니다. 활성화 후에는 가져오기/내보내기 및 클라우드 동기화 패널도 이 사이트에서 바로 사용할 수 있습니다.
- **프롬프트 전용 클라우드 동기화**: Google 드라이브에 프롬프트 라이브러리만 동기화하는 "가져오기(병합)" / "보내기(병합)" 버튼을 추가했습니다. 양쪽을 병합하며 데이터를 덮어쓰지 않습니다.

### 수정

- **Claude 타임라인 흔들림**: Claude의 가상화된 대화 DOM 때문에 스크롤 시 타임라인이 늘었다 줄었다 하고 별표와 현재 위치 표시가 잘못되던 문제를 수정했습니다.
- **기본 모델 자동 적용**: 기본 모델/사고 강도를 자동 적용할 때 간헐적으로 화면이 깜빡이고, 별표가 이중으로 표시되고, 입력창 포커스를 빼앗던 문제를 수정했습니다.
- **Gems 사이드바**: Google 계정을 전환한 후 사이드바에 이전 계정의 캐시된 Gems가 계속 표시되던 문제를 수정했습니다.
- **폴더 안정성**: 메시지 전송이 간헐적으로 멈추거나 화면이 중복 렌더링되는 등 여러 문제를 수정했습니다.
- **사이드바 접기 버튼**: 사이드바 너비를 조절한 후 접기 버튼이 가끔 클릭에 반응하지 않던 문제를 수정했습니다.
- **폴더 최근 사용 순 정렬**: 최근 대화 목록의 정렬이 불안정하던 문제를 수정했습니다.
- **Claude 사용량 막대**: 비활성화한 뒤에도 가끔 저절로 다시 나타나던 문제를 수정했습니다.
- **팝업 클라우드 동기화 아이콘**: 폴더 패널과 동일한 스타일로 통일했습니다.
- **프롬프트 가져오기/내보내기**: 메인 설정 패널에서 사라졌던 가져오기/내보내기 기능을 복원했습니다.

---

> *"수천수만 사람들 가운데서 만나야 할 사람을 만나고, 수천수만 년의 세월 가운데서, 가없는 시간의 광야 속에서 — 한 걸음도 이르지 않고, 한 걸음도 늦지 않게." — 장아이링(張愛玲)*

<!-- lang:ru -->

### Новое

- **Реальные метки времени сообщений**: Временная шкала теперь показывает время, зафиксированное на серверах Gemini, а не момент, когда ваше устройство впервые увидело сообщение — это исправляет неверное или отсутствующее время при просмотре истории с другого устройства.
- **Менеджер промптов проще найти на ChatGPT/Claude**: Точка на значке панели инструментов и переключатель «Включить на этом сайте» во всплывающем окне указывают на Менеджер промптов; панель импорта/экспорта и облачной синхронизации теперь работает прямо на этих сайтах.
- **Облачная синхронизация только промптов**: Новые кнопки «Получить (слияние)» / «Отправить (слияние)» синхронизируют только вашу библиотеку промптов с Google Диском, объединяя обе стороны без перезаписи данных.

### Исправления

- **Дрожание временной шкалы Claude**: Исправлено разрастание/сжатие временной шкалы при прокрутке и смещение звёзд и активного маркера из-за виртуализированного DOM переписки в Claude.
- **Автоприменение модели по умолчанию**: Исправлено случайное мерцание, двойная подсветка звёздочкой и перехват фокуса поля ввода при автоприменении модели или уровня рассуждений по умолчанию.
- **Боковая панель Gems**: Исправлено отображение кэшированных Gems от другого аккаунта после переключения аккаунта Google.
- **Стабильность папок**: Исправлен ряд проблем, включая случайные зависания при отправке сообщений и дублирующийся рендеринг.
- **Кнопка сворачивания боковой панели**: Исправлено, что кнопка сворачивания иногда не реагировала на клики после изменения ширины боковой панели.
- **Сортировка папок по недавнему использованию**: Исправлена нестабильная сортировка в списке недавних переписок.
- **Панель использования Claude**: Исправлено её случайное самопроизвольное появление после отключения.
- **Иконки облачной синхронизации во всплывающем окне**: Теперь соответствуют стилю панели папок.
- **Импорт/экспорт промптов**: Восстановлены элементы управления импортом/экспортом, пропавшие с главной панели настроек.

---

> *«Среди тысяч и десятков тысяч людей встречаешь того, кого должен встретить; среди тысяч и десятков тысяч лет, в бескрайней пустыне времени — не на шаг раньше, не на шаг позже.» — Эйлин Чжан*
`;export{e as default};
