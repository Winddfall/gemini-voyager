const e=`<!-- lang:en -->

> Voyager is back on the Chrome Web Store! If you know someone who lost the extension after the takedown, share the link and help them find their way home. 🚀

### What's New

- **User-message LaTeX rendering**: Math formulas in your own messages are now rendered via KaTeX.
- **Notion-compatible formula copy**: Copy formulas in a format that pastes correctly into Notion.
- **Per-message timestamps**: See the exact sent time for each message in both chat and timeline.
- **Popup section reorder**: Rearrange popup sections with up/down buttons to match your workflow.

### Fixes

- **Quote Reply IME**: The first keystroke after quoting no longer bypasses Chinese/Japanese/Korean input methods.
- **Empty folders**: Folders without conversations now stay visible when a user filter is active.
- **Visual effect selection**: The selected visual effect (rain/sakura/snow) is correctly restored on popup reload.
- **Prompt Manager shadow**: Removed a stray gradient shadow on collapsed prompt text.
- **Hide-input focus**: Resolved focus interference and improved selector performance.

<!-- lang:zh -->

> Voyager 已重新上架 Chrome 商店！如果你身边有因下架而失联的老用户，分享一下链接，帮他们回家吧 🚀

### 新功能

- **用户消息 LaTeX 渲染**：你发送的消息中的数学公式现在会通过 KaTeX 渲染。
- **Notion 兼容公式复制**：复制的公式可以正确粘贴到 Notion 中。
- **逐条消息时间戳**：在聊天和时间线中查看每条消息的精确发送时间。
- **弹窗分区排序**：使用上/下按钮重新排列弹窗中的各分区，适配你的工作流。

### 修复

- **引用回复输入法**：引用后的第一个按键不再跳过中文/日文/韩文输入法。
- **空文件夹**：启用用户筛选时，没有对话的文件夹不会再消失。
- **视觉效果选择**：重新加载弹窗后，已选的视觉效果（雨/樱花/雪）能正确恢复。
- **提示词管理器阴影**：移除了折叠提示词文本上多余的渐变阴影。
- **隐藏输入框焦点**：修复了焦点干扰问题并优化了选择器性能。

<!-- lang:zh_TW -->

> Voyager 已重新上架 Chrome 商店！如果你身邊有因下架而失聯的老使用者，分享一下連結，幫他們回家吧 🚀

### 新功能

- **使用者訊息 LaTeX 渲染**：你傳送的訊息中的數學公式現在會透過 KaTeX 渲染。
- **Notion 相容公式複製**：複製的公式可以正確貼上到 Notion 中。
- **逐條訊息時間戳記**：在聊天和時間線中檢視每條訊息的精確傳送時間。
- **彈窗分區排序**：使用上/下按鈕重新排列彈窗中的各分區，適配你的工作流程。

### 修復

- **引用回覆輸入法**：引用後的第一個按鍵不再跳過中文/日文/韓文輸入法。
- **空資料夾**：啟用使用者篩選時，沒有對話的資料夾不會再消失。
- **視覺效果選擇**：重新載入彈窗後，已選的視覺效果（雨/櫻花/雪）能正確恢復。
- **提示詞管理器陰影**：移除了摺疊提示詞文字上多餘的漸層陰影。
- **隱藏輸入框焦點**：修復了焦點干擾問題並最佳化了選擇器效能。

<!-- lang:ja -->

> Voyager が Chrome ウェブストアに復活しました！削除で見失った方がいたら、リンクをシェアして呼び戻してあげてください 🚀

### 新機能

- **ユーザーメッセージの LaTeX レンダリング**：送信メッセージ内の数式が KaTeX でレンダリングされるようになりました。
- **Notion 互換の数式コピー**：Notion に正しく貼り付けられる形式で数式をコピーできます。
- **メッセージごとのタイムスタンプ**：チャットとタイムラインで各メッセージの正確な送信時刻を確認できます。
- **ポップアップセクションの並べ替え**：上下ボタンでポップアップのセクション順序をカスタマイズできます。

### 修正

- **引用返信の IME**：引用後の最初のキー入力が中国語/日本語/韓国語入力メソッドをバイパスしなくなりました。
- **空フォルダ**：ユーザーフィルターが有効な場合でも、会話のないフォルダが表示されるようになりました。
- **ビジュアルエフェクト選択**：ポップアップ再読み込み時に選択したエフェクト（雨/桜/雪）が正しく復元されます。
- **プロンプトマネージャーの影**：折りたたまれたプロンプトテキストの余分なグラデーションシャドウを削除しました。
- **入力欄非表示のフォーカス**：フォーカス干渉の問題を修正し、セレクターのパフォーマンスを改善しました。

<!-- lang:fr -->

> Voyager est de retour sur le Chrome Web Store ! Si vous connaissez quelqu'un qui a perdu l'extension après le retrait, partagez le lien pour les aider à revenir 🚀

### Nouveautés

- **Rendu LaTeX des messages utilisateur** : Les formules mathématiques dans vos messages sont désormais rendues via KaTeX.
- **Copie de formules compatible Notion** : Copiez les formules dans un format qui se colle correctement dans Notion.
- **Horodatages par message** : Consultez l'heure d'envoi exacte de chaque message dans le chat et la timeline.
- **Réorganisation des sections du popup** : Réarrangez les sections du popup avec les boutons haut/bas.

### Corrections

- **IME de la citation** : La première frappe après une citation ne contourne plus les méthodes de saisie chinoise/japonaise/coréenne.
- **Dossiers vides** : Les dossiers sans conversations restent visibles lorsqu'un filtre utilisateur est actif.
- **Sélection d'effet visuel** : L'effet visuel sélectionné (pluie/sakura/neige) est correctement restauré au rechargement du popup.
- **Ombre du gestionnaire de prompts** : Suppression d'une ombre de dégradé parasite sur le texte de prompt réduit.
- **Focus de la saisie masquée** : Résolution de l'interférence de focus et amélioration des performances du sélecteur.

<!-- lang:es -->

> ¡Voyager ha vuelto a la Chrome Web Store! Si conoces a alguien que perdió la extensión tras la retirada, comparte el enlace y ayúdale a volver 🚀

### Novedades

- **Renderizado LaTeX en mensajes del usuario**: Las fórmulas matemáticas en tus mensajes ahora se renderizan mediante KaTeX.
- **Copia de fórmulas compatible con Notion**: Copia fórmulas en un formato que se pega correctamente en Notion.
- **Marcas de tiempo por mensaje**: Consulta la hora exacta de envío de cada mensaje en el chat y la línea de tiempo.
- **Reordenación de secciones del popup**: Reorganiza las secciones del popup con los botones arriba/abajo.

### Correcciones

- **IME en cita y respuesta**: La primera pulsación tras citar ya no omite los métodos de entrada chino/japonés/coreano.
- **Carpetas vacías**: Las carpetas sin conversaciones permanecen visibles cuando hay un filtro de usuario activo.
- **Selección de efecto visual**: El efecto visual seleccionado (lluvia/sakura/nieve) se restaura correctamente al recargar el popup.
- **Sombra del gestor de prompts**: Se eliminó una sombra de degradado en el texto de prompt contraído.
- **Foco de entrada oculta**: Se resolvió la interferencia de foco y se mejoró el rendimiento del selector.

<!-- lang:pt -->

> O Voyager está de volta na Chrome Web Store! Se conhece alguém que perdeu a extensão após a remoção, partilhe o link e ajude-o a regressar 🚀

### Novidades

- **Renderização LaTeX em mensagens do utilizador**: As fórmulas matemáticas nas suas mensagens são agora renderizadas via KaTeX.
- **Cópia de fórmulas compatível com Notion**: Copie fórmulas num formato que cola corretamente no Notion.
- **Carimbos de data/hora por mensagem**: Veja a hora exata de envio de cada mensagem no chat e na linha do tempo.
- **Reordenação de secções do popup**: Reorganize as secções do popup com os botões cima/baixo.

### Correções

- **IME na citação e resposta**: O primeiro toque após citar já não ignora os métodos de entrada chinês/japonês/coreano.
- **Pastas vazias**: As pastas sem conversas permanecem visíveis quando um filtro de utilizador está ativo.
- **Seleção de efeito visual**: O efeito visual selecionado (chuva/sakura/neve) é corretamente restaurado ao recarregar o popup.
- **Sombra do gestor de prompts**: Removida uma sombra de degradê no texto de prompt recolhido.
- **Foco da entrada oculta**: Resolvida a interferência de foco e melhorado o desempenho do seletor.

<!-- lang:ar -->

> عاد Voyager إلى Chrome Web Store! إذا كنت تعرف شخصًا فقد الإضافة بعد الإزالة، شارك الرابط وساعده على العودة 🚀

### الجديد

- **عرض LaTeX في رسائل المستخدم**: يتم الآن عرض الصيغ الرياضية في رسائلك عبر KaTeX.
- **نسخ صيغ متوافق مع Notion**: انسخ الصيغ بتنسيق يُلصق بشكل صحيح في Notion.
- **طوابع زمنية لكل رسالة**: شاهد وقت الإرسال الدقيق لكل رسالة في الدردشة والخط الزمني.
- **إعادة ترتيب أقسام النافذة المنبثقة**: أعد ترتيب الأقسام باستخدام أزرار أعلى/أسفل.

### الإصلاحات

- **محرر الإدخال عند الاقتباس**: لم يعد الضغط الأول بعد الاقتباس يتجاوز طرق الإدخال الصينية/اليابانية/الكورية.
- **المجلدات الفارغة**: تظل المجلدات بدون محادثات مرئية عند تفعيل فلتر المستخدم.
- **اختيار التأثير البصري**: يتم استعادة التأثير البصري المحدد (مطر/ساكورا/ثلج) بشكل صحيح عند إعادة تحميل النافذة المنبثقة.
- **ظل مدير الأوامر**: تمت إزالة ظل التدرج الزائد على نص الأمر المطوي.
- **تركيز الإدخال المخفي**: تم حل تداخل التركيز وتحسين أداء المحدد.

<!-- lang:ko -->

> Voyager가 Chrome 웹 스토어에 돌아왔습니다! 삭제로 확장 프로그램을 잃은 분이 있다면, 링크를 공유해서 다시 찾을 수 있도록 도와주세요 🚀

### 새로운 기능

- **사용자 메시지 LaTeX 렌더링**: 보낸 메시지의 수학 공식이 이제 KaTeX로 렌더링됩니다.
- **Notion 호환 수식 복사**: Notion에 올바르게 붙여넣기되는 형식으로 수식을 복사할 수 있습니다.
- **메시지별 타임스탬프**: 채팅과 타임라인에서 각 메시지의 정확한 전송 시간을 확인할 수 있습니다.
- **팝업 섹션 재정렬**: 위/아래 버튼으로 팝업 섹션 순서를 사용자 정의할 수 있습니다.

### 수정

- **인용 답장 IME**: 인용 후 첫 번째 키 입력이 더 이상 중국어/일본어/한국어 입력기를 우회하지 않습니다.
- **빈 폴더**: 사용자 필터가 활성화된 경우에도 대화가 없는 폴더가 표시됩니다.
- **시각 효과 선택**: 팝업 새로고침 시 선택한 시각 효과(비/벚꽃/눈)가 올바르게 복원됩니다.
- **프롬프트 매니저 그림자**: 접힌 프롬프트 텍스트의 불필요한 그라데이션 그림자를 제거했습니다.
- **숨김 입력 포커스**: 포커스 간섭 문제를 해결하고 선택자 성능을 개선했습니다.

<!-- lang:ru -->

> Voyager снова в Chrome Web Store! Если вы знаете кого-то, кто потерял расширение после удаления, поделитесь ссылкой и помогите им вернуться 🚀

### Новое

- **Рендеринг LaTeX в сообщениях пользователя**: Математические формулы в ваших сообщениях теперь отображаются через KaTeX.
- **Копирование формул, совместимое с Notion**: Копируйте формулы в формате, который корректно вставляется в Notion.
- **Временные метки для каждого сообщения**: Просматривайте точное время отправки каждого сообщения в чате и на временной шкале.
- **Перестановка секций попапа**: Переставляйте секции попапа кнопками вверх/вниз под свой рабочий процесс.

### Исправления

- **IME при цитировании**: Первое нажатие после цитирования больше не обходит методы ввода китайского/японского/корейского.
- **Пустые папки**: Папки без бесед остаются видимыми при активном фильтре пользователя.
- **Выбор визуального эффекта**: Выбранный визуальный эффект (дождь/сакура/снег) корректно восстанавливается при перезагрузке попапа.
- **Тень менеджера промптов**: Удалена лишняя градиентная тень на свёрнутом тексте промпта.
- **Фокус скрытого ввода**: Устранена интерференция фокуса и улучшена производительность селектора.
`;export{e as default};
