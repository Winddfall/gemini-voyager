const e=`<!-- lang:en -->

### What's New

- **Default model kill switch**: The on/off toggle in popup settings now takes effect instantly — no page reload needed. Also fixes multiple stars appearing in the model menu and shows a failure toast after repeated lock failures.
- **Persistent export toolbar**: When Gemini hides the native menu anchor, a fallback export toolbar appears in the top-right corner. Can be toggled off in General Options.

### Fixes

- **Export entries after Gemini lr26**: Export buttons restored in conversation and response menus after Gemini replaced its internal menu component.
- **Watermark download**: Watermark auto-processing handles Gemini's new redirect-based download chain.
- **Sidebar Recents recovery**: Removed the Recents hide toggle that could permanently lock users out of their Recents list with no visible recovery.
- **Gems sidebar refresh**: The gems list in the sidebar now re-injects reliably after navigation.
- **Folder sidebar performance**: Sidebar clicks are no longer janky when folders are enabled.
- **Safari update checks**: Safari users now receive release update notifications.

<!-- lang:zh -->

### 新功能

- **默认模型开关**：弹窗设置中的开关现在即时生效，无需刷新页面。同时修复了模型菜单中出现多个星标的问题，并在多次锁定失败后显示提示。
- **常驻导出工具栏**：当 Gemini 隐藏了原生菜单锚点时，右上角会出现备用导出工具栏。可在"常规选项"中关闭。

### 修复

- **Gemini lr26 导出按钮**：Gemini 更换内部菜单组件后，对话和回复菜单中的导出按钮已恢复。
- **水印下载**：水印自动处理已适配 Gemini 新的重定向下载链路。
- **侧边栏 Recents 恢复**：移除了可能导致用户永久丢失 Recents 列表且无法恢复的隐藏开关。
- **Gems 侧边栏刷新**：侧边栏中的 gems 列表现在可在导航后可靠重新注入。
- **文件夹侧边栏性能**：启用文件夹后，侧边栏点击不再卡顿。
- **Safari 更新检查**：Safari 用户现在可以收到版本更新通知。

<!-- lang:zh_TW -->

### 新功能

- **預設模型開關**：彈窗設定中的開關現在即時生效，無需重新整理頁面。同時修復了模型選單中出現多個星標的問題，並在多次鎖定失敗後顯示提示。
- **常駐匯出工具列**：當 Gemini 隱藏了原生選單錨點時，右上角會出現備用匯出工具列。可在「一般選項」中關閉。

### 修復

- **Gemini lr26 匯出按鈕**：Gemini 更換內部選單元件後，對話和回覆選單中的匯出按鈕已恢復。
- **浮水印下載**：浮水印自動處理已適配 Gemini 新的重新導向下載鏈路。
- **側邊欄 Recents 恢復**：移除了可能導致使用者永久遺失 Recents 列表且無法恢復的隱藏開關。
- **Gems 側邊欄重新整理**：側邊欄中的 gems 列表現在可在導覽後可靠重新注入。
- **資料夾側邊欄效能**：啟用資料夾後，側邊欄點擊不再卡頓。
- **Safari 更新檢查**：Safari 使用者現在可以收到版本更新通知。

<!-- lang:ja -->

### 新機能

- **デフォルトモデルのキルスイッチ**：ポップアップ設定のオン/オフ切替がページリロードなしで即座に反映されます。モデルメニューにスターが複数表示される問題も修正し、ロック失敗が続いた際にトーストで通知します。
- **常設エクスポートツールバー**：Gemini がネイティブメニューのアンカーを隠した場合、右上にフォールバックのエクスポートツールバーが表示されます。「一般オプション」でオフにできます。

### 修正

- **Gemini lr26 後のエクスポート項目**：Gemini が内部メニューコンポーネントを刷新した後、会話・応答メニューのエクスポートボタンが復活しました。
- **ウォーターマークのダウンロード**：ウォーターマーク自動処理が Gemini の新しいリダイレクト方式のダウンロードチェーンに対応しました。
- **サイドバー Recents の復旧**：Recents リストが永久に非表示になり復旧不能になるトグルを削除しました。
- **Gems サイドバーの再注入**：サイドバーの gems リストがナビゲーション後も確実に再注入されます。
- **フォルダサイドバーのパフォーマンス**：フォルダ有効時のサイドバークリックのカクつきが解消されました。
- **Safari の更新チェック**：Safari ユーザーにリリース更新通知が届くようになりました。

<!-- lang:fr -->

### Nouveautés

- **Interrupteur du modèle par défaut** : Le bouton on/off dans les paramètres du popup prend effet instantanément, sans recharger la page. Corrige aussi l'apparition de plusieurs étoiles dans le menu des modèles et affiche un avertissement après des échecs répétés de verrouillage.
- **Barre d'outils d'export permanente** : Quand Gemini masque l'ancre du menu natif, une barre d'outils d'export de secours apparaît en haut à droite. Désactivable dans les Options générales.

### Corrections

- **Boutons d'export après Gemini lr26** : Les boutons d'export restaurés dans les menus de conversation et de réponse après le remplacement du composant de menu interne de Gemini.
- **Téléchargement du filigrane** : Le traitement automatique du filigrane gère la nouvelle chaîne de téléchargement par redirection de Gemini.
- **Récupération de Recents dans la barre latérale** : Suppression du bouton de masquage de Recents qui pouvait bloquer définitivement l'accès à la liste sans possibilité de récupération.
- **Actualisation de Gems dans la barre latérale** : La liste des gems se réinjecte correctement après chaque navigation.
- **Performance de la barre latérale des dossiers** : Les clics dans la barre latérale ne provoquent plus de saccades lorsque les dossiers sont activés.
- **Vérifications de mise à jour Safari** : Les utilisateurs Safari reçoivent désormais les notifications de mise à jour.

<!-- lang:es -->

### Novedades

- **Interruptor del modelo predeterminado**: El botón on/off en los ajustes del popup surte efecto al instante, sin recargar la página. También corrige la aparición de múltiples estrellas en el menú de modelos y muestra un aviso tras fallos repetidos de bloqueo.
- **Barra de exportación permanente**: Cuando Gemini oculta el ancla del menú nativo, aparece una barra de exportación de respaldo en la esquina superior derecha. Se puede desactivar en Opciones generales.

### Correcciones

- **Botones de exportación tras Gemini lr26**: Los botones de exportación se restauraron en los menús de conversación y respuesta tras el cambio del componente de menú interno de Gemini.
- **Descarga de marca de agua**: El procesamiento automático de marcas de agua maneja la nueva cadena de descarga por redirección de Gemini.
- **Recuperación de Recents en la barra lateral**: Se eliminó el botón para ocultar Recents que podía bloquear permanentemente la lista sin forma de recuperarla.
- **Actualización de Gems en la barra lateral**: La lista de gems se reinyecta correctamente tras cada navegación.
- **Rendimiento de la barra lateral de carpetas**: Los clics en la barra lateral ya no producen tirones con las carpetas activadas.
- **Comprobaciones de actualización en Safari**: Los usuarios de Safari ahora reciben notificaciones de actualización.

<!-- lang:pt -->

### Novidades

- **Interruptor do modelo padrão**: O botão on/off nas configurações do popup agora tem efeito instantâneo, sem recarregar a página. Também corrige o aparecimento de múltiplas estrelas no menu de modelos e exibe um aviso após falhas repetidas de bloqueio.
- **Barra de exportação permanente**: Quando o Gemini oculta a âncora do menu nativo, uma barra de exportação reserva aparece no canto superior direito. Pode ser desativada em Opções gerais.

### Correções

- **Botões de exportação após Gemini lr26**: Os botões de exportação foram restaurados nos menus de conversa e resposta após a substituição do componente de menu interno do Gemini.
- **Download de marca d'água**: O processamento automático de marca d'água lida com a nova cadeia de download por redirecionamento do Gemini.
- **Recuperação de Recents na barra lateral**: Removido o botão de ocultar Recents que podia bloquear permanentemente a lista sem possibilidade de recuperação.
- **Atualização de Gems na barra lateral**: A lista de gems se reinjecta de forma confiável após cada navegação.
- **Desempenho da barra lateral de pastas**: Cliques na barra lateral não causam mais travamentos com as pastas ativadas.
- **Verificações de atualização no Safari**: Usuários do Safari agora recebem notificações de atualização.

<!-- lang:ar -->

### الجديد

- **مفتاح إيقاف النموذج الافتراضي**: زر التشغيل/الإيقاف في إعدادات النافذة المنبثقة يسري فورًا دون إعادة تحميل الصفحة. يُصلح أيضًا ظهور نجوم متعددة في قائمة النماذج، ويعرض تنبيهًا بعد فشل القفل المتكرر.
- **شريط أدوات التصدير الدائم**: عندما يخفي Gemini مرساة القائمة الأصلية، يظهر شريط أدوات تصدير احتياطي في الزاوية العلوية اليمنى. يمكن إيقافه من الخيارات العامة.

### الإصلاحات

- **أزرار التصدير بعد Gemini lr26**: استُعيدت أزرار التصدير في قوائم المحادثة والردود بعد استبدال Gemini لمكوّن القائمة الداخلي.
- **تنزيل العلامة المائية**: تتعامل المعالجة التلقائية للعلامة المائية مع سلسلة التنزيل الجديدة القائمة على إعادة التوجيه.
- **استرداد Recents في الشريط الجانبي**: أُزيل زر إخفاء Recents الذي كان يمكن أن يحجب القائمة نهائيًا دون طريقة للاسترداد.
- **تحديث Gems في الشريط الجانبي**: تُعاد حقن قائمة gems بشكل موثوق بعد كل تنقّل.
- **أداء الشريط الجانبي للمجلدات**: لم تعد النقرات في الشريط الجانبي تتلعثم عند تفعيل المجلدات.
- **فحوصات تحديث Safari**: يتلقّى مستخدمو Safari الآن إشعارات تحديث الإصدار.

<!-- lang:ko -->

### 새로운 기능

- **기본 모델 킬 스위치**: 팝업 설정의 온/오프 토글이 페이지 새로고침 없이 즉시 반영됩니다. 모델 메뉴에 별표가 여러 개 나타나는 문제도 수정하고, 잠금 실패가 반복되면 토스트로 알려줍니다.
- **상시 내보내기 툴바**: Gemini가 기본 메뉴 앵커를 숨기면 우측 상단에 대체 내보내기 툴바가 나타납니다. 일반 옵션에서 끌 수 있습니다.

### 수정

- **Gemini lr26 이후 내보내기 버튼**: Gemini가 내부 메뉴 컴포넌트를 교체한 후 대화 및 응답 메뉴의 내보내기 버튼이 복원되었습니다.
- **워터마크 다운로드**: 워터마크 자동 처리가 Gemini의 새로운 리다이렉트 기반 다운로드 체인에 대응합니다.
- **사이드바 Recents 복구**: Recents 목록을 영구적으로 숨겨 복구 불가능하게 만들 수 있던 숨기기 토글을 제거했습니다.
- **Gems 사이드바 새로고침**: 사이드바의 gems 목록이 내비게이션 후 안정적으로 재주입됩니다.
- **폴더 사이드바 성능**: 폴더가 활성화된 상태에서 사이드바 클릭 시 버벅거림이 해소되었습니다.
- **Safari 업데이트 확인**: Safari 사용자에게 릴리스 업데이트 알림이 전달됩니다.

<!-- lang:ru -->

### Новое

- **Выключатель модели по умолчанию**: Переключатель вкл/выкл в настройках попапа применяется мгновенно, без перезагрузки страницы. Также исправляет появление нескольких звёздочек в меню моделей и показывает уведомление после повторных неудач блокировки.
- **Постоянная панель экспорта**: Когда Gemini скрывает якорь нативного меню, в правом верхнем углу появляется резервная панель экспорта. Можно отключить в общих настройках.

### Исправления

- **Кнопки экспорта после Gemini lr26**: Кнопки экспорта восстановлены в меню диалогов и ответов после замены внутреннего компонента меню Gemini.
- **Загрузка водяного знака**: Автоматическая обработка водяного знака работает с новой цепочкой загрузки через перенаправление.
- **Восстановление Recents в боковой панели**: Удалён переключатель скрытия Recents, который мог навсегда заблокировать доступ к списку без возможности восстановления.
- **Обновление Gems в боковой панели**: Список gems в боковой панели надёжно повторно внедряется после навигации.
- **Производительность боковой панели папок**: Клики в боковой панели больше не притормаживают при включённых папках.
- **Проверка обновлений в Safari**: Пользователи Safari теперь получают уведомления об обновлениях.
`;export{e as default};
