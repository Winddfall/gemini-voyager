const e=`<!-- lang:en -->

### What's New

- **Draft auto-save** *(off by default)*: Your unsent input is automatically saved and restored when you return to a conversation.
- **Chat font size** *(off by default)*: Adjust the font size of chat messages (80%–150%) from the popup. [→ Docs](/guide/chat-font-size)
- **gg / GG shortcuts**: Vim-style jump to the first or last turn in a conversation. [→ Docs](/guide/timeline)
- **Table width stretch**: Tables now expand to match your chat width setting.

### Fixes

- **Image export**: Fixed rendering failures caused by XML-illegal control characters in chat content.
- **Timeline timestamps**: First-turn timestamps are preserved during route changes; dot elements no longer twitch on hover.
- **Cloud sync on Brave**: Eliminated the error popup that appeared on Brave due to unsupported auth token calls.
- **Popup icons**: Material Symbols font is now bundled locally to avoid proxy/firewall conflicts.

<!-- lang:zh -->

### 新功能

- **草稿自动保存** *（默认关闭）*：未发送的输入内容会自动保存，切回对话时自动恢复。
- **聊天字号调节** *（默认关闭）*：在弹窗中调整聊天消息的字体大小（80%–150%）。[→ 文档](/guide/chat-font-size)
- **gg / GG 快捷键**：Vim 风格跳转到对话的第一轮或最后一轮。[→ 文档](/guide/timeline)
- **表格宽度拉伸**：表格现在会跟随聊天宽度设置自动展开。
### 修复

- **图片导出**：修复了聊天内容中含有非法 XML 控制字符导致渲染失败的问题。
- **时间线时间戳**：路由切换时保留首轮时间戳；悬停时圆点不再抖动。
- **Brave 云同步**：消除了 Brave 浏览器中因不支持的 auth token 调用弹出的错误窗口。
- **弹窗图标**：Material Symbols 字体改为本地打包，避免代理/防火墙冲突。

<!-- lang:zh_TW -->

### 新功能

- **草稿自動儲存** *（預設關閉）*：未傳送的輸入內容會自動儲存，切回對話時自動恢復。
- **聊天字型大小調整** *（預設關閉）*：在彈窗中調整聊天訊息的字型大小（80%–150%）。[→ 文件](/guide/chat-font-size)
- **gg / GG 快捷鍵**：Vim 風格跳轉到對話的第一輪或最後一輪。[→ 文件](/guide/timeline)
- **表格寬度延伸**：表格現在會跟隨聊天寬度設定自動展開。[→ 文件](/guide/settings)

### 修復

- **圖片匯出**：修復了聊天內容中含有非法 XML 控制字元導致渲染失敗的問題。
- **時間線時間戳記**：路由切換時保留首輪時間戳記；懸停時圓點不再抖動。
- **Brave 雲端同步**：消除了 Brave 瀏覽器中因不支援的 auth token 呼叫彈出的錯誤視窗。
- **彈窗圖示**：Material Symbols 字型改為本機打包，避免代理/防火牆衝突。

<!-- lang:ja -->

### 新機能

- **下書き自動保存** *（デフォルトOFF）*：未送信の入力内容が自動保存され、会話に戻ると復元されます。
- **チャットフォントサイズ** *（デフォルトOFF）*：ポップアップからチャットメッセージのフォントサイズ（80%–150%）を調整できます。[→ ドキュメント](/guide/chat-font-size)
- **gg / GG ショートカット**：Vim スタイルで会話の最初または最後のターンにジャンプします。[→ ドキュメント](/guide/timeline)
- **テーブル幅の拡張**：テーブルがチャット幅の設定に合わせて拡張されるようになりました。
### 修正

- **画像エクスポート**：チャット内容に含まれる XML 不正制御文字によるレンダリング失敗を修正しました。
- **タイムラインのタイムスタンプ**：ルート変更時に最初のターンのタイムスタンプが保持されるようになり、ホバー時のドットのちらつきも解消しました。
- **Brave でのクラウド同期**：サポートされていない認証トークン呼び出しによるエラーポップアップを解消しました。
- **ポップアップアイコン**：Material Symbols フォントをローカルにバンドルし、プロキシ/ファイアウォールの競合を回避します。

<!-- lang:fr -->

### Nouveautés

- **Sauvegarde automatique des brouillons** *(désactivé par défaut)* : Votre saisie non envoyée est automatiquement sauvegardée et restaurée lorsque vous revenez à une conversation.
- **Taille de police du chat** *(désactivé par défaut)* : Ajustez la taille de police des messages (80%–150%) depuis le popup. [→ Documentation](/guide/chat-font-size)
- **Raccourcis gg / GG** : Navigation Vim pour sauter au premier ou dernier tour d'une conversation. [→ Documentation](/guide/timeline)
- **Largeur des tableaux** : Les tableaux s'étendent désormais pour correspondre à votre réglage de largeur de chat. 
### Corrections

- **Export d'image** : Correction des échecs de rendu causés par des caractères de contrôle XML illégaux dans le contenu du chat.
- **Horodatages de la timeline** : Les horodatages du premier tour sont conservés lors des changements de route ; les points ne tremblent plus au survol.
- **Synchronisation cloud sur Brave** : Suppression du popup d'erreur lié aux appels de jeton d'authentification non supportés.
- **Icônes du popup** : La police Material Symbols est désormais intégrée localement pour éviter les conflits de proxy/pare-feu.

<!-- lang:es -->

### Novedades

- **Guardado automático de borradores** *(desactivado por defecto)*: Tu entrada no enviada se guarda automáticamente y se restaura al volver a la conversación.
- **Tamaño de fuente del chat** *(desactivado por defecto)*: Ajusta el tamaño de fuente de los mensajes (80%–150%) desde el popup. [→ Documentación](/guide/chat-font-size)
- **Atajos gg / GG**: Salto estilo Vim al primer o último turno de una conversación. [→ Documentación](/guide/timeline)
- **Ancho de tablas**: Las tablas ahora se expanden para coincidir con tu configuración de ancho de chat. 
### Correcciones

- **Exportación de imagen**: Corregidos fallos de renderizado causados por caracteres de control XML ilegales en el contenido del chat.
- **Marcas de tiempo de la línea de tiempo**: Las marcas de tiempo del primer turno se conservan durante los cambios de ruta; los puntos ya no tiemblan al pasar el cursor.
- **Sincronización en la nube en Brave**: Eliminado el popup de error causado por llamadas de token de autenticación no soportadas.
- **Iconos del popup**: La fuente Material Symbols ahora se incluye localmente para evitar conflictos con proxy/firewall.

<!-- lang:pt -->

### Novidades

- **Guardar rascunhos automaticamente** *(desativado por padrão)*: O seu texto não enviado é guardado automaticamente e restaurado quando regressa à conversa.
- **Tamanho de letra do chat** *(desativado por padrão)*: Ajuste o tamanho de letra das mensagens (80%–150%) a partir do popup. [→ Documentação](/guide/chat-font-size)
- **Atalhos gg / GG**: Salto estilo Vim para o primeiro ou último turno de uma conversa. [→ Documentação](/guide/timeline)
- **Largura das tabelas**: As tabelas expandem-se agora para corresponder à sua definição de largura do chat. 
### Correções

- **Exportação de imagem**: Corrigidas falhas de renderização causadas por caracteres de controlo XML ilegais no conteúdo do chat.
- **Carimbos de data/hora da linha do tempo**: Os carimbos do primeiro turno são preservados durante mudanças de rota; os pontos já não tremem ao passar o cursor.
- **Sincronização na nuvem no Brave**: Eliminado o popup de erro causado por chamadas de token de autenticação não suportadas.
- **Ícones do popup**: A fonte Material Symbols é agora incluída localmente para evitar conflitos com proxy/firewall.

<!-- lang:ar -->

### الجديد

- **حفظ المسودة تلقائيًا** *(معطّل افتراضيًا)*: يتم حفظ النص غير المرسل تلقائيًا واستعادته عند العودة إلى المحادثة.
- **حجم خط الدردشة** *(معطّل افتراضيًا)*: اضبط حجم خط رسائل الدردشة (80%–150%) من النافذة المنبثقة. [→ التوثيق](/guide/chat-font-size)
- **اختصارات gg / GG**: انتقال بأسلوب Vim إلى أول أو آخر دور في المحادثة. [→ التوثيق](/guide/timeline)
- **توسيع عرض الجداول**: تتوسع الجداول الآن لتتطابق مع إعداد عرض الدردشة. 
### الإصلاحات

- **تصدير الصور**: إصلاح فشل العرض الناتج عن أحرف تحكم XML غير قانونية في محتوى الدردشة.
- **طوابع وقت الخط الزمني**: يتم الحفاظ على طوابع وقت الدور الأول أثناء تغيير المسار؛ لم تعد النقاط ترتعش عند التمرير.
- **المزامنة السحابية على Brave**: تم إزالة نافذة الخطأ المنبثقة الناتجة عن استدعاءات رمز المصادقة غير المدعومة.
- **أيقونات النافذة المنبثقة**: تم تضمين خط Material Symbols محليًا لتجنب تعارضات الوكيل/جدار الحماية.

<!-- lang:ko -->

### 새로운 기능

- **초안 자동 저장** *(기본 비활성)*: 보내지 않은 입력 내용이 자동 저장되어 대화로 돌아오면 복원됩니다.
- **채팅 글꼴 크기** *(기본 비활성)*: 팝업에서 채팅 메시지의 글꼴 크기(80%–150%)를 조정할 수 있습니다. [→ 문서](/guide/chat-font-size)
- **gg / GG 단축키**: Vim 스타일로 대화의 첫 번째 또는 마지막 턴으로 이동합니다. [→ 문서](/guide/timeline)
- **표 너비 확장**: 표가 채팅 너비 설정에 맞게 확장됩니다. 
### 수정

- **이미지 내보내기**: 채팅 내용의 XML 불법 제어 문자로 인한 렌더링 실패를 수정했습니다.
- **타임라인 타임스탬프**: 경로 변경 시 첫 번째 턴의 타임스탬프가 유지되며, 호버 시 점이 더 이상 떨리지 않습니다.
- **Brave 클라우드 동기화**: 지원되지 않는 인증 토큰 호출로 인한 오류 팝업을 제거했습니다.
- **팝업 아이콘**: 프록시/방화벽 충돌을 방지하기 위해 Material Symbols 글꼴을 로컬로 번들링합니다.

<!-- lang:ru -->

### Новое

- **Автосохранение черновиков** *(выключено по умолчанию)*: Неотправленный текст автоматически сохраняется и восстанавливается при возврате к беседе.
- **Размер шрифта чата** *(выключено по умолчанию)*: Настройте размер шрифта сообщений (80%–150%) из попапа. [→ Документация](/guide/chat-font-size)
- **Горячие клавиши gg / GG**: Переход в стиле Vim к первому или последнему сообщению в беседе. [→ Документация](/guide/timeline)
- **Ширина таблиц**: Таблицы теперь расширяются в соответствии с настройкой ширины чата. 
### Исправления

- **Экспорт изображений**: Исправлены ошибки рендеринга, вызванные недопустимыми управляющими символами XML в содержимом чата.
- **Временные метки таймлайна**: Временные метки первого хода сохраняются при смене маршрута; точки больше не дрожат при наведении.
- **Облачная синхронизация в Brave**: Устранён всплывающий попап ошибки из-за неподдерживаемых вызовов токена аутентификации.
- **Иконки попапа**: Шрифт Material Symbols теперь включён локально для избежания конфликтов с прокси/файрволом.
`;export{e as default};
